# RAM PLAYER 19.0.9 r2 — rebuild kit

IMPORTANT: the original Android Studio/Gradle source of PATCH9 and 19.0.9 does not exist here.
This kit rebuilds the APK at bytecode level (apktool + smali), which is how 19.0.9 r2 was made.

- `apk-project/`  : decoded 19.0.9 APK (smali bytecode of every class, raw resources, native FFmpeg libs for 4 ABIs).
                    PATCH9 code lives in `smali/` + `smali_classes2/`; ULTRA additions in `smali_classes3/`.
- `patches/Fix10.java`   : the r2 change (dead-link / server-error handling). Compiled into `classes4.dex`.
- `patches/TestHook.java`: TEST BUILD ONLY. Remote-control receiver used for automated tests (`am broadcast -a ram.test.CMD`).
- `build/build.sh`       : `build.sh release out.apk` or `build.sh test out.apk`. Applies the one-line smali hook in
                           `Ultra.onPlayerError`, bumps versionCode (axml_vc.py), assembles, zipaligns (16 KB), signs.
                           Paths inside point to /tmp/ram and /tmp/tools — edit them for your machine.
                           Needs: JDK 17, apktool 2.12, Android build-tools 35 (d8, zipalign, apksigner), android.jar (API 34).
- `tests/`        : local HTTP test server (404/410/403/500/503, VLC-only UA, wrong MIME, HTML, extensionless HLS) and zapping logs.
- `reference/ultra_decompiled_java/` : JADX output of the ULTRA classes. READ-ONLY reference — it does NOT compile (~28 decompiler errors).

The signing key is NOT in this ZIP. It is in Files → signing-key/ (keep it private, back it up).
