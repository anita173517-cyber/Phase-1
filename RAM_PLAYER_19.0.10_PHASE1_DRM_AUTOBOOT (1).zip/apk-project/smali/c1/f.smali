.class public abstract Lc1/f;
.super Ljava/lang/Exception;
.source "SourceFile"
