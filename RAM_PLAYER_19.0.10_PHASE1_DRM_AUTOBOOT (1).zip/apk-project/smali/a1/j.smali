.class public final synthetic La1/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq5/u;


# instance fields
.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, La1/j;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 15

    .line 1
    iget v0, p0, La1/j;->k:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :try_start_0
    const-string v0, "androidx.media3.effect.DefaultVideoFrameProcessor$Factory$Builder"

    .line 7
    .line 8
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    return-object v0

    .line 13
    :catch_0
    move-exception v0

    .line 14
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    .line 17
    .line 18
    .line 19
    throw v1

    .line 20
    :pswitch_0
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 29
    .line 30
    :try_start_1
    const-string v2, "config_mediaMetadataBitmapMaxSize"

    .line 31
    .line 32
    const-string v3, "dimen"

    .line 33
    .line 34
    const-string v4, "android"

    .line 35
    .line 36
    invoke-virtual {v0, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 41
    .line 42
    .line 43
    move-result v1
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    .line 44
    :catch_1
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0

    .line 49
    :pswitch_1
    const-string v0, "android"

    .line 50
    .line 51
    const-string v1, "dimen"

    .line 52
    .line 53
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    const/16 v3, 0x1f

    .line 58
    .line 59
    :try_start_2
    const-string v4, "notification_right_icon_size"

    .line 60
    .line 61
    invoke-virtual {v2, v4, v1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    invoke-virtual {v2, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 70
    .line 71
    if-ge v5, v3, :cond_1

    .line 72
    .line 73
    const-string v5, "notification_media_image_max_height"

    .line 74
    .line 75
    invoke-virtual {v2, v5, v1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 76
    .line 77
    .line 78
    move-result v5

    .line 79
    invoke-virtual {v2, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    const-string v6, "notification_media_image_max_width"

    .line 84
    .line 85
    invoke-virtual {v2, v6, v1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    invoke-static {v0, v5}, Ljava/lang/Math;->max(II)I

    .line 98
    .line 99
    .line 100
    move-result v4
    :try_end_2
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    .line 101
    goto :goto_1

    .line 102
    :catch_2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 103
    .line 104
    if-ge v0, v3, :cond_0

    .line 105
    .line 106
    const/16 v0, 0x118

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_0
    const/16 v0, 0x30

    .line 110
    .line 111
    :goto_0
    int-to-float v0, v0

    .line 112
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 113
    .line 114
    .line 115
    move-result-object v1

    .line 116
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 117
    .line 118
    mul-float/2addr v0, v1

    .line 119
    float-to-int v4, v0

    .line 120
    :cond_1
    :goto_1
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    return-object v0

    .line 125
    :pswitch_2
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 126
    .line 127
    const/16 v1, 0x25

    .line 128
    .line 129
    if-le v0, v1, :cond_2

    .line 130
    .line 131
    const-string v0, "persist.audio.compressed_offload_implicit_aac"

    .line 132
    .line 133
    invoke-static {v0}, Ly0/k0;->K(Ljava/lang/String;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    const-string v1, "false"

    .line 138
    .line 139
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-eqz v0, :cond_2

    .line 144
    .line 145
    const/4 v0, 0x1

    .line 146
    goto :goto_2

    .line 147
    :cond_2
    const/4 v0, 0x0

    .line 148
    :goto_2
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 149
    .line 150
    .line 151
    move-result-object v0

    .line 152
    return-object v0

    .line 153
    :pswitch_3
    const/16 v0, 0xc

    .line 154
    .line 155
    new-array v0, v0, [B

    .line 156
    .line 157
    sget-object v1, Le1/i;->i:Ljava/util/Random;

    .line 158
    .line 159
    invoke-virtual {v1, v0}, Ljava/util/Random;->nextBytes([B)V

    .line 160
    .line 161
    .line 162
    const/16 v1, 0xa

    .line 163
    .line 164
    invoke-static {v0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    return-object v0

    .line 169
    :pswitch_4
    new-instance v1, Ld1/g;

    .line 170
    .line 171
    new-instance v2, Lv1/e;

    .line 172
    .line 173
    invoke-direct {v2}, Lv1/e;-><init>()V

    .line 174
    .line 175
    .line 176
    const/4 v13, 0x1

    .line 177
    sget-object v14, Lr5/a2;->n:Lr5/a2;

    .line 178
    .line 179
    const v3, 0xc350

    .line 180
    .line 181
    .line 182
    const/16 v4, 0x3e8

    .line 183
    .line 184
    const v5, 0xc350

    .line 185
    .line 186
    .line 187
    const v6, 0xc350

    .line 188
    .line 189
    .line 190
    const/16 v7, 0x3e8

    .line 191
    .line 192
    const/16 v8, 0x3e8

    .line 193
    .line 194
    const/16 v9, 0x7d0

    .line 195
    .line 196
    const/16 v10, 0x3e8

    .line 197
    .line 198
    const/4 v11, -0x1

    .line 199
    const/4 v12, 0x0

    .line 200
    invoke-direct/range {v1 .. v14}, Ld1/g;-><init>(Lv1/e;IIIIIIIIIZZLjava/util/Map;)V

    .line 201
    .line 202
    .line 203
    return-object v1

    .line 204
    :pswitch_5
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    instance-of v1, v0, Lcom/google/common/util/concurrent/s;

    .line 209
    .line 210
    if-eqz v1, :cond_3

    .line 211
    .line 212
    check-cast v0, Lcom/google/common/util/concurrent/s;

    .line 213
    .line 214
    goto :goto_4

    .line 215
    :cond_3
    instance-of v1, v0, Ljava/util/concurrent/ScheduledExecutorService;

    .line 216
    .line 217
    if-eqz v1, :cond_4

    .line 218
    .line 219
    new-instance v1, Lcom/google/common/util/concurrent/x;

    .line 220
    .line 221
    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    .line 222
    .line 223
    invoke-direct {v1, v0}, Lcom/google/common/util/concurrent/x;-><init>(Ljava/util/concurrent/ScheduledExecutorService;)V

    .line 224
    .line 225
    .line 226
    :goto_3
    move-object v0, v1

    .line 227
    goto :goto_4

    .line 228
    :cond_4
    new-instance v1, Lcom/google/common/util/concurrent/u;

    .line 229
    .line 230
    invoke-direct {v1, v0}, Lcom/google/common/util/concurrent/u;-><init>(Ljava/util/concurrent/ExecutorService;)V

    .line 231
    .line 232
    .line 233
    goto :goto_3

    .line 234
    :goto_4
    return-object v0

    .line 235
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
