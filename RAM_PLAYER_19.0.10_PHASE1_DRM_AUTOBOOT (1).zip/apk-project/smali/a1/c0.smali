.class public final La1/c0;
.super La1/a0;
.source "SourceFile"


# instance fields
.field public final m:I

.field public final n:Ljava/util/Map;


# direct methods
.method public constructor <init>(ILa1/n;Ljava/util/Map;)V
    .locals 2

    .line 1
    const-string v0, "Response code: "

    .line 2
    .line 3
    invoke-static {v0, p1}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/16 v1, 0x7d4

    .line 8
    .line 9
    invoke-direct {p0, v1, p2, v0}, La1/a0;-><init>(ILjava/io/IOException;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iput p1, p0, La1/c0;->m:I

    .line 13
    .line 14
    iput-object p3, p0, La1/c0;->n:Ljava/util/Map;

    .line 15
    .line 16
    return-void
.end method
