.class public final Lcom/bumptech/glide/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ComponentCallbacks2;


# static fields
.field public static volatile s:Lcom/bumptech/glide/b;

.field public static volatile t:Z


# instance fields
.field public final k:Lu4/l;

.field public final l:Lv4/a;

.field public final m:Lw4/c;

.field public final n:Lcom/bumptech/glide/e;

.field public final o:Lv4/f;

.field public final p:Lh5/l;

.field public final q:La2/h;

.field public final r:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lu4/l;Lw4/c;Lv4/a;Lv4/f;Lh5/l;La2/h;La2/h;Lr/e;Ljava/util/List;Ljava/util/ArrayList;Lb4/a;Landroidx/lifecycle/c0;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 10
    .line 11
    iput-object p2, p0, Lcom/bumptech/glide/b;->k:Lu4/l;

    .line 12
    .line 13
    iput-object p4, p0, Lcom/bumptech/glide/b;->l:Lv4/a;

    .line 14
    .line 15
    iput-object p5, p0, Lcom/bumptech/glide/b;->o:Lv4/f;

    .line 16
    .line 17
    iput-object p3, p0, Lcom/bumptech/glide/b;->m:Lw4/c;

    .line 18
    .line 19
    iput-object p6, p0, Lcom/bumptech/glide/b;->p:Lh5/l;

    .line 20
    .line 21
    iput-object p7, p0, Lcom/bumptech/glide/b;->q:La2/h;

    .line 22
    .line 23
    new-instance p4, Lh5/u;

    .line 24
    .line 25
    invoke-direct {p4, p0, p11, p12}, Lh5/u;-><init>(Lcom/bumptech/glide/b;Ljava/util/ArrayList;Lb4/a;)V

    .line 26
    .line 27
    .line 28
    move-object p3, p5

    .line 29
    new-instance p5, Li1/n;

    .line 30
    .line 31
    const/16 p6, 0xe

    .line 32
    .line 33
    invoke-direct {p5, p6}, Li1/n;-><init>(I)V

    .line 34
    .line 35
    .line 36
    move-object p7, p9

    .line 37
    move-object p9, p2

    .line 38
    move-object p2, p1

    .line 39
    new-instance p1, Lcom/bumptech/glide/e;

    .line 40
    .line 41
    move-object p6, p8

    .line 42
    move-object p8, p10

    .line 43
    move-object p10, p13

    .line 44
    invoke-direct/range {p1 .. p10}, Lcom/bumptech/glide/e;-><init>(Landroid/content/Context;Lv4/f;Lh5/u;Li1/n;La2/h;Lr/e;Ljava/util/List;Lu4/l;Landroidx/lifecycle/c0;)V

    .line 45
    .line 46
    .line 47
    iput-object p1, p0, Lcom/bumptech/glide/b;->n:Lcom/bumptech/glide/e;

    .line 48
    .line 49
    return-void
.end method

.method public static b(Landroid/content/Context;)Lcom/bumptech/glide/b;
    .locals 7

    .line 1
    sget-object v0, Lcom/bumptech/glide/b;->s:Lcom/bumptech/glide/b;

    .line 2
    .line 3
    if-nez v0, :cond_3

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const-string v1, "Glide"

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    const/4 v3, 0x1

    .line 13
    :try_start_0
    const-string v4, "com.bumptech.glide.GeneratedAppGlideModuleImpl"

    .line 14
    .line 15
    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    new-array v5, v3, [Ljava/lang/Class;

    .line 20
    .line 21
    const-class v6, Landroid/content/Context;

    .line 22
    .line 23
    aput-object v6, v5, v2

    .line 24
    .line 25
    invoke-virtual {v4, v5}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    new-array v5, v3, [Ljava/lang/Object;

    .line 34
    .line 35
    aput-object v0, v5, v2

    .line 36
    .line 37
    invoke-virtual {v4, v5}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Lcom/bumptech/glide/GeneratedAppGlideModule;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :catch_0
    move-exception p0

    .line 45
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    const-string v1, "GeneratedAppGlideModuleImpl is implemented incorrectly. If you\'ve manually implemented this class, remove your implementation. The Annotation processor will generate a correct implementation."

    .line 48
    .line 49
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    throw v0

    .line 53
    :catch_1
    move-exception p0

    .line 54
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 55
    .line 56
    const-string v1, "GeneratedAppGlideModuleImpl is implemented incorrectly. If you\'ve manually implemented this class, remove your implementation. The Annotation processor will generate a correct implementation."

    .line 57
    .line 58
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 59
    .line 60
    .line 61
    throw v0

    .line 62
    :catch_2
    move-exception p0

    .line 63
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 64
    .line 65
    const-string v1, "GeneratedAppGlideModuleImpl is implemented incorrectly. If you\'ve manually implemented this class, remove your implementation. The Annotation processor will generate a correct implementation."

    .line 66
    .line 67
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :catch_3
    move-exception p0

    .line 72
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 73
    .line 74
    const-string v1, "GeneratedAppGlideModuleImpl is implemented incorrectly. If you\'ve manually implemented this class, remove your implementation. The Annotation processor will generate a correct implementation."

    .line 75
    .line 76
    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 77
    .line 78
    .line 79
    throw v0

    .line 80
    :catch_4
    const/4 v0, 0x5

    .line 81
    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_0

    .line 86
    .line 87
    const-string v0, "Failed to find GeneratedAppGlideModule. You should include an annotationProcessor compile dependency on com.github.bumptech.glide:compiler in your application and a @GlideModule annotated AppGlideModule implementation or LibraryGlideModules will be silently ignored"

    .line 88
    .line 89
    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    :cond_0
    const/4 v0, 0x0

    .line 93
    :goto_0
    const-class v1, Lcom/bumptech/glide/b;

    .line 94
    .line 95
    monitor-enter v1

    .line 96
    :try_start_1
    sget-object v4, Lcom/bumptech/glide/b;->s:Lcom/bumptech/glide/b;

    .line 97
    .line 98
    if-nez v4, :cond_2

    .line 99
    .line 100
    sget-boolean v4, Lcom/bumptech/glide/b;->t:Z

    .line 101
    .line 102
    if-nez v4, :cond_1

    .line 103
    .line 104
    sput-boolean v3, Lcom/bumptech/glide/b;->t:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 105
    .line 106
    :try_start_2
    invoke-static {p0, v0}, Lcom/bumptech/glide/b;->d(Landroid/content/Context;Lcom/bumptech/glide/GeneratedAppGlideModule;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 107
    .line 108
    .line 109
    :try_start_3
    sput-boolean v2, Lcom/bumptech/glide/b;->t:Z

    .line 110
    .line 111
    goto :goto_1

    .line 112
    :catchall_0
    move-exception p0

    .line 113
    sput-boolean v2, Lcom/bumptech/glide/b;->t:Z

    .line 114
    .line 115
    throw p0

    .line 116
    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 117
    .line 118
    const-string v0, "Glide has been called recursively, this is probably an internal library error!"

    .line 119
    .line 120
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p0

    .line 124
    :cond_2
    :goto_1
    monitor-exit v1

    .line 125
    goto :goto_2

    .line 126
    :catchall_1
    move-exception p0

    .line 127
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 128
    throw p0

    .line 129
    :cond_3
    :goto_2
    sget-object p0, Lcom/bumptech/glide/b;->s:Lcom/bumptech/glide/b;

    .line 130
    .line 131
    return-object p0
.end method

.method public static c(Landroid/content/Context;)Lh5/l;
    .locals 1

    .line 1
    const-string v0, "You cannot start a load on a not yet attached View or a Fragment where getActivity() returns null (which usually occurs when getActivity() is called before the Fragment is attached or after the Fragment is destroyed)."

    .line 2
    .line 3
    invoke-static {p0, v0}, Lo5/f;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, Lcom/bumptech/glide/b;->b(Landroid/content/Context;)Lcom/bumptech/glide/b;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    iget-object p0, p0, Lcom/bumptech/glide/b;->p:Lh5/l;

    .line 11
    .line 12
    return-object p0
.end method

.method public static d(Landroid/content/Context;Lcom/bumptech/glide/GeneratedAppGlideModule;)V
    .locals 27

    .line 1
    new-instance v9, Lr/e;

    .line 2
    .line 3
    invoke-direct {v9}, Lr/i;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lc4/e;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {v1, v0}, Lc4/e;-><init>(I)V

    .line 10
    .line 11
    .line 12
    new-instance v8, La2/h;

    .line 13
    .line 14
    const/16 v0, 0xe

    .line 15
    .line 16
    invoke-direct {v8, v0}, La2/h;-><init>(I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 24
    .line 25
    const-string v3, "ManifestParser"

    .line 26
    .line 27
    const/4 v4, 0x3

    .line 28
    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 29
    .line 30
    .line 31
    new-instance v11, Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 34
    .line 35
    .line 36
    const/4 v5, 0x2

    .line 37
    :try_start_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    const/16 v7, 0x80

    .line 46
    .line 47
    invoke-virtual {v0, v6, v7}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-eqz v0, :cond_4

    .line 52
    .line 53
    iget-object v6, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    .line 54
    .line 55
    if-nez v6, :cond_0

    .line 56
    .line 57
    goto :goto_2

    .line 58
    :cond_0
    invoke-static {v3, v5}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 59
    .line 60
    .line 61
    move-result v6

    .line 62
    if-eqz v6, :cond_1

    .line 63
    .line 64
    iget-object v6, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    .line 65
    .line 66
    invoke-static {v6}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :catch_0
    move-exception v0

    .line 71
    goto :goto_3

    .line 72
    :cond_1
    :goto_0
    iget-object v6, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    .line 73
    .line 74
    invoke-virtual {v6}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 79
    .line 80
    .line 81
    move-result-object v6

    .line 82
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 83
    .line 84
    .line 85
    move-result v7

    .line 86
    if-eqz v7, :cond_3

    .line 87
    .line 88
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v7

    .line 92
    check-cast v7, Ljava/lang/String;

    .line 93
    .line 94
    const-string v10, "GlideModule"

    .line 95
    .line 96
    iget-object v12, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    .line 97
    .line 98
    invoke-virtual {v12, v7}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v12

    .line 102
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v10

    .line 106
    if-nez v10, :cond_2

    .line 107
    .line 108
    goto :goto_1

    .line 109
    :cond_2
    invoke-static {v7}, Lc4/b0;->w(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    const/4 v0, 0x0

    .line 113
    throw v0

    .line 114
    :cond_3
    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 115
    .line 116
    .line 117
    goto :goto_4

    .line 118
    :cond_4
    :goto_2
    invoke-static {v3, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 119
    .line 120
    .line 121
    goto :goto_4

    .line 122
    :goto_3
    const/4 v6, 0x6

    .line 123
    invoke-static {v3, v6}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    if-eqz v6, :cond_5

    .line 128
    .line 129
    const-string v6, "Failed to parse glide modules"

    .line 130
    .line 131
    invoke-static {v3, v6, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 132
    .line 133
    .line 134
    :cond_5
    :goto_4
    if-eqz p1, :cond_7

    .line 135
    .line 136
    new-instance v0, Ljava/util/HashSet;

    .line 137
    .line 138
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v0}, Ljava/util/HashSet;->isEmpty()Z

    .line 142
    .line 143
    .line 144
    move-result v0

    .line 145
    if-nez v0, :cond_7

    .line 146
    .line 147
    new-instance v0, Ljava/util/HashSet;

    .line 148
    .line 149
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 157
    .line 158
    .line 159
    move-result v3

    .line 160
    if-nez v3, :cond_6

    .line 161
    .line 162
    goto :goto_5

    .line 163
    :cond_6
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    .line 169
    .line 170
    new-instance v0, Ljava/lang/ClassCastException;

    .line 171
    .line 172
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 173
    .line 174
    .line 175
    throw v0

    .line 176
    :cond_7
    :goto_5
    const-string v0, "Glide"

    .line 177
    .line 178
    invoke-static {v0, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-eqz v0, :cond_9

    .line 183
    .line 184
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 189
    .line 190
    .line 191
    move-result v3

    .line 192
    if-nez v3, :cond_8

    .line 193
    .line 194
    goto :goto_6

    .line 195
    :cond_8
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 200
    .line 201
    .line 202
    new-instance v0, Ljava/lang/ClassCastException;

    .line 203
    .line 204
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 205
    .line 206
    .line 207
    throw v0

    .line 208
    :cond_9
    :goto_6
    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 213
    .line 214
    .line 215
    move-result v3

    .line 216
    if-nez v3, :cond_15

    .line 217
    .line 218
    new-instance v0, Lx4/a;

    .line 219
    .line 220
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 221
    .line 222
    .line 223
    sget v3, Lx4/d;->m:I

    .line 224
    .line 225
    const/4 v4, 0x4

    .line 226
    if-nez v3, :cond_a

    .line 227
    .line 228
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 229
    .line 230
    .line 231
    move-result-object v3

    .line 232
    invoke-virtual {v3}, Ljava/lang/Runtime;->availableProcessors()I

    .line 233
    .line 234
    .line 235
    move-result v3

    .line 236
    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    .line 237
    .line 238
    .line 239
    move-result v3

    .line 240
    sput v3, Lx4/d;->m:I

    .line 241
    .line 242
    :cond_a
    sget v13, Lx4/d;->m:I

    .line 243
    .line 244
    const-string v3, "source"

    .line 245
    .line 246
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 247
    .line 248
    .line 249
    move-result v6

    .line 250
    if-nez v6, :cond_14

    .line 251
    .line 252
    new-instance v12, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 253
    .line 254
    sget-object v19, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 255
    .line 256
    new-instance v18, Ljava/util/concurrent/PriorityBlockingQueue;

    .line 257
    .line 258
    invoke-direct/range {v18 .. v18}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    .line 259
    .line 260
    .line 261
    new-instance v6, Lx4/b;

    .line 262
    .line 263
    const/4 v7, 0x0

    .line 264
    invoke-direct {v6, v0, v3, v7}, Lx4/b;-><init>(Lx4/a;Ljava/lang/String;Z)V

    .line 265
    .line 266
    .line 267
    const-wide/16 v15, 0x0

    .line 268
    .line 269
    move v14, v13

    .line 270
    move-object/from16 v17, v19

    .line 271
    .line 272
    move-object/from16 v19, v6

    .line 273
    .line 274
    invoke-direct/range {v12 .. v19}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 275
    .line 276
    .line 277
    move-object/from16 v19, v17

    .line 278
    .line 279
    new-instance v0, Lx4/d;

    .line 280
    .line 281
    invoke-direct {v0, v12}, Lx4/d;-><init>(Ljava/util/concurrent/ThreadPoolExecutor;)V

    .line 282
    .line 283
    .line 284
    new-instance v3, Lx4/a;

    .line 285
    .line 286
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 287
    .line 288
    .line 289
    const-string v6, "disk-cache"

    .line 290
    .line 291
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 292
    .line 293
    .line 294
    move-result v10

    .line 295
    if-nez v10, :cond_13

    .line 296
    .line 297
    new-instance v14, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 298
    .line 299
    new-instance v20, Ljava/util/concurrent/PriorityBlockingQueue;

    .line 300
    .line 301
    invoke-direct/range {v20 .. v20}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    .line 302
    .line 303
    .line 304
    new-instance v10, Lx4/b;

    .line 305
    .line 306
    const/4 v15, 0x1

    .line 307
    invoke-direct {v10, v3, v6, v15}, Lx4/b;-><init>(Lx4/a;Ljava/lang/String;Z)V

    .line 308
    .line 309
    .line 310
    const-wide/16 v17, 0x0

    .line 311
    .line 312
    move/from16 v16, v15

    .line 313
    .line 314
    move-object/from16 v21, v10

    .line 315
    .line 316
    invoke-direct/range {v14 .. v21}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 317
    .line 318
    .line 319
    new-instance v3, Lx4/d;

    .line 320
    .line 321
    invoke-direct {v3, v14}, Lx4/d;-><init>(Ljava/util/concurrent/ThreadPoolExecutor;)V

    .line 322
    .line 323
    .line 324
    sget v6, Lx4/d;->m:I

    .line 325
    .line 326
    if-nez v6, :cond_b

    .line 327
    .line 328
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 329
    .line 330
    .line 331
    move-result-object v6

    .line 332
    invoke-virtual {v6}, Ljava/lang/Runtime;->availableProcessors()I

    .line 333
    .line 334
    .line 335
    move-result v6

    .line 336
    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    .line 337
    .line 338
    .line 339
    move-result v6

    .line 340
    sput v6, Lx4/d;->m:I

    .line 341
    .line 342
    :cond_b
    sget v6, Lx4/d;->m:I

    .line 343
    .line 344
    const/4 v10, 0x1

    .line 345
    if-lt v6, v4, :cond_c

    .line 346
    .line 347
    move v15, v5

    .line 348
    goto :goto_7

    .line 349
    :cond_c
    move v15, v10

    .line 350
    :goto_7
    new-instance v4, Lx4/a;

    .line 351
    .line 352
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 353
    .line 354
    .line 355
    const-string v5, "animation"

    .line 356
    .line 357
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 358
    .line 359
    .line 360
    move-result v6

    .line 361
    if-nez v6, :cond_12

    .line 362
    .line 363
    new-instance v14, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 364
    .line 365
    new-instance v20, Ljava/util/concurrent/PriorityBlockingQueue;

    .line 366
    .line 367
    invoke-direct/range {v20 .. v20}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    .line 368
    .line 369
    .line 370
    new-instance v6, Lx4/b;

    .line 371
    .line 372
    invoke-direct {v6, v4, v5, v10}, Lx4/b;-><init>(Lx4/a;Ljava/lang/String;Z)V

    .line 373
    .line 374
    .line 375
    const-wide/16 v17, 0x0

    .line 376
    .line 377
    move/from16 v16, v15

    .line 378
    .line 379
    move-object/from16 v21, v6

    .line 380
    .line 381
    invoke-direct/range {v14 .. v21}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 382
    .line 383
    .line 384
    new-instance v4, Lx4/d;

    .line 385
    .line 386
    invoke-direct {v4, v14}, Lx4/d;-><init>(Ljava/util/concurrent/ThreadPoolExecutor;)V

    .line 387
    .line 388
    .line 389
    new-instance v5, Lw4/d;

    .line 390
    .line 391
    invoke-direct {v5, v2}, Lw4/d;-><init>(Landroid/content/Context;)V

    .line 392
    .line 393
    .line 394
    new-instance v6, La2/d;

    .line 395
    .line 396
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 397
    .line 398
    .line 399
    iget-object v10, v5, Lw4/d;->a:Landroid/content/Context;

    .line 400
    .line 401
    iget v12, v5, Lw4/d;->d:F

    .line 402
    .line 403
    iget-object v13, v5, Lw4/d;->b:Landroid/app/ActivityManager;

    .line 404
    .line 405
    invoke-virtual {v13}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    .line 406
    .line 407
    .line 408
    move-result v14

    .line 409
    if-eqz v14, :cond_d

    .line 410
    .line 411
    const/high16 v14, 0x200000

    .line 412
    .line 413
    goto :goto_8

    .line 414
    :cond_d
    const/high16 v14, 0x400000

    .line 415
    .line 416
    :goto_8
    iput v14, v6, La2/d;->c:I

    .line 417
    .line 418
    invoke-virtual {v13}, Landroid/app/ActivityManager;->getMemoryClass()I

    .line 419
    .line 420
    .line 421
    move-result v15

    .line 422
    const/high16 v16, 0x100000

    .line 423
    .line 424
    mul-int v15, v15, v16

    .line 425
    .line 426
    invoke-virtual {v13}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    .line 427
    .line 428
    .line 429
    move-result v16

    .line 430
    int-to-float v15, v15

    .line 431
    if-eqz v16, :cond_e

    .line 432
    .line 433
    const v16, 0x3ea8f5c3    # 0.33f

    .line 434
    .line 435
    .line 436
    goto :goto_9

    .line 437
    :cond_e
    const v16, 0x3ecccccd    # 0.4f

    .line 438
    .line 439
    .line 440
    :goto_9
    mul-float v15, v15, v16

    .line 441
    .line 442
    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    .line 443
    .line 444
    .line 445
    move-result v15

    .line 446
    iget-object v5, v5, Lw4/d;->c:Lu4/k;

    .line 447
    .line 448
    iget-object v5, v5, Lu4/k;->l:Ljava/lang/Object;

    .line 449
    .line 450
    check-cast v5, Landroid/util/DisplayMetrics;

    .line 451
    .line 452
    iget v7, v5, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 453
    .line 454
    iget v5, v5, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 455
    .line 456
    mul-int/2addr v7, v5

    .line 457
    mul-int/lit8 v7, v7, 0x4

    .line 458
    .line 459
    int-to-float v5, v7

    .line 460
    mul-float v7, v5, v12

    .line 461
    .line 462
    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    .line 463
    .line 464
    .line 465
    move-result v7

    .line 466
    const/high16 v16, 0x40000000    # 2.0f

    .line 467
    .line 468
    mul-float v5, v5, v16

    .line 469
    .line 470
    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    .line 471
    .line 472
    .line 473
    move-result v5

    .line 474
    move-object/from16 v24, v0

    .line 475
    .line 476
    sub-int v0, v15, v14

    .line 477
    .line 478
    move-object/from16 v23, v3

    .line 479
    .line 480
    add-int v3, v5, v7

    .line 481
    .line 482
    if-gt v3, v0, :cond_f

    .line 483
    .line 484
    iput v5, v6, La2/d;->b:I

    .line 485
    .line 486
    iput v7, v6, La2/d;->a:I

    .line 487
    .line 488
    goto :goto_a

    .line 489
    :cond_f
    int-to-float v0, v0

    .line 490
    add-float v3, v12, v16

    .line 491
    .line 492
    div-float/2addr v0, v3

    .line 493
    mul-float v16, v16, v0

    .line 494
    .line 495
    invoke-static/range {v16 .. v16}, Ljava/lang/Math;->round(F)I

    .line 496
    .line 497
    .line 498
    move-result v3

    .line 499
    iput v3, v6, La2/d;->b:I

    .line 500
    .line 501
    mul-float/2addr v0, v12

    .line 502
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 503
    .line 504
    .line 505
    move-result v0

    .line 506
    iput v0, v6, La2/d;->a:I

    .line 507
    .line 508
    :goto_a
    const-string v0, "MemorySizeCalculator"

    .line 509
    .line 510
    const/4 v3, 0x3

    .line 511
    invoke-static {v0, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 512
    .line 513
    .line 514
    move-result v0

    .line 515
    if-eqz v0, :cond_10

    .line 516
    .line 517
    iget v0, v6, La2/d;->b:I

    .line 518
    .line 519
    move-object/from16 v26, v4

    .line 520
    .line 521
    int-to-long v3, v0

    .line 522
    invoke-static {v10, v3, v4}, Landroid/text/format/Formatter;->formatFileSize(Landroid/content/Context;J)Ljava/lang/String;

    .line 523
    .line 524
    .line 525
    iget v0, v6, La2/d;->a:I

    .line 526
    .line 527
    int-to-long v3, v0

    .line 528
    invoke-static {v10, v3, v4}, Landroid/text/format/Formatter;->formatFileSize(Landroid/content/Context;J)Ljava/lang/String;

    .line 529
    .line 530
    .line 531
    int-to-long v3, v14

    .line 532
    invoke-static {v10, v3, v4}, Landroid/text/format/Formatter;->formatFileSize(Landroid/content/Context;J)Ljava/lang/String;

    .line 533
    .line 534
    .line 535
    int-to-long v3, v15

    .line 536
    invoke-static {v10, v3, v4}, Landroid/text/format/Formatter;->formatFileSize(Landroid/content/Context;J)Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    invoke-virtual {v13}, Landroid/app/ActivityManager;->getMemoryClass()I

    .line 540
    .line 541
    .line 542
    invoke-virtual {v13}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    .line 543
    .line 544
    .line 545
    goto :goto_b

    .line 546
    :cond_10
    move-object/from16 v26, v4

    .line 547
    .line 548
    :goto_b
    new-instance v7, La2/h;

    .line 549
    .line 550
    const/16 v0, 0x19

    .line 551
    .line 552
    invoke-direct {v7, v0}, La2/h;-><init>(I)V

    .line 553
    .line 554
    .line 555
    iget v0, v6, La2/d;->a:I

    .line 556
    .line 557
    if-lez v0, :cond_11

    .line 558
    .line 559
    new-instance v3, Lv4/g;

    .line 560
    .line 561
    int-to-long v4, v0

    .line 562
    invoke-direct {v3, v4, v5}, Lv4/g;-><init>(J)V

    .line 563
    .line 564
    .line 565
    :goto_c
    move-object v4, v3

    .line 566
    goto :goto_d

    .line 567
    :cond_11
    new-instance v3, Lp1/h0;

    .line 568
    .line 569
    const/16 v0, 0x16

    .line 570
    .line 571
    invoke-direct {v3, v0}, Lp1/h0;-><init>(I)V

    .line 572
    .line 573
    .line 574
    goto :goto_c

    .line 575
    :goto_d
    new-instance v5, Lv4/f;

    .line 576
    .line 577
    iget v0, v6, La2/d;->c:I

    .line 578
    .line 579
    invoke-direct {v5, v0}, Lv4/f;-><init>(I)V

    .line 580
    .line 581
    .line 582
    new-instance v3, Lw4/c;

    .line 583
    .line 584
    iget v0, v6, La2/d;->b:I

    .line 585
    .line 586
    int-to-long v12, v0

    .line 587
    invoke-direct {v3, v12, v13}, Lo5/j;-><init>(J)V

    .line 588
    .line 589
    .line 590
    new-instance v0, Lu4/k;

    .line 591
    .line 592
    invoke-direct {v0, v2}, Lu4/k;-><init>(Landroid/content/Context;)V

    .line 593
    .line 594
    .line 595
    new-instance v6, Lu4/l;

    .line 596
    .line 597
    new-instance v10, Lx4/d;

    .line 598
    .line 599
    new-instance v14, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 600
    .line 601
    sget-wide v17, Lx4/d;->l:J

    .line 602
    .line 603
    new-instance v20, Ljava/util/concurrent/SynchronousQueue;

    .line 604
    .line 605
    invoke-direct/range {v20 .. v20}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    .line 606
    .line 607
    .line 608
    new-instance v12, Lx4/b;

    .line 609
    .line 610
    new-instance v13, Lx4/a;

    .line 611
    .line 612
    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 613
    .line 614
    .line 615
    const-string v15, "source-unlimited"

    .line 616
    .line 617
    move-object/from16 v22, v0

    .line 618
    .line 619
    const/4 v0, 0x0

    .line 620
    invoke-direct {v12, v13, v15, v0}, Lx4/b;-><init>(Lx4/a;Ljava/lang/String;Z)V

    .line 621
    .line 622
    .line 623
    const/4 v15, 0x0

    .line 624
    const v16, 0x7fffffff

    .line 625
    .line 626
    .line 627
    move-object/from16 v21, v12

    .line 628
    .line 629
    invoke-direct/range {v14 .. v21}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    .line 630
    .line 631
    .line 632
    invoke-direct {v10, v14}, Lx4/d;-><init>(Ljava/util/concurrent/ThreadPoolExecutor;)V

    .line 633
    .line 634
    .line 635
    move-object/from16 v21, v3

    .line 636
    .line 637
    move-object/from16 v20, v6

    .line 638
    .line 639
    move-object/from16 v25, v10

    .line 640
    .line 641
    invoke-direct/range {v20 .. v26}, Lu4/l;-><init>(Lw4/c;Lu4/k;Lx4/d;Lx4/d;Lx4/d;Lx4/d;)V

    .line 642
    .line 643
    .line 644
    sget-object v10, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 645
    .line 646
    new-instance v13, Landroidx/lifecycle/c0;

    .line 647
    .line 648
    invoke-direct {v13, v1}, Landroidx/lifecycle/c0;-><init>(Lc4/e;)V

    .line 649
    .line 650
    .line 651
    new-instance v6, Lh5/l;

    .line 652
    .line 653
    invoke-direct {v6}, Lh5/l;-><init>()V

    .line 654
    .line 655
    .line 656
    new-instance v0, Lcom/bumptech/glide/b;

    .line 657
    .line 658
    move-object/from16 v12, p1

    .line 659
    .line 660
    move-object v1, v2

    .line 661
    move-object/from16 v2, v20

    .line 662
    .line 663
    invoke-direct/range {v0 .. v13}, Lcom/bumptech/glide/b;-><init>(Landroid/content/Context;Lu4/l;Lw4/c;Lv4/a;Lv4/f;Lh5/l;La2/h;La2/h;Lr/e;Ljava/util/List;Ljava/util/ArrayList;Lb4/a;Landroidx/lifecycle/c0;)V

    .line 664
    .line 665
    .line 666
    invoke-virtual {v1, v0}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    .line 667
    .line 668
    .line 669
    sput-object v0, Lcom/bumptech/glide/b;->s:Lcom/bumptech/glide/b;

    .line 670
    .line 671
    return-void

    .line 672
    :cond_12
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 673
    .line 674
    const-string v1, "Name must be non-null and non-empty, but given: animation"

    .line 675
    .line 676
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 677
    .line 678
    .line 679
    throw v0

    .line 680
    :cond_13
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 681
    .line 682
    const-string v1, "Name must be non-null and non-empty, but given: disk-cache"

    .line 683
    .line 684
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 685
    .line 686
    .line 687
    throw v0

    .line 688
    :cond_14
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 689
    .line 690
    const-string v1, "Name must be non-null and non-empty, but given: source"

    .line 691
    .line 692
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 693
    .line 694
    .line 695
    throw v0

    .line 696
    :cond_15
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    move-result-object v0

    .line 700
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 701
    .line 702
    .line 703
    new-instance v0, Ljava/lang/ClassCastException;

    .line 704
    .line 705
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 706
    .line 707
    .line 708
    throw v0
.end method

.method public static h(Landroid/content/Context;)Lcom/bumptech/glide/m;
    .locals 1

    .line 1
    invoke-static {p0}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lh5/l;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p0}, Lh5/l;->b(Landroid/content/Context;)Lcom/bumptech/glide/m;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method


# virtual methods
.method public final a()V
    .locals 3

    .line 1
    invoke-static {}, Lo5/n;->a()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/bumptech/glide/b;->m:Lw4/c;

    .line 5
    .line 6
    const-wide/16 v1, 0x0

    .line 7
    .line 8
    invoke-virtual {v0, v1, v2}, Lo5/j;->e(J)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lcom/bumptech/glide/b;->l:Lv4/a;

    .line 12
    .line 13
    invoke-interface {v0}, Lv4/a;->q()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lcom/bumptech/glide/b;->o:Lv4/f;

    .line 17
    .line 18
    invoke-virtual {v0}, Lv4/f;->a()V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final e()V
    .locals 5

    .line 1
    invoke-static {}, Lo5/n;->a()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/bumptech/glide/b;->m:Lw4/c;

    .line 5
    .line 6
    monitor-enter v0

    .line 7
    :try_start_0
    iget-wide v1, v0, Lo5/j;->b:J

    .line 8
    .line 9
    long-to-float v1, v1

    .line 10
    const/high16 v2, 0x3f000000    # 0.5f

    .line 11
    .line 12
    mul-float/2addr v1, v2

    .line 13
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    int-to-long v3, v1

    .line 18
    iput-wide v3, v0, Lo5/j;->c:J

    .line 19
    .line 20
    invoke-virtual {v0, v3, v4}, Lo5/j;->e(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 21
    .line 22
    .line 23
    monitor-exit v0

    .line 24
    iget-object v0, p0, Lcom/bumptech/glide/b;->l:Lv4/a;

    .line 25
    .line 26
    invoke-interface {v0, v2}, Lv4/a;->a(F)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :catchall_0
    move-exception v1

    .line 31
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 32
    throw v1
.end method

.method public final f(I)V
    .locals 5

    .line 1
    invoke-static {}, Lo5/n;->a()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 5
    .line 6
    monitor-enter v0

    .line 7
    :try_start_0
    iget-object v1, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    if-ge v3, v2, :cond_0

    .line 15
    .line 16
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    add-int/lit8 v3, v3, 0x1

    .line 21
    .line 22
    check-cast v4, Lcom/bumptech/glide/m;

    .line 23
    .line 24
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catchall_0
    move-exception p1

    .line 29
    goto :goto_1

    .line 30
    :cond_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    iget-object v0, p0, Lcom/bumptech/glide/b;->m:Lw4/c;

    .line 32
    .line 33
    invoke-virtual {v0, p1}, Lw4/c;->f(I)V

    .line 34
    .line 35
    .line 36
    iget-object v0, p0, Lcom/bumptech/glide/b;->l:Lv4/a;

    .line 37
    .line 38
    invoke-interface {v0, p1}, Lv4/a;->o(I)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lcom/bumptech/glide/b;->o:Lv4/f;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, Lv4/f;->i(I)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 48
    throw p1
.end method

.method public final g(Lcom/bumptech/glide/m;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    iget-object v1, p0, Lcom/bumptech/glide/b;->r:Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    monitor-exit v0

    .line 18
    return-void

    .line 19
    :catchall_0
    move-exception p1

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 22
    .line 23
    const-string v1, "Cannot unregister not yet registered manager"

    .line 24
    .line 25
    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw p1

    .line 29
    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    throw p1
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    return-void
.end method

.method public final onLowMemory()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcom/bumptech/glide/b;->a()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final onTrimMemory(I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcom/bumptech/glide/b;->f(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
