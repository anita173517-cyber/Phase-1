.class public abstract Lcom/bumptech/glide/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Z

.field public static b:Ljava/lang/reflect/Method;

.field public static c:Z

.field public static d:Ljava/lang/reflect/Field;


# direct methods
.method public static A(Ly0/u;)V
    .locals 2

    const/4 v0, 0x3

    invoke-virtual {p0, v0}, Ly0/u;->o(I)V

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Ly0/u;->o(I)V

    invoke-virtual {p0}, Ly0/u;->f()Z

    move-result v0

    invoke-virtual {p0}, Ly0/u;->f()Z

    move-result v1

    if-eqz v0, :cond_0

    const/4 v0, 0x5

    invoke-virtual {p0, v0}, Ly0/u;->o(I)V

    :cond_0
    if-eqz v1, :cond_1

    const/4 v0, 0x6

    invoke-virtual {p0, v0}, Ly0/u;->o(I)V

    :cond_1
    return-void
.end method

.method public static B(Ly0/u;)V
    .locals 12

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Ly0/u;->g(I)I

    move-result v1

    const/4 v2, 0x6

    if-nez v1, :cond_0

    invoke-virtual {p0, v2}, Ly0/u;->o(I)V

    return-void

    :cond_0
    const/16 v3, 0x10

    const/4 v4, 0x5

    const/16 v5, 0x8

    invoke-static {p0, v4, v5, v3}, Lcom/bumptech/glide/c;->s(Ly0/u;III)I

    move-result v3

    const/4 v6, 0x1

    add-int/2addr v3, v6

    const/4 v7, 0x7

    if-ne v1, v6, :cond_1

    mul-int/2addr v3, v7

    invoke-virtual {p0, v3}, Ly0/u;->o(I)V

    return-void

    :cond_1
    if-ne v1, v0, :cond_9

    invoke-virtual {p0}, Ly0/u;->f()Z

    move-result v1

    if-eqz v1, :cond_2

    move v8, v6

    goto :goto_0

    :cond_2
    move v8, v4

    :goto_0
    if-eqz v1, :cond_3

    move v4, v7

    :cond_3
    if-eqz v1, :cond_4

    move v2, v5

    :cond_4
    const/4 v1, 0x0

    move v5, v1

    :goto_1
    if-ge v5, v3, :cond_9

    invoke-virtual {p0}, Ly0/u;->f()Z

    move-result v9

    const/16 v10, 0xb4

    if-eqz v9, :cond_5

    invoke-virtual {p0, v7}, Ly0/u;->o(I)V

    move v9, v1

    goto :goto_2

    :cond_5
    invoke-virtual {p0, v0}, Ly0/u;->g(I)I

    move-result v9

    const/4 v11, 0x3

    if-ne v9, v11, :cond_6

    invoke-virtual {p0, v4}, Ly0/u;->g(I)I

    move-result v9

    mul-int/2addr v9, v8

    if-eqz v9, :cond_6

    invoke-virtual {p0}, Ly0/u;->n()V

    :cond_6
    invoke-virtual {p0, v2}, Ly0/u;->g(I)I

    move-result v9

    mul-int/2addr v9, v8

    if-eqz v9, :cond_7

    if-eq v9, v10, :cond_7

    invoke-virtual {p0}, Ly0/u;->n()V

    :cond_7
    invoke-virtual {p0}, Ly0/u;->n()V

    :goto_2
    if-eqz v9, :cond_8

    if-eq v9, v10, :cond_8

    invoke-virtual {p0}, Ly0/u;->f()Z

    move-result v9

    if-eqz v9, :cond_8

    add-int/lit8 v5, v5, 0x1

    :cond_8
    add-int/2addr v5, v6

    goto :goto_1

    :cond_9
    return-void
.end method

.method public static C(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 9

    if-eqz p0, :cond_12

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_9

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v2, v3, :cond_9

    invoke-virtual {p0, v2}, Ljava/lang/String;->codePointAt(I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->charCount(I)I

    move-result v4

    const/16 v5, 0x200d

    if-eq v3, v5, :cond_8

    const v5, 0xfe0f

    if-eq v3, v5, :cond_8

    const v5, 0xfe0e

    if-ne v3, v5, :cond_1

    goto :goto_1

    :cond_1
    const v5, 0x1f000

    if-gt v5, v3, :cond_2

    const v5, 0x1fb00

    if-ge v3, v5, :cond_2

    goto :goto_1

    :cond_2
    const/16 v5, 0x2600

    if-gt v5, v3, :cond_3

    const/16 v6, 0x27c0

    if-ge v3, v6, :cond_3

    goto :goto_1

    :cond_3
    const/16 v6, 0x2190

    if-gt v6, v3, :cond_4

    const/16 v6, 0x2200

    if-ge v3, v6, :cond_4

    goto :goto_1

    :cond_4
    const/16 v6, 0x23e9

    if-gt v6, v3, :cond_5

    const/16 v6, 0x23fb

    if-ge v3, v6, :cond_5

    goto :goto_1

    :cond_5
    const/16 v6, 0x25a0

    if-gt v6, v3, :cond_6

    if-ge v3, v5, :cond_6

    goto :goto_1

    :cond_6
    const/16 v5, 0x2b00

    if-gt v5, v3, :cond_7

    const/16 v5, 0x2c00

    if-ge v3, v5, :cond_7

    goto :goto_1

    :cond_7
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->appendCodePoint(I)Ljava/lang/StringBuilder;

    goto :goto_2

    :cond_8
    :goto_1
    const/16 v3, 0x20

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_2
    add-int/2addr v2, v4

    goto :goto_0

    :cond_9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "toString(...)"

    invoke-static {p0, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v0, 0x2022

    const/16 v2, 0x2c

    invoke-static {p0, v0, v2}, Le7/m;->M(Ljava/lang/String;CC)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\\s*,\\s*(,\\s*)*"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const-string v3, "compile(...)"

    invoke-static {v0, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, ", "

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0, v4}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "replaceAll(...)"

    invoke-static {p0, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "\\s+"

    invoke-static {v4}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    invoke-static {v4, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, " "

    invoke-virtual {v4, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p0

    invoke-virtual {p0, v3}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x1

    new-array v3, v0, [C

    aput-char v2, v3, v1

    const-string v2, "<this>"

    invoke-static {p0, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v0

    move v4, v1

    move v5, v4

    :goto_3
    if-gt v4, v2, :cond_11

    if-nez v5, :cond_a

    move v6, v4

    goto :goto_4

    :cond_a
    move v6, v2

    :goto_4
    invoke-virtual {p0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    move v7, v1

    :goto_5
    if-ge v7, v0, :cond_c

    aget-char v8, v3, v7

    if-ne v6, v8, :cond_b

    goto :goto_6

    :cond_b
    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_c
    const/4 v7, -0x1

    :goto_6
    if-ltz v7, :cond_d

    move v6, v0

    goto :goto_7

    :cond_d
    move v6, v1

    :goto_7
    if-nez v5, :cond_f

    if-nez v6, :cond_e

    move v5, v0

    goto :goto_3

    :cond_e
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_f
    if-nez v6, :cond_10

    goto :goto_8

    :cond_10
    add-int/lit8 v2, v2, -0x1

    goto :goto_3

    :cond_11
    :goto_8
    add-int/2addr v2, v0

    invoke-virtual {p0, v4, v2}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_12
    :goto_9
    const-string p0, ""

    return-object p0
.end method

.method public static final D(Lcom/harindra/iptvpro/PlayerActivity;Z)V
    .locals 8

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    iget v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-ltz v1, :cond_3

    if-ge v1, v0, :cond_3

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lm6/n;

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lm6/n;->a:Ljava/lang/String;

    const-string v3, "channelId"

    invoke-static {v2, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v3, "audio_lang_"

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    move-object v3, v1

    :cond_0
    if-eqz v3, :cond_2

    invoke-static {v3}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ld1/k0;->E0()Lv0/p1;

    move-result-object v2

    check-cast v2, Lu1/k;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v4, Lu1/j;

    invoke-direct {v4, v2}, Lu1/j;-><init>(Lu1/k;)V

    const-string v2, "en"

    const-string v5, "eng"

    const-string v6, "hi"

    const-string v7, "hin"

    filled-new-array {v3, v6, v7, v2, v5}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Lu1/j;->l([Ljava/lang/String;)Lv0/o1;

    invoke-virtual {v4}, Lv0/o1;->b()Lv0/p1;

    move-result-object v2

    invoke-virtual {v1, v2}, Ld1/k0;->o(Lv0/p1;)V

    :cond_2
    :goto_0
    iget-object v0, v0, Lm6/n;->e:Ljava/lang/String;

    invoke-static {p0, v0, p1}, Lcom/bumptech/glide/c;->r(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)V

    :cond_3
    return-void
.end method

.method public static final E(Lcom/harindra/iptvpro/PlayerActivity;IZZ)V
    .locals 16

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    rem-int v1, p1, v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    add-int/2addr v2, v1

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    rem-int/2addr v2, v1

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v6, v1, Lm6/n;->d:Ljava/lang/String;

    const-string v7, "category"

    invoke-static {v6, v7}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v3}, Lm6/m6;->U()Z

    move-result v7

    if-nez v7, :cond_1

    goto :goto_2

    :cond_1
    invoke-static {v6}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3}, Lm6/m6;->A()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_2

    goto :goto_0

    :cond_2
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7, v6}, Le7/m;->K(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3

    goto :goto_1

    :cond_4
    :goto_0
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v7, "ROOT"

    const-string v8, "toLowerCase(...)"

    invoke-static {v3, v7, v6, v3, v8}, Lq3/e;->f(Ljava/util/Locale;Ljava/lang/String;Ljava/lang/String;Ljava/util/Locale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v6, "adult"

    invoke-static {v3, v6, v5}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v6

    if-nez v6, :cond_5

    const-string v6, "18+"

    invoke-static {v3, v6, v5}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v6

    if-nez v6, :cond_5

    const-string v6, "xxx"

    invoke-static {v3, v6, v5}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    move-result v3

    if-eqz v3, :cond_6

    :cond_5
    :goto_1
    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->t2:Ljava/util/HashSet;

    iget-object v6, v1, Lm6/n;->d:Ljava/lang/String;

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v8, "ROOT"

    const-string v9, "toLowerCase(...)"

    invoke-static {v7, v8, v6, v7, v9}, Lq3/e;->f(Ljava/util/Locale;Ljava/lang/String;Ljava/lang/String;Ljava/util/Locale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_6

    move v3, v4

    goto :goto_3

    :cond_6
    :goto_2
    move v3, v5

    :goto_3
    const-wide/16 v6, 0x3e8

    const/4 v8, 0x0

    const-wide/16 v9, 0x1

    if-eqz v3, :cond_b

    if-nez p3, :cond_b

    iget-object v1, v1, Lm6/n;->d:Ljava/lang/String;

    new-instance v3, Lm6/j2;

    const/16 v5, 0xf

    invoke-direct {v3, v0, v2, v5}, Lm6/j2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;II)V

    const-string v2, "category"

    invoke-static {v1, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    invoke-virtual {v2}, Lm6/m6;->h0()J

    move-result-wide v11

    const-wide/16 v13, 0x0

    cmp-long v2, v11, v13

    if-lez v2, :cond_9

    const-string v1, " s"

    const-wide/16 v2, 0x3e7

    add-long/2addr v11, v2

    div-long/2addr v11, v6

    cmp-long v2, v11, v9

    if-gez v2, :cond_7

    goto :goto_4

    :cond_7
    move-wide v9, v11

    :goto_4
    const-wide/16 v2, 0x3c

    cmp-long v5, v9, v2

    if-ltz v5, :cond_8

    div-long v5, v9, v2

    rem-long/2addr v9, v2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v3, " min "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_5
    invoke-virtual {v2, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_6

    :cond_8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    goto :goto_5

    :goto_6
    const-string v2, "\u26d4 Too many wrong PINs. Try again in "

    invoke-static {v4, v0, v2, v1}, La0/h;->A(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_9
    const-string v2, "Locked Category: "

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "Enter your 4-digit Parental PIN to watch channels in \'"

    const-string v5, "\'"

    invoke-static {v4, v1, v5}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v5, v4

    const-string v4, "LOCKED \ud83d\udd12"

    new-instance v9, Lm6/u0;

    const-string v10, "ENTER 4-DIGIT PARENTAL PIN"

    const-string v11, "\u2022\u2022\u2022\u2022"

    const/16 v14, 0x12

    const/16 v15, 0x8

    const v12, 0x7f0800c6

    const/4 v13, 0x0

    invoke-direct/range {v9 .. v15}, Lm6/u0;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;II)V

    invoke-static {v9}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v7

    invoke-virtual {v7}, Lm6/m6;->V()Z

    move-result v7

    if-eqz v7, :cond_a

    const-string v8, "Forgot PIN"

    :cond_a
    new-instance v7, Lm6/x3;

    const/16 v9, 0xd

    invoke-direct {v7, v0, v9}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move-object v9, v5

    move-object v5, v6

    move-object v6, v8

    const-string v8, "Unlock Category"

    new-instance v11, Lm6/k4;

    invoke-direct {v11, v0, v1, v3}, Lm6/k4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Lm6/j2;)V

    const/16 v12, 0xc0

    const v1, 0x7f0800c6

    move-object v3, v9

    const v9, 0x7f080053

    const v10, 0x7f0800c6

    invoke-static/range {v0 .. v12}, Landroid/support/v4/media/session/b;->X(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lz6/a;Ljava/lang/String;IILz6/l;I)V

    return-void

    :cond_b
    invoke-static {v0}, Landroid/support/v4/media/session/b;->T(Lcom/harindra/iptvpro/PlayerActivity;)V

    sget-object v1, Lm6/x1;->LIVE_TV:Lm6/x1;

    invoke-virtual {v0, v1}, Lcom/harindra/iptvpro/PlayerActivity;->R(Lm6/x1;)V

    iget v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-eq v2, v1, :cond_e

    if-gt v2, v1, :cond_d

    iget-object v11, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-static {v11}, Lo6/k;->J(Ljava/util/List;)I

    move-result v11

    if-ne v1, v11, :cond_c

    if-nez v2, :cond_c

    goto :goto_7

    :cond_c
    move v1, v5

    goto :goto_8

    :cond_d
    :goto_7
    move v1, v4

    :goto_8
    iput-boolean v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->a1:Z

    iget v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    iput v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->d3:I

    :cond_e
    iput v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    iput v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->e3:I

    iput v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->N2:I

    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->O2:Z

    if-eqz v2, :cond_11

    if-nez p3, :cond_11

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->l2:Ljava/lang/String;

    const-string v11, "Auto"

    invoke-static {v2, v11}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_11

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz v2, :cond_10

    invoke-virtual {v2}, Ld1/k0;->E0()Lv0/p1;

    move-result-object v11

    const-string v12, "getTrackSelectionParameters(...)"

    invoke-static {v11, v12}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iget-boolean v12, v0, Lcom/harindra/iptvpro/PlayerActivity;->b1:Z

    check-cast v11, Lu1/k;

    new-instance v13, Lu1/j;

    invoke-direct {v13, v11}, Lu1/j;-><init>(Lu1/k;)V

    if-eqz v12, :cond_f

    const/16 v11, 0x780

    iput v11, v13, Lv0/o1;->a:I

    const/16 v11, 0x438

    iput v11, v13, Lv0/o1;->b:I

    const v11, 0x7a1200

    iput v11, v13, Lv0/o1;->d:I

    goto :goto_9

    :cond_f
    invoke-virtual {v13}, Lu1/j;->e()Lv0/o1;

    const v11, 0x7fffffff

    invoke-virtual {v13, v11}, Lv0/o1;->i(I)Lv0/o1;

    :goto_9
    new-instance v11, Lu1/k;

    invoke-direct {v11, v13}, Lu1/k;-><init>(Lu1/j;)V

    invoke-virtual {v2, v11}, Ld1/k0;->o(Lv0/p1;)V

    :cond_10
    iput-boolean v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->O2:Z

    :cond_11
    iput-boolean v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->s2:Z

    const-string v2, ""

    iput-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i2:Ljava/lang/String;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    sub-long v6, v11, v6

    iget-wide v13, v0, Lcom/harindra/iptvpro/PlayerActivity;->T0:J

    cmp-long v2, v6, v13

    if-gtz v2, :cond_12

    cmp-long v2, v13, v11

    if-gtz v2, :cond_12

    sub-long v6, v11, v13

    cmp-long v2, v6, v9

    if-gez v2, :cond_13

    :cond_12
    move-wide v6, v9

    :cond_13
    iput-wide v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->U0:J

    iput-wide v11, v0, Lcom/harindra/iptvpro/PlayerActivity;->V0:J

    if-eqz p3, :cond_14

    if-eqz v3, :cond_14

    const-string v2, "\ud83d\udd12 Locked \u2014 release to unlock"

    goto :goto_a

    :cond_14
    if-eqz p3, :cond_15

    const-string v2, "\u23e9 Browsing \u2014 release to play"

    goto :goto_a

    :cond_15
    const-string v2, "\u26a1 Zapping..."

    :goto_a
    iput-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->A()Landroid/widget/ProgressBar;

    move-result-object v2

    const/16 v3, 0x23

    invoke-virtual {v2, v3}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->P2:Lm6/d2;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->K2:Lm6/s1;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->J2:Lm6/s1;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-wide v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->N:J

    add-long/2addr v2, v9

    iput-wide v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->N:J

    const/4 v6, 0x7

    if-eqz p3, :cond_19

    iput-boolean v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->H2:Z

    iput-wide v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->G2:J

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->J2:Lm6/s1;

    iget-boolean v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->b1:Z

    if-eqz v3, :cond_16

    const-wide/16 v7, 0x140

    goto :goto_b

    :cond_16
    const-wide/16 v7, 0x104

    :goto_b
    invoke-virtual {v1, v2, v7, v8}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    sub-long/2addr v1, v11

    cmp-long v3, v1, v9

    if-gez v3, :cond_17

    goto :goto_c

    :cond_17
    move-wide v9, v1

    :goto_c
    iput-wide v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->W0:J

    invoke-static {v0, v4}, Lcom/bumptech/glide/c;->H(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    invoke-static {v0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_18

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->b3:Ljava/lang/String;

    const-string v2, "RECENT"

    invoke-static {v1, v2}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-static {v0, v6}, Ll4/f;->w(Lcom/harindra/iptvpro/PlayerActivity;I)V

    return-void

    :cond_18
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->s()Lm6/a0;

    move-result-object v1

    iget v0, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-virtual {v1, v0}, Lm6/a0;->l(I)V

    return-void

    :cond_19
    iput-boolean v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->H2:Z

    sget-object v7, Lm6/y7;->a:Lk7/e;

    iget-object v7, v1, Lm6/n;->e:Ljava/lang/String;

    const-string v13, "activeUrl"

    invoke-static {v7, v13}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v13, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    sget-object v13, Lo6/s;->k:Lo6/s;

    invoke-static {v7, v13}, Lm6/f1;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object v7

    sget-object v13, Lm6/y7;->c:Ljava/lang/Object;

    monitor-enter v13

    :try_start_0
    sput-object v7, Lm6/y7;->h:Ljava/lang/String;

    sget-object v14, Lm6/y7;->f:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v14}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    invoke-static {}, Lm6/y7;->e()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v13

    sget-object v13, Lm6/y7;->d:Lf7/g1;

    if-eqz v13, :cond_1a

    invoke-virtual {v13, v8}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    :cond_1a
    sget-object v13, Lm6/y7;->e:Lf7/g1;

    if-eqz v13, :cond_1b

    invoke-virtual {v13, v8}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    :cond_1b
    invoke-static {v7}, Lm6/y7;->k(Ljava/lang/String;)V

    if-eqz p2, :cond_1c

    invoke-static {v0, v5}, Lcom/bumptech/glide/c;->D(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    goto :goto_d

    :cond_1c
    iput-wide v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->G2:J

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->J2:Lm6/s1;

    const-wide/16 v13, 0x19

    invoke-virtual {v2, v3, v13, v14}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_d
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    sub-long/2addr v2, v11

    cmp-long v7, v2, v9

    if-gez v7, :cond_1d

    goto :goto_e

    :cond_1d
    move-wide v9, v2

    :goto_e
    iput-wide v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->W0:J

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->a3:Ljava/util/ArrayList;

    iget-object v3, v1, Lm6/n;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->a3:Ljava/util/ArrayList;

    iget-object v3, v1, Lm6/n;->a:Ljava/lang/String;

    invoke-virtual {v2, v5, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->a3:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v3, 0x14

    if-le v2, v3, :cond_1e

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->a3:Ljava/util/ArrayList;

    invoke-static {v2}, Lo6/k;->J(Ljava/util/List;)I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_1e
    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->R2:Lm6/s1;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->R2:Lm6/s1;

    const-wide/16 v9, 0x258

    invoke-virtual {v2, v3, v9, v10}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-static {v0, v5}, Lcom/bumptech/glide/c;->H(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    invoke-static {v0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->z()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1}, Lm6/n;->c()Ljava/lang/String;

    move-result-object v3

    iget-object v7, v1, Lm6/n;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/bumptech/glide/c;->p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Ln6/d;

    move-result-object v1

    if-eqz v1, :cond_1f

    iget-object v1, v1, Ln6/d;->k:Ljava/lang/Object;

    move-object v8, v1

    check-cast v8, Ljava/lang/String;

    :cond_1f
    const-string v1, "number"

    invoke-static {v3, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "name"

    invoke-static {v7, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-array v1, v4, [C

    const/16 v4, 0x30

    aput-char v4, v1, v5

    invoke-static {v3, v1}, Le7/e;->p0(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_20

    const-string v1, "0"

    :cond_20
    invoke-static {v7}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Channel "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v8}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_21

    const-string v4, ", now: "

    invoke-static {v1, v4, v3}, Lq3/e;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_21
    invoke-static {v2, v1}, Lcom/bumptech/glide/c;->a(Landroid/view/View;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_22

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->b3:Ljava/lang/String;

    const-string v2, "RECENT"

    invoke-static {v1, v2}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-static {v0, v6}, Ll4/f;->w(Lcom/harindra/iptvpro/PlayerActivity;I)V

    return-void

    :cond_22
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->s()Lm6/a0;

    move-result-object v1

    iget v0, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-virtual {v1, v0}, Lm6/a0;->l(I)V

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v13

    throw v0
.end method

.method public static F(Lx2/d;Lx2/l;Ly0/i;)V
    .locals 12

    iget-wide v0, p1, Lx2/l;->a:J

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v4, v0, v2

    const/4 v5, 0x0

    if-nez v4, :cond_0

    move v4, v5

    goto :goto_0

    :cond_0
    invoke-interface {p0, v0, v1}, Lx2/d;->a(J)I

    move-result v4

    const/4 v6, -0x1

    if-ne v4, v6, :cond_1

    invoke-interface {p0}, Lx2/d;->f()I

    move-result v4

    :cond_1
    if-lez v4, :cond_2

    add-int/lit8 v6, v4, -0x1

    invoke-interface {p0, v6}, Lx2/d;->b(I)J

    move-result-wide v6

    cmp-long v6, v6, v0

    if-nez v6, :cond_2

    add-int/lit8 v4, v4, -0x1

    :cond_2
    :goto_0
    cmp-long v2, v0, v2

    if-eqz v2, :cond_3

    invoke-interface {p0}, Lx2/d;->f()I

    move-result v2

    if-ge v4, v2, :cond_3

    invoke-interface {p0, v0, v1}, Lx2/d;->c(J)Ljava/util/List;

    move-result-object v11

    invoke-interface {p0, v4}, Lx2/d;->b(I)J

    move-result-wide v2

    invoke-interface {v11}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_3

    iget-wide v7, p1, Lx2/l;->a:J

    cmp-long v6, v7, v2

    if-gez v6, :cond_3

    new-instance v6, Lx2/a;

    sub-long v9, v2, v7

    invoke-direct/range {v6 .. v11}, Lx2/a;-><init>(JJLjava/util/List;)V

    invoke-interface {p2, v6}, Ly0/i;->accept(Ljava/lang/Object;)V

    const/4 v2, 0x1

    goto :goto_1

    :cond_3
    move v2, v5

    :goto_1
    move v3, v4

    :goto_2
    invoke-interface {p0}, Lx2/d;->f()I

    move-result v6

    if-ge v3, v6, :cond_4

    invoke-static {p0, v3, p2}, Lcom/bumptech/glide/c;->q(Lx2/d;ILy0/i;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_4
    iget-boolean p1, p1, Lx2/l;->b:Z

    if-eqz p1, :cond_7

    if-eqz v2, :cond_5

    add-int/lit8 v4, v4, -0x1

    :cond_5
    :goto_3
    if-ge v5, v4, :cond_6

    invoke-static {p0, v5, p2}, Lcom/bumptech/glide/c;->q(Lx2/d;ILy0/i;)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_6
    if-eqz v2, :cond_7

    new-instance v6, Lx2/a;

    invoke-interface {p0, v0, v1}, Lx2/d;->c(J)Ljava/util/List;

    move-result-object v11

    invoke-interface {p0, v4}, Lx2/d;->b(I)J

    move-result-wide v7

    invoke-interface {p0, v4}, Lx2/d;->b(I)J

    move-result-wide p0

    sub-long v9, v0, p0

    invoke-direct/range {v6 .. v11}, Lx2/a;-><init>(JJLjava/util/List;)V

    invoke-interface {p2, v6}, Ly0/i;->accept(Ljava/lang/Object;)V

    :cond_7
    return-void
.end method

.method public static final G(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    xor-int/lit8 v0, v0, 0x1

    iput-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    iget-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    if-eqz v0, :cond_0

    const-string v0, "\ud83d\udd12 Player Locked \u2014 Press OK or Menu to unlock"

    goto :goto_0

    :cond_0
    const-string v0, "\ud83d\udd13 Player Unlocked"

    :goto_0
    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public static final H(Lcom/harindra/iptvpro/PlayerActivity;Z)V
    .locals 18

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_11

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/Collection;->size()I

    move-result v1

    iget v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    if-ltz v2, :cond_11

    if-ge v2, v1, :cond_11

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->I()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1}, Lm6/n;->c()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v1, Lm6/n;->f:Ljava/lang/String;

    iget-object v5, v1, Lm6/n;->d:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->H()Landroid/widget/TextView;

    move-result-object v2

    iget-object v3, v1, Lm6/n;->c:Ljava/lang/String;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, 0x0

    const-string v3, "/"

    const-string v6, "  \u2022  CH "

    const-string v7, "Now: "

    const-string v8, "Live Broadcast"

    const/4 v9, 0x1

    const-string v11, " \u2022 "

    if-eqz p1, :cond_3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    const-string v12, "\ud83d\udd12"

    invoke-static {v4, v12, v2}, Le7/m;->P(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    invoke-static {v0, v1}, Lcom/bumptech/glide/c;->p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Ln6/d;

    move-result-object v10

    :goto_0
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->G()Landroid/widget/TextView;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->J()Landroid/widget/TextView;

    move-result-object v1

    if-eqz v10, :cond_2

    iget-object v2, v10, Ln6/d;->k:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    move-object v8, v2

    :cond_2
    :goto_1
    iget v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    add-int/2addr v2, v9

    iget-object v0, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_3
    invoke-static {v4}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v12

    const-string v13, "channelLogo"

    if-nez v12, :cond_5

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v12

    if-nez v12, :cond_5

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v12

    if-nez v12, :cond_5

    invoke-static {v0}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lh5/l;

    move-result-object v12

    invoke-virtual {v12, v0}, Lh5/l;->c(Li/k;)Lcom/bumptech/glide/m;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v14, Lcom/bumptech/glide/j;

    iget-object v15, v12, Lcom/bumptech/glide/m;->k:Lcom/bumptech/glide/b;

    const/16 v16, 0x0

    iget-object v10, v12, Lcom/bumptech/glide/m;->l:Landroid/content/Context;

    const-class v2, Landroid/graphics/drawable/Drawable;

    invoke-direct {v14, v15, v12, v2, v10}, Lcom/bumptech/glide/j;-><init>(Lcom/bumptech/glide/b;Lcom/bumptech/glide/m;Ljava/lang/Class;Landroid/content/Context;)V

    invoke-virtual {v14, v4}, Lcom/bumptech/glide/j;->A(Ljava/lang/Object;)Lcom/bumptech/glide/j;

    move-result-object v2

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->u2:Ln6/g;

    invoke-virtual {v4}, Ln6/g;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lk5/e;

    invoke-virtual {v2, v4}, Lcom/bumptech/glide/j;->v(Lk5/a;)Lcom/bumptech/glide/j;

    move-result-object v2

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->o0:Landroid/widget/ImageView;

    if-eqz v4, :cond_4

    invoke-virtual {v2, v4}, Lcom/bumptech/glide/j;->y(Landroid/widget/ImageView;)V

    goto :goto_2

    :cond_4
    invoke-static {v13}, La7/h;->h(Ljava/lang/String;)V

    throw v16

    :cond_5
    const/16 v16, 0x0

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->o0:Landroid/widget/ImageView;

    if-eqz v2, :cond_10

    const v4, 0x7f0800c5

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_2
    invoke-static {v0, v1}, Lcom/bumptech/glide/c;->p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Ln6/d;

    move-result-object v2

    invoke-static {v0, v1}, Lcom/bumptech/glide/c;->o(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Lm6/l0;

    move-result-object v4

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->i2:Ljava/lang/String;

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    const-string v12, ""

    if-lez v10, :cond_6

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->i2:Ljava/lang/String;

    invoke-static {v11, v10}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_3

    :cond_6
    move-object v10, v12

    :goto_3
    iget-object v13, v0, Lcom/harindra/iptvpro/PlayerActivity;->I2:Lm6/k9;

    if-nez v13, :cond_7

    invoke-static {v0}, Lcom/bumptech/glide/d;->l(Lcom/harindra/iptvpro/PlayerActivity;)Lm6/k9;

    move-result-object v13

    iput-object v13, v0, Lcom/harindra/iptvpro/PlayerActivity;->I2:Lm6/k9;

    :cond_7
    sget-object v14, Lm6/w5;->a:[I

    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    move-result v13

    aget v13, v14, v13

    if-eq v13, v9, :cond_a

    const/4 v12, 0x2

    if-eq v13, v12, :cond_9

    const/4 v12, 0x3

    if-ne v13, v12, :cond_8

    const-string v12, " \u2022 \ud83d\udd00 Favourites only"

    goto :goto_4

    :cond_8
    new-instance v0, Lb5/f0;

    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    throw v0

    :cond_9
    const-string v12, " \u2022 \ud83d\udd00 "

    const-string v13, " only"

    invoke-static {v12, v5, v13}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :cond_a
    :goto_4
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->G()Landroid/widget/TextView;

    move-result-object v13

    iget-object v14, v0, Lcom/harindra/iptvpro/PlayerActivity;->h2:Ljava/lang/String;

    iget-object v15, v0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    move/from16 v17, v9

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz v4, :cond_b

    iget-object v8, v4, Lm6/l0;->a:Ljava/lang/String;

    goto :goto_5

    :cond_b
    if-eqz v2, :cond_c

    iget-object v5, v2, Ln6/d;->k:Ljava/lang/Object;

    move-object v8, v5

    check-cast v8, Ljava/lang/String;

    :cond_c
    :goto_5
    if-eqz v4, :cond_d

    iget-object v2, v4, Lm6/l0;->b:Ljava/lang/String;

    goto :goto_6

    :cond_d
    if-eqz v2, :cond_e

    iget-object v2, v2, Ln6/d;->l:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    goto :goto_6

    :cond_e
    const-string v2, "Upcoming Show"

    :goto_6
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->J()Landroid/widget/TextView;

    move-result-object v5

    iget v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    add-int/lit8 v9, v9, 0x1

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    const-string v11, "  \u2022  Next: "

    invoke-static {v7, v8, v11, v2, v6}, Lq3/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz v4, :cond_f

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->j2:Ljava/lang/String;

    const-string v3, "\ud83d\udfe2"

    const/4 v5, 0x0

    invoke-static {v2, v3, v5}, Le7/m;->P(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->A()Landroid/widget/ProgressBar;

    move-result-object v2

    iget v3, v4, Lm6/l0;->e:I

    invoke-virtual {v2, v3}, Landroid/widget/ProgressBar;->setProgress(I)V

    :cond_f
    iget-object v1, v1, Lm6/n;->a:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/bumptech/glide/d;->J(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    return-void

    :cond_10
    invoke-static {v13}, La7/h;->h(Ljava/lang/String;)V

    throw v16

    :cond_11
    return-void
.end method

.method public static a(Landroid/view/View;Ljava/lang/String;)V
    .locals 2

    const-string v0, "text"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "getContext(...)"

    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "accessibility"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Landroid/view/accessibility/AccessibilityManager;

    if-eqz v1, :cond_1

    check-cast v0, Landroid/view/accessibility/AccessibilityManager;

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_2

    const/4 v0, 0x0

    goto :goto_1

    :cond_2
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    move-result v0

    :goto_1
    if-nez v0, :cond_3

    :goto_2
    return-void

    :cond_3
    invoke-virtual {p0, p1}, Landroid/view/View;->announceForAccessibility(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public static final b(Lcom/harindra/iptvpro/PlayerActivity;Lm6/l1;)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "mode"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    sget-object v0, Lm6/y7;->a:Lk7/e;

    invoke-static {p1}, Lm6/y7;->t(Lm6/l1;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v0

    iget-object v0, v0, Lm6/m6;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "performance_mode_id_v18"

    invoke-virtual {p1}, Lm6/l1;->f()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    sget-object v0, Lm6/l1;->LOW_MEMORY:Lm6/l1;

    if-ne p1, v0, :cond_1

    :try_start_0
    invoke-static {p0}, Lcom/bumptech/glide/b;->b(Landroid/content/Context;)Lcom/bumptech/glide/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/bumptech/glide/b;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    :goto_0
    sget-object v0, Lm6/w;->c:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {}, Lw0/h;->H()V

    :cond_1
    invoke-static {p0}, Ll3/e;->c(Lcom/harindra/iptvpro/PlayerActivity;)V

    invoke-static {p0}, Ll3/e;->e(Lcom/harindra/iptvpro/PlayerActivity;)V

    sget-object v0, Lm6/h;->Companion:Lm6/g;

    invoke-virtual {p1}, Lm6/l1;->o()Ljava/lang/String;

    move-result-object v1

    iget-boolean v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->b1:Z

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lm6/g;->a(Ljava/lang/String;Z)Lm6/h;

    move-result-object v0

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->m2:Lm6/h;

    const/4 v2, 0x0

    if-eq v0, v1, :cond_2

    const-string v1, "<set-?>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->m2:Lm6/h;

    const-string v1, "iptv_pro_prefs"

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "buffer_profile_id"

    invoke-virtual {v0}, Lm6/h;->a()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v0, 0x1

    invoke-static {p0, v0}, Lw0/h;->q(Lcom/harindra/iptvpro/PlayerActivity;Z)V

    :cond_2
    invoke-virtual {p1}, Lm6/l1;->r()Ljava/lang/String;

    move-result-object p1

    const-string v0, "\u26a1 Performance Mode: "

    invoke-static {v2, p0, v0, p1}, La0/h;->A(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static final c(III[B[B)Z
    .locals 4

    const-string v0, "a"

    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "b"

    invoke-static {p4, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-ge v1, p2, :cond_1

    add-int v2, v1, p0

    aget-byte v2, p3, v2

    add-int v3, v1, p1

    aget-byte v3, p4, v3

    if-eq v2, v3, :cond_0

    return v0

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method public static final d(JJJ)V
    .locals 4

    or-long v0, p2, p4

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    cmp-long v0, p2, p0

    if-gtz v0, :cond_0

    sub-long v0, p0, p2

    cmp-long v0, v0, p4

    if-ltz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/ArrayIndexOutOfBoundsException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "size="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, " offset="

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, " byteCount="

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p4, p5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static e(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .locals 0

    if-ne p0, p1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    if-nez p0, :cond_1

    const/4 p0, -0x1

    return p0

    :cond_1
    if-nez p1, :cond_2

    const/4 p0, 0x1

    return p0

    :cond_2
    invoke-interface {p0, p1}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method public static f(JJ)I
    .locals 11

    const-wide/16 v0, 0x0

    cmp-long v2, p0, v0

    const v3, -0x7fffffff

    if-lez v2, :cond_1

    cmp-long v2, p2, v0

    if-gtz v2, :cond_0

    goto :goto_0

    :cond_0
    const-wide/32 v6, 0x7a1200

    sget-object v10, Ljava/math/RoundingMode;->HALF_UP:Ljava/math/RoundingMode;

    move-wide v4, p0

    move-wide v8, p2

    invoke-static/range {v4 .. v10}, Ly0/k0;->d0(JJJLjava/math/RoundingMode;)J

    move-result-wide p0

    cmp-long p2, p0, v0

    if-lez p2, :cond_1

    const-wide/32 p2, 0x7fffffff

    cmp-long p2, p0, p2

    if-gtz p2, :cond_1

    long-to-int p0, p0

    return p0

    :cond_1
    :goto_0
    return v3
.end method

.method public static g(Landroid/view/View;Landroid/view/KeyEvent;)Z
    .locals 3

    sget-object v0, Le0/k0;->a:Ljava/util/WeakHashMap;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_0

    goto/16 :goto_1

    :cond_0
    sget-object v0, Le0/j0;->d:Ljava/util/ArrayList;

    const v0, 0x7f0a0109

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le0/j0;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    new-instance v1, Le0/j0;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v2, v1, Le0/j0;->a:Ljava/util/WeakHashMap;

    iput-object v2, v1, Le0/j0;->b:Landroid/util/SparseArray;

    iput-object v2, v1, Le0/j0;->c:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_1
    iget-object p0, v1, Le0/j0;->c:Ljava/lang/ref/WeakReference;

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    if-ne p0, p1, :cond_2

    goto :goto_1

    :cond_2
    new-instance p0, Ljava/lang/ref/WeakReference;

    invoke-direct {p0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p0, v1, Le0/j0;->c:Ljava/lang/ref/WeakReference;

    iget-object p0, v1, Le0/j0;->b:Landroid/util/SparseArray;

    if-nez p0, :cond_3

    new-instance p0, Landroid/util/SparseArray;

    invoke-direct {p0}, Landroid/util/SparseArray;-><init>()V

    iput-object p0, v1, Le0/j0;->b:Landroid/util/SparseArray;

    :cond_3
    iget-object p0, v1, Le0/j0;->b:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_4

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v0

    if-ltz v0, :cond_4

    invoke-virtual {p0, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/ref/WeakReference;

    invoke-virtual {p0, v0}, Landroid/util/SparseArray;->removeAt(I)V

    :cond_4
    if-nez v2, :cond_5

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    move-object v2, p0

    check-cast v2, Ljava/lang/ref/WeakReference;

    :cond_5
    if-eqz v2, :cond_8

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p1

    if-eqz p1, :cond_7

    const p1, 0x7f0a010a

    invoke-virtual {p0, p1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/ArrayList;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v1

    if-gez p1, :cond_6

    goto :goto_0

    :cond_6
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Ljava/lang/ClassCastException;

    invoke-direct {p0}, Ljava/lang/ClassCastException;-><init>()V

    throw p0

    :cond_7
    :goto_0
    return v1

    :cond_8
    :goto_1
    const/4 p0, 0x0

    return p0
.end method

.method public static h(Le0/i;Landroid/view/View;Landroid/view/Window$Callback;Landroid/view/KeyEvent;)Z
    .locals 7

    const/4 v0, 0x0

    if-nez p0, :cond_0

    goto/16 :goto_4

    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_1

    invoke-interface {p0, p3}, Le0/i;->b(Landroid/view/KeyEvent;)Z

    move-result p0

    return p0

    :cond_1
    instance-of v1, p2, Landroid/app/Activity;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_9

    check-cast p2, Landroid/app/Activity;

    invoke-virtual {p2}, Landroid/app/Activity;->onUserInteraction()V

    invoke-virtual {p2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/view/Window;->hasFeature(I)Z

    move-result p1

    if-eqz p1, :cond_5

    invoke-virtual {p2}, Landroid/app/Activity;->getActionBar()Landroid/app/ActionBar;

    move-result-object p1

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    const/16 v4, 0x52

    if-ne v1, v4, :cond_5

    if-eqz p1, :cond_5

    sget-boolean v1, Lcom/bumptech/glide/c;->a:Z

    if-nez v1, :cond_2

    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const-string v4, "onMenuKeyEvent"

    new-array v5, v3, [Ljava/lang/Class;

    const-class v6, Landroid/view/KeyEvent;

    aput-object v6, v5, v0

    invoke-virtual {v1, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    sput-object v1, Lcom/bumptech/glide/c;->b:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    sput-boolean v3, Lcom/bumptech/glide/c;->a:Z

    :cond_2
    sget-object v1, Lcom/bumptech/glide/c;->b:Ljava/lang/reflect/Method;

    if-eqz v1, :cond_4

    :try_start_1
    new-array v4, v3, [Ljava/lang/Object;

    aput-object p3, v4, v0

    invoke-virtual {v1, p1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_4
    :goto_0
    if-eqz v0, :cond_5

    goto :goto_1

    :cond_5
    invoke-virtual {p0, p3}, Landroid/view/Window;->superDispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_6

    goto :goto_1

    :cond_6
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    invoke-static {p0, p3}, Le0/k0;->b(Landroid/view/View;Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_7

    goto :goto_1

    :cond_7
    if-eqz p0, :cond_8

    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object v2

    :cond_8
    invoke-virtual {p3, p2, v2, p2}, Landroid/view/KeyEvent;->dispatch(Landroid/view/KeyEvent$Callback;Landroid/view/KeyEvent$DispatcherState;Ljava/lang/Object;)Z

    move-result v3

    :goto_1
    return v3

    :cond_9
    instance-of v1, p2, Landroid/app/Dialog;

    if-eqz v1, :cond_10

    check-cast p2, Landroid/app/Dialog;

    sget-boolean p0, Lcom/bumptech/glide/c;->c:Z

    if-nez p0, :cond_a

    :try_start_2
    const-class p0, Landroid/app/Dialog;

    const-string p1, "mOnKeyListener"

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    sput-object p0, Lcom/bumptech/glide/c;->d:Ljava/lang/reflect/Field;

    invoke-virtual {p0, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_2
    .catch Ljava/lang/NoSuchFieldException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    sput-boolean v3, Lcom/bumptech/glide/c;->c:Z

    :cond_a
    sget-object p0, Lcom/bumptech/glide/c;->d:Ljava/lang/reflect/Field;

    if-eqz p0, :cond_b

    :try_start_3
    invoke-virtual {p0, p2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/DialogInterface$OnKeyListener;
    :try_end_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_2

    :catch_3
    :cond_b
    move-object p0, v2

    :goto_2
    if-eqz p0, :cond_c

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result p1

    invoke-interface {p0, p2, p1, p3}, Landroid/content/DialogInterface$OnKeyListener;->onKey(Landroid/content/DialogInterface;ILandroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_c

    goto :goto_3

    :cond_c
    invoke-virtual {p2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    invoke-virtual {p0, p3}, Landroid/view/Window;->superDispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_d

    goto :goto_3

    :cond_d
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p0

    invoke-static {p0, p3}, Le0/k0;->b(Landroid/view/View;Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_e

    goto :goto_3

    :cond_e
    if-eqz p0, :cond_f

    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object v2

    :cond_f
    invoke-virtual {p3, p2, v2, p2}, Landroid/view/KeyEvent;->dispatch(Landroid/view/KeyEvent$Callback;Landroid/view/KeyEvent$DispatcherState;Ljava/lang/Object;)Z

    move-result v3

    :goto_3
    return v3

    :cond_10
    if-eqz p1, :cond_11

    invoke-static {p1, p3}, Le0/k0;->b(Landroid/view/View;Landroid/view/KeyEvent;)Z

    move-result p1

    if-nez p1, :cond_12

    :cond_11
    invoke-interface {p0, p3}, Le0/i;->b(Landroid/view/KeyEvent;)Z

    move-result p0

    if-eqz p0, :cond_13

    :cond_12
    return v3

    :cond_13
    :goto_4
    return v0
.end method

.method public static i(Lcom/google/crypto/tink/shaded/protobuf/j;)Ljava/lang/String;
    .locals 5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v1, 0x0

    :goto_0
    invoke-virtual {p0}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    move-result v2

    if-ge v1, v2, :cond_4

    invoke-virtual {p0, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->f(I)B

    move-result v2

    const/16 v3, 0x22

    if-eq v2, v3, :cond_3

    const/16 v3, 0x27

    if-eq v2, v3, :cond_2

    const/16 v3, 0x5c

    if-eq v2, v3, :cond_1

    packed-switch v2, :pswitch_data_0

    const/16 v4, 0x20

    if-lt v2, v4, :cond_0

    const/16 v4, 0x7e

    if-gt v2, v4, :cond_0

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_0
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    ushr-int/lit8 v3, v2, 0x6

    and-int/lit8 v3, v3, 0x3

    add-int/lit8 v3, v3, 0x30

    int-to-char v3, v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    ushr-int/lit8 v3, v2, 0x3

    and-int/lit8 v3, v3, 0x7

    add-int/lit8 v3, v3, 0x30

    int-to-char v3, v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    and-int/lit8 v2, v2, 0x7

    add-int/lit8 v2, v2, 0x30

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_0
    const-string v2, "\\r"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_1
    const-string v2, "\\f"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_2
    const-string v2, "\\v"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_3
    const-string v2, "\\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_4
    const-string v2, "\\t"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_5
    const-string v2, "\\b"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :pswitch_6
    const-string v2, "\\a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_1
    const-string v2, "\\\\"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_2
    const-string v2, "\\\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_3
    const-string v2, "\\\""

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_0

    :cond_4
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_data_0
    .packed-switch 0x7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static final j(Ll4/q;)Ll4/j;
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Ll4/j;

    iget-object v1, p0, Ll4/q;->a:Ljava/lang/String;

    iget p0, p0, Ll4/q;->t:I

    invoke-direct {v0, v1, p0}, Ll4/j;-><init>(Ljava/lang/String;I)V

    return-object v0
.end method

.method public static k(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 8

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    new-instance v1, Lw/l;

    invoke-direct {v1, v0, p0}, Lw/l;-><init>(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)V

    sget-object v2, Lw/o;->c:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    sget-object v3, Lw/o;->b:Ljava/util/WeakHashMap;

    invoke-virtual {v3, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/SparseArray;

    const/4 v4, 0x0

    if-eqz v3, :cond_3

    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-lez v5, :cond_3

    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lw/k;

    if-eqz v5, :cond_3

    iget-object v6, v5, Lw/k;->b:Landroid/content/res/Configuration;

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/res/Configuration;->equals(Landroid/content/res/Configuration;)Z

    move-result v6

    if-eqz v6, :cond_2

    if-nez p0, :cond_0

    iget v6, v5, Lw/k;->c:I

    if-eqz v6, :cond_1

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_4

    :cond_0
    :goto_0
    if-eqz p0, :cond_2

    iget v6, v5, Lw/k;->c:I

    invoke-virtual {p0}, Landroid/content/res/Resources$Theme;->hashCode()I

    move-result v7

    if-ne v6, v7, :cond_2

    :cond_1
    iget-object v3, v5, Lw/k;->a:Landroid/content/res/ColorStateList;

    monitor-exit v2

    goto :goto_1

    :cond_2
    invoke-virtual {v3, p1}, Landroid/util/SparseArray;->remove(I)V

    :cond_3
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v3, v4

    :goto_1
    if-eqz v3, :cond_4

    return-object v3

    :cond_4
    sget-object v2, Lw/o;->a:Ljava/lang/ThreadLocal;

    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/util/TypedValue;

    if-nez v3, :cond_5

    new-instance v3, Landroid/util/TypedValue;

    invoke-direct {v3}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_5
    const/4 v2, 0x1

    invoke-virtual {v0, p1, v3, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    iget v2, v3, Landroid/util/TypedValue;->type:I

    const/16 v3, 0x1c

    if-lt v2, v3, :cond_6

    const/16 v3, 0x1f

    if-gt v2, v3, :cond_6

    goto :goto_2

    :cond_6
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v2

    :try_start_1
    invoke-static {v0, v2, p0}, Lw/c;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_2

    :catch_0
    move-exception v2

    const-string v3, "ResourcesCompat"

    const-string v5, "Failed to inflate ColorStateList, leaving it to the framework"

    invoke-static {v3, v5, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_2
    if-eqz v4, :cond_7

    invoke-static {v1, p1, v4, p0}, Lw/o;->a(Lw/l;ILandroid/content/res/ColorStateList;Landroid/content/res/Resources$Theme;)V

    goto :goto_3

    :cond_7
    invoke-static {v0, p1, p0}, Lw/j;->b(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object v4

    :goto_3
    return-object v4

    :goto_4
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public static l(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    invoke-static {}, Lo/m2;->d()Lo/m2;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lo/m2;->f(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static m(Ljava/lang/Object;)Ljava/util/List;
    .locals 1

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const-string v0, "singletonList(...)"

    invoke-static {p0, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method

.method public static final n(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 10

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "input"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "label"

    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->W1:Ld/a;

    invoke-virtual {v0}, Ld/a;->h()V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->T1:Lf7/g1;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0, v1}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    invoke-static {p0}, La/a;->f(Lcom/harindra/iptvpro/PlayerActivity;)V

    sget-object v0, Lm6/n6;->M3U:Lm6/n6;

    iput-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    iput-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->e2:Ljava/lang/String;

    iput-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->f2:Ljava/lang/String;

    const/16 v0, 0x100

    invoke-static {p1, v0}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    const-string v2, "m3u_live_"

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "raw"

    invoke-static {v0, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/bumptech/glide/d;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez p4, :cond_1

    move-object p4, v7

    :cond_1
    const-string v0, "<set-?>"

    invoke-static {p4, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p4, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-static {p0}, Landroidx/lifecycle/i0;->a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;

    move-result-object p4

    new-instance v3, Lm6/c4;

    const/4 v9, 0x0

    move-object v5, p0

    move-object v8, p1

    move-object v6, p2

    move v4, p3

    invoke-direct/range {v3 .. v9}, Lm6/c4;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lr6/d;)V

    const/4 p0, 0x3

    invoke-static {p4, v1, v3, p0}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    move-result-object p0

    iput-object p0, v5, Lcom/harindra/iptvpro/PlayerActivity;->T1:Lf7/g1;

    return-void
.end method

.method public static final o(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Lm6/l0;
    .locals 2

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p1, Lm6/n;->c:Ljava/lang/String;

    iget-object v0, p1, Lm6/n;->g:Ljava/lang/String;

    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, p1, Lm6/n;->a:Ljava/lang/String;

    :cond_0
    invoke-static {v0}, Lm6/v8;->b(Ljava/lang/String;)Lm6/l0;

    move-result-object p1

    if-eqz p1, :cond_1

    return-object p1

    :cond_1
    invoke-static {p0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_2

    invoke-static {p0}, Lm6/v8;->b(Ljava/lang/String;)Lm6/l0;

    move-result-object p0

    if-eqz p0, :cond_2

    return-object p0

    :cond_2
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final p(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)Ln6/d;
    .locals 5

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "channel"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p1, Lm6/n;->c:Ljava/lang/String;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p1, Lm6/n;->g:Ljava/lang/String;

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v1, p1, Lm6/n;->a:Ljava/lang/String;

    :cond_1
    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ln6/d;

    if-eqz p1, :cond_2

    return-object p1

    :cond_2
    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v3, "ROOT"

    const-string v4, "toLowerCase(...)"

    invoke-static {v2, v3, v1, v2, v4}, Lq3/e;->f(Ljava/util/Locale;Ljava/lang/String;Ljava/lang/String;Ljava/util/Locale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ln6/d;

    if-eqz p1, :cond_3

    return-object p1

    :cond_3
    invoke-static {v1}, Lm6/v8;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_4

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ln6/d;

    if-eqz p1, :cond_4

    return-object p1

    :cond_4
    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v4}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ln6/d;

    if-eqz p1, :cond_5

    return-object p1

    :cond_5
    invoke-static {v0}, Lm6/v8;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_6

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ln6/d;

    if-eqz p0, :cond_6

    return-object p0

    :cond_6
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static q(Lx2/d;ILy0/i;)V
    .locals 6

    invoke-interface {p0, p1}, Lx2/d;->b(I)J

    move-result-wide v1

    invoke-interface {p0, v1, v2}, Lx2/d;->c(J)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {p0}, Lx2/d;->f()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-eq p1, v0, :cond_2

    add-int/lit8 v0, p1, 0x1

    invoke-interface {p0, v0}, Lx2/d;->b(I)J

    move-result-wide v3

    invoke-interface {p0, p1}, Lx2/d;->b(I)J

    move-result-wide p0

    sub-long/2addr v3, p0

    const-wide/16 p0, 0x0

    cmp-long p0, v3, p0

    if-lez p0, :cond_1

    new-instance v0, Lx2/a;

    invoke-direct/range {v0 .. v5}, Lx2/a;-><init>(JJLjava/util/List;)V

    invoke-interface {p2, v0}, Ly0/i;->accept(Ljava/lang/Object;)V

    :cond_1
    :goto_0
    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    throw p0
.end method

.method public static final r(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)V
    .locals 9

    invoke-static {p0, p1, p2}, Lcom/harindra/iptvpro/ultra/Ultra;->onPlayRequest(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "targetUrl"

    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-eqz v1, :cond_a

    const/4 v0, 0x1

    if-nez p2, :cond_2

    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    invoke-static {v2, p1}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v1}, Ld1/k0;->D()I

    move-result v2

    const/4 v3, 0x3

    if-eq v2, v3, :cond_1

    invoke-virtual {v1}, Ld1/k0;->D()I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_2

    :cond_1
    invoke-virtual {v1, v0}, Ld1/k0;->i(Z)V

    return-void

    :cond_2
    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->q2:Ljava/lang/String;

    const-string v2, ""

    iput-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->A2:Ljava/lang/String;

    const/4 v2, 0x0

    if-nez p2, :cond_6

    iget-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->E1:Lm6/x1;

    sget-object v3, Lm6/x1;->LIVE_TV:Lm6/x1;

    if-ne p2, v3, :cond_6

    sget-object p2, Lm6/y7;->a:Lk7/e;

    sget-object p2, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    sget-object p2, Lo6/s;->k:Lo6/s;

    invoke-static {p1, p2}, Lm6/f1;->c(Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    sget-object v3, Lm6/y7;->c:Ljava/lang/Object;

    monitor-enter v3

    :try_start_0
    sget-object v4, Lm6/y7;->l:Lm6/t7;

    if-nez v4, :cond_3

    sget-object p2, Lm6/y7;->s:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    monitor-exit v3

    goto :goto_2

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_1

    :cond_3
    :try_start_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    iget-wide v7, v4, Lm6/t7;->f:J

    sub-long/2addr v5, v7

    iget-object v7, v4, Lm6/t7;->a:Ljava/lang/String;

    invoke-static {v7, p2}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_4

    iget-object p2, v4, Lm6/t7;->e:Lr1/a;

    if-eqz p2, :cond_4

    iget p2, v4, Lm6/t7;->g:I

    if-lez p2, :cond_4

    const-wide/16 v7, 0x0

    cmp-long p2, v7, v5

    if-gtz p2, :cond_4

    const-wide/16 v7, 0x1d4d

    cmp-long p2, v5, v7

    if-gez p2, :cond_4

    sput-object v2, Lm6/y7;->l:Lm6/t7;

    sget-object p2, Lm6/s7;->HANDED_OFF:Lm6/s7;

    sput-object p2, Lm6/y7;->k:Lm6/s7;

    sget-object p2, Lm6/y7;->r:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    iget-object v2, v4, Lm6/t7;->e:Lr1/a;

    goto :goto_0

    :cond_4
    const-wide/16 v7, 0x1d4c

    cmp-long p2, v5, v7

    if-lez p2, :cond_5

    sput-object v2, Lm6/y7;->l:Lm6/t7;

    :cond_5
    sget-object p2, Lm6/y7;->s:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_1
    monitor-exit v3

    throw p0

    :cond_6
    :goto_2
    if-eqz v2, :cond_7

    iput-boolean v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->M:Z

    invoke-virtual {v1}, Ld1/k0;->I1()V

    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1}, Ld1/k0;->I1()V

    const/4 v3, -0x1

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v6, 0x1

    invoke-virtual/range {v1 .. v6}, Ld1/k0;->A1(Ljava/util/List;IJZ)V

    invoke-virtual {v1}, Ld1/k0;->b()V

    invoke-virtual {v1, v0}, Ld1/k0;->i(Z)V

    return-void

    :cond_7
    const/4 p2, 0x0

    iput-boolean p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->M:Z

    sget-object p2, Lm6/y7;->a:Lk7/e;

    invoke-static {p1}, Lm6/y7;->c(Ljava/lang/String;)Lv0/k0;

    move-result-object p2

    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->K:Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;

    iget-object p0, p0, Lcom/harindra/iptvpro/PlayerActivity;->L:Lr1/o;

    if-eqz v2, :cond_8

    invoke-static {p1}, Lm6/y7;->i(Ljava/lang/String;)Lm6/u7;

    move-result-object p1

    sget-object v3, Lm6/u7;->HLS:Lm6/u7;

    if-ne p1, v3, :cond_8

    invoke-virtual {v2, p2}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->e(Lv0/k0;)Lj1/m;

    move-result-object p0

    invoke-virtual {v1}, Ld1/k0;->I1()V

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1}, Ld1/k0;->I1()V

    const/4 v3, -0x1

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v6, 0x1

    invoke-virtual/range {v1 .. v6}, Ld1/k0;->A1(Ljava/util/List;IJZ)V

    goto :goto_3

    :cond_8
    if-eqz p0, :cond_9

    invoke-virtual {p0, p2}, Lr1/o;->c(Lv0/k0;)Lr1/a;

    move-result-object p0

    invoke-virtual {v1}, Ld1/k0;->I1()V

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1}, Ld1/k0;->I1()V

    const/4 v3, -0x1

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v6, 0x1

    invoke-virtual/range {v1 .. v6}, Ld1/k0;->A1(Ljava/util/List;IJZ)V

    goto :goto_3

    :cond_9
    invoke-virtual {v1, p2}, Le6/e;->G0(Lv0/k0;)V

    :goto_3
    invoke-virtual {v1}, Ld1/k0;->b()V

    invoke-virtual {v1, v0}, Ld1/k0;->i(Z)V

    :cond_a
    return-void
.end method

.method public static s(Ly0/u;III)I
    .locals 7

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v0, p3}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/16 v1, 0x1f

    const/4 v2, 0x1

    if-gt v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, Landroid/support/v4/media/session/b;->g(Z)V

    shl-int v0, v2, p1

    sub-int/2addr v0, v2

    shl-int v1, v2, p2

    sub-int/2addr v1, v2

    int-to-long v3, v0

    int-to-long v5, v1

    add-long/2addr v3, v5

    long-to-int v5, v3

    int-to-long v5, v5

    cmp-long v3, v3, v5

    if-nez v3, :cond_6

    shl-int/2addr v2, p3

    int-to-long v2, v2

    add-long/2addr v5, v2

    long-to-int v2, v5

    int-to-long v2, v2

    cmp-long v2, v5, v2

    if-nez v2, :cond_5

    invoke-virtual {p0}, Ly0/u;->b()I

    move-result v2

    if-ge v2, p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p0, p1}, Ly0/u;->g(I)I

    move-result p1

    if-ne p1, v0, :cond_4

    invoke-virtual {p0}, Ly0/u;->b()I

    move-result v0

    if-ge v0, p2, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {p0, p2}, Ly0/u;->g(I)I

    move-result p2

    add-int/2addr p1, p2

    if-ne p2, v1, :cond_4

    invoke-virtual {p0}, Ly0/u;->b()I

    move-result p2

    if-ge p2, p3, :cond_3

    :goto_1
    const/4 p0, -0x1

    return p0

    :cond_3
    invoke-virtual {p0, p3}, Ly0/u;->g(I)I

    move-result p0

    add-int/2addr p0, p1

    return p0

    :cond_4
    return p1

    :cond_5
    new-instance p0, Ljava/lang/ArithmeticException;

    invoke-direct {p0}, Ljava/lang/ArithmeticException;-><init>()V

    throw p0

    :cond_6
    new-instance p0, Ljava/lang/ArithmeticException;

    invoke-direct {p0}, Ljava/lang/ArithmeticException;-><init>()V

    throw p0
.end method

.method public static t(Lx0/a;)V
    .locals 5

    const v0, -0x800001

    iput v0, p0, Lx0/a;->k:F

    const/high16 v0, -0x80000000

    iput v0, p0, Lx0/a;->j:I

    iget-object v0, p0, Lx0/a;->a:Ljava/lang/CharSequence;

    instance-of v1, v0, Landroid/text/Spanned;

    if-eqz v1, :cond_3

    instance-of v1, v0, Landroid/text/Spannable;

    if-nez v1, :cond_0

    invoke-static {v0}, Landroid/text/SpannableString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannableString;

    move-result-object v0

    iput-object v0, p0, Lx0/a;->a:Ljava/lang/CharSequence;

    const/4 v0, 0x0

    iput-object v0, p0, Lx0/a;->b:Landroid/graphics/Bitmap;

    :cond_0
    iget-object p0, p0, Lx0/a;->a:Ljava/lang/CharSequence;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Landroid/text/Spannable;

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const-class v1, Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-interface {p0, v2, v0, v1}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    array-length v1, v0

    :goto_0
    if-ge v2, v1, :cond_3

    aget-object v3, v0, v2

    instance-of v4, v3, Landroid/text/style/AbsoluteSizeSpan;

    if-nez v4, :cond_1

    instance-of v4, v3, Landroid/text/style/RelativeSizeSpan;

    if-eqz v4, :cond_2

    :cond_1
    invoke-interface {p0, v3}, Landroid/text/Spannable;->removeSpan(Ljava/lang/Object;)V

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method

.method public static u(Landroid/net/Uri;)Landroid/net/Uri;
    .locals 6

    invoke-virtual {p0}, Landroid/net/Uri;->isHierarchical()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "CMCD"

    invoke-virtual {p0, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri$Builder;->clearQuery()Landroid/net/Uri$Builder;

    invoke-virtual {p0}, Landroid/net/Uri;->getQueryParameterNames()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {p0, v3}, Landroid/net/Uri;->getQueryParameters(Ljava/lang/String;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v1, v3, v5}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    :cond_2
    return-object p0
.end method

.method public static v(IFII)F
    .locals 2

    const v0, -0x800001

    cmpl-float v1, p1, v0

    if-nez v1, :cond_0

    return v0

    :cond_0
    if-eqz p0, :cond_3

    const/4 p3, 0x1

    if-eq p0, p3, :cond_2

    const/4 p2, 0x2

    if-eq p0, p2, :cond_1

    return v0

    :cond_1
    return p1

    :cond_2
    int-to-float p0, p2

    :goto_0
    mul-float/2addr p1, p0

    return p1

    :cond_3
    int-to-float p0, p3

    goto :goto_0
.end method

.method public static final w(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 30

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    if-nez v1, :cond_0

    return-void

    :cond_0
    new-instance v9, Ljava/util/ArrayList;

    const/16 v2, 0xe

    invoke-direct {v9, v2}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v10, Lm6/v0;

    new-instance v2, Lm6/s2;

    invoke-direct {v2, v1, v0}, Lm6/s2;-><init>(Ld1/k0;Lcom/harindra/iptvpro/PlayerActivity;)V

    const v11, 0x7f0800d4

    const-string v12, "Sync to Live Broadcast Edge"

    const-string v13, "Jump directly to real-time live edge with zero delay"

    const-string v14, "ZERO DELAY"

    const/4 v15, 0x0

    move-object/from16 v16, v2

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v2, Ln6/h;

    const-string v3, "Video Quality: Auto"

    const-string v4, "Smart 1080p / 8 Mbps Low-RAM Hardware Guard"

    const/4 v10, 0x0

    invoke-direct {v2, v3, v4, v10}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v3, Ln6/h;

    const/16 v4, 0x780

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/16 v5, 0x438

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    new-instance v6, Ln6/d;

    invoke-direct {v6, v4, v5}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v4, "Video Quality: 1080p Full HD"

    const-string v5, "1920x1080 \u2022 Maximum Crystal Sharpness"

    invoke-direct {v3, v4, v5, v6}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v4, Ln6/h;

    const/16 v5, 0x500

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/16 v6, 0x2d0

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v7, Ln6/d;

    invoke-direct {v7, v5, v6}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v5, "Video Quality: 720p HD"

    const-string v6, "1280x720 \u2022 Recommended for 512MB RAM Smart TVs"

    invoke-direct {v4, v5, v6, v7}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v5, Ln6/h;

    const/16 v6, 0x356

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/16 v7, 0x1e0

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    new-instance v8, Ln6/d;

    invoke-direct {v8, v6, v7}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v6, "Video Quality: 480p SD"

    const-string v7, "854x480 \u2022 Fast Zap & Mobile Data Saver"

    invoke-direct {v5, v6, v7, v8}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v6, Ln6/h;

    const/16 v7, 0x280

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/16 v8, 0x168

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    new-instance v11, Ln6/d;

    invoke-direct {v11, v7, v8}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const-string v7, "Video Quality: 360p Eco"

    const-string v8, "640x360 \u2022 Ultra Low Bandwidth Mode"

    invoke-direct {v6, v7, v8, v11}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    const/4 v7, 0x5

    new-array v7, v7, [Ln6/h;

    const/4 v11, 0x0

    aput-object v2, v7, v11

    const/4 v12, 0x1

    aput-object v3, v7, v12

    const/4 v2, 0x2

    aput-object v4, v7, v2

    const/4 v3, 0x3

    aput-object v5, v7, v3

    const/4 v4, 0x4

    aput-object v6, v7, v4

    invoke-static {v7}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const-string v13, "toUpperCase(...)"

    const-string v14, "ROOT"

    if-eqz v6, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ln6/h;

    iget-object v7, v6, Ln6/h;->k:Ljava/io/Serializable;

    move-object/from16 v17, v7

    check-cast v17, Ljava/lang/String;

    iget-object v7, v6, Ln6/h;->l:Ljava/io/Serializable;

    move-object/from16 v18, v7

    check-cast v18, Ljava/lang/String;

    iget-object v6, v6, Ln6/h;->m:Ljava/lang/Object;

    check-cast v6, Ln6/d;

    if-nez v6, :cond_1

    const-string v7, "Auto"

    goto :goto_1

    :cond_1
    iget-object v7, v6, Ln6/d;->l:Ljava/lang/Object;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v7, "p"

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_1
    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->l2:Ljava/lang/String;

    invoke-static {v8, v7}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v20

    new-instance v15, Lm6/v0;

    if-eqz v20, :cond_2

    const-string v7, "ACTIVE \u2713"

    :goto_2
    move-object/from16 v19, v7

    goto :goto_3

    :cond_2
    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v8, v14}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v7, v8}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v13}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_2

    :goto_3
    new-instance v7, Lm6/y2;

    invoke-direct {v7, v1, v6, v0, v11}, Lm6/y2;-><init>(Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Object;I)V

    const v16, 0x7f0800db

    move-object/from16 v21, v7

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v5

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v5, v6}, Lm6/m6;->Q(Ljava/lang/String;)I

    move-result v5

    new-instance v15, Lm6/v0;

    const-string v6, "\u23f1\ufe0f Subtitle Delay: +"

    const-string v7, "ms (Fine +100ms / Reset)"

    invoke-static {v5, v6, v7}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    const-string v6, "+"

    const-string v7, "ms"

    invoke-static {v5, v6, v7}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    if-lez v5, :cond_4

    move/from16 v20, v12

    goto :goto_4

    :cond_4
    move/from16 v20, v11

    :goto_4
    new-instance v8, Lm6/j2;

    invoke-direct {v8, v5, v0, v2}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const v16, 0x7f0800d6

    const-string v18, "Generation-safe cue delay (auto-cancels on seek/pause/zap) \u2022 Tap for +100ms, or reset below"

    move-object/from16 v21, v8

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v16, Lm6/v0;

    if-lez v5, :cond_5

    const-string v2, "Tap to jump +500ms (cycles back to 0ms after 3000ms)"

    :goto_5
    move-object/from16 v19, v2

    goto :goto_6

    :cond_5
    const-string v2, "Currently 0ms (synced)"

    goto :goto_5

    :goto_6
    if-lez v5, :cond_6

    const-string v2, "COARSE"

    :goto_7
    move-object/from16 v20, v2

    goto :goto_8

    :cond_6
    const-string v2, "0ms"

    goto :goto_7

    :goto_8
    new-instance v2, Lm6/j2;

    invoke-direct {v2, v5, v0, v3}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v21, 0x0

    const v17, 0x7f0800d6

    const-string v18, "\u23f1\ufe0f Subtitle Delay Coarse (+500ms) / Reset to 0ms"

    move-object/from16 v22, v2

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v2, v16

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->m(Ljava/lang/String;)I

    move-result v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->l3:Lm6/b;

    iget-object v3, v3, Lm6/b;->n:Lw0/j;

    sget-object v8, Lw0/j;->e:Lw0/j;

    invoke-static {v3, v8}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    new-instance v15, Lm6/v0;

    const-string v8, "\ud83c\udf9a\ufe0f Real PCM Audio Delay: +"

    const-string v12, "ms (Fine +25ms)"

    invoke-static {v2, v8, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    if-nez v3, :cond_7

    const-string v8, "Active on Media3 AudioDelayProcessor (0\u2013500ms live PCM ring buffer) \u2022 Tap for +25ms"

    :goto_9
    move-object/from16 v18, v8

    goto :goto_a

    :cond_7
    const-string v8, "Saved (+"

    const-string v12, "ms); applies automatically to PCM streams (hardware bitstream passthrough bypasses PCM)"

    invoke-static {v2, v8, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_9

    :goto_a
    if-nez v3, :cond_8

    const-string v3, "ms LIVE"

    invoke-static {v2, v6, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_b
    move-object/from16 v19, v3

    goto :goto_c

    :cond_8
    invoke-static {v2, v6, v7}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_b

    :goto_c
    if-lez v2, :cond_9

    const/16 v20, 0x1

    goto :goto_d

    :cond_9
    move/from16 v20, v11

    :goto_d
    new-instance v3, Lm6/j2;

    invoke-direct {v3, v2, v0, v4}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const v16, 0x7f0800bf

    move-object/from16 v21, v3

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-lez v2, :cond_a

    new-instance v23, Lm6/v0;

    const-string v3, "ms) and subtitle (+"

    const-string v4, "ms) offsets"

    const-string v6, "Immediately reset both audio (+"

    invoke-static {v2, v5, v6, v3, v4}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v26

    new-instance v2, Lm6/l2;

    const/16 v3, 0x15

    invoke-direct {v2, v0, v3}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v28, 0x0

    const v24, 0x7f0800d7

    const-string v25, "\u21ba Reset Audio & Subtitle Delays to 0ms"

    const-string v27, "RESET 0ms"

    move-object/from16 v29, v2

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v2, v23

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    invoke-static {v0}, Lc4/b0;->o(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lm6/m6;->Y(Ljava/lang/String;)Z

    move-result v3

    new-instance v15, Lm6/v0;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    const/16 v5, 0x3e

    if-eqz v4, :cond_b

    const-string v4, "\ud83d\udd07 Hardware Bitstream Passthrough: Not Supported"

    :goto_e
    move-object/from16 v17, v4

    goto :goto_f

    :cond_b
    const-string v4, "/"

    invoke-static {v2, v4, v10, v5}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object v4

    const-string v6, "\ud83d\udd0a Hardware Bitstream Capabilities: "

    invoke-static {v6, v4}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_e

    :goto_f
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_c

    const-string v4, "TV audio output reports PCM stereo only (AC3/DTS/TrueHD passthrough unavailable)"

    :goto_10
    move-object/from16 v18, v4

    goto :goto_11

    :cond_c
    const-string v4, ", "

    invoke-static {v2, v4, v10, v5}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "Verified via AudioManager.getDevices: "

    const-string v6, " (separate from Audio Offload)"

    invoke-static {v5, v4, v6}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_10

    :goto_11
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_d

    const-string v4, "PCM ONLY"

    :goto_12
    move-object/from16 v19, v4

    goto :goto_13

    :cond_d
    const-string v4, "VERIFIED \u2713"

    goto :goto_12

    :goto_13
    new-instance v4, Lm6/a1;

    const/16 v5, 0xc

    invoke-direct {v4, v5}, Lm6/a1;-><init>(I)V

    const/16 v20, 0x0

    const v16, 0x7f0800bf

    move-object/from16 v21, v4

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v23, Lm6/v0;

    if-eqz v3, :cond_e

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_e

    const-string v4, "ENABLED"

    goto :goto_14

    :cond_e
    const-string v4, "DISABLED"

    :goto_14
    const-string v6, "\u26a1 Media3 Audio Offload: "

    invoke-virtual {v6, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_f

    const-string v4, "Disabled automatically \u2014 device reports no hardware offload/passthrough codecs"

    :goto_15
    move-object/from16 v26, v4

    goto :goto_16

    :cond_f
    const-string v4, "Uses TrackSelectionParameters.AudioOffloadPreferences (disables PCM Audio Delay when active)"

    goto :goto_15

    :goto_16
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v4

    const-string v12, "OFF"

    const-string v15, "ON \u2713"

    if-eqz v4, :cond_10

    const-string v4, "UNSUPPORTED"

    move-object/from16 v27, v4

    goto :goto_17

    :cond_10
    if-eqz v3, :cond_11

    move-object/from16 v27, v15

    goto :goto_17

    :cond_11
    move-object/from16 v27, v12

    :goto_17
    if-eqz v3, :cond_12

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_12

    const/16 v28, 0x1

    goto :goto_18

    :cond_12
    move/from16 v28, v11

    :goto_18
    new-instance v4, Lm6/b5;

    invoke-direct {v4, v2, v0, v3, v1}, Lm6/b5;-><init>(Ljava/util/List;Lcom/harindra/iptvpro/PlayerActivity;ZLd1/k0;)V

    const v24, 0x7f0800bf

    move-object/from16 v29, v4

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v2, v23

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v0}, Lc4/b0;->n(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Ld1/k0;->I1()V

    iget-object v3, v1, Ld1/k0;->d0:Lv0/t;

    invoke-static {v0, v3}, Lc4/b0;->m(Lcom/harindra/iptvpro/PlayerActivity;Lv0/t;)Ljava/lang/String;

    move-result-object v3

    new-instance v23, Lm6/v0;

    const-string v4, "\u2728 Video Format & HDR: Stream="

    const-string v6, " \u2022 TV="

    invoke-static {v4, v3, v6, v2}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    new-instance v2, Lm6/a1;

    invoke-direct {v2, v5}, Lm6/a1;-><init>(I)V

    const/16 v28, 0x0

    const v24, 0x7f0800db

    const-string v26, "Verified directly from Media3 ColorInfo & Display.HdrCapabilities (zero fake HDR claims)"

    move-object/from16 v29, v2

    move-object/from16 v27, v3

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v2, v23

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ld1/k0;->F()Lv0/r1;

    move-result-object v2

    const-string v3, "getCurrentTracks(...)"

    invoke-static {v2, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v4, v3}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lm6/n;

    if-eqz v3, :cond_13

    iget-object v3, v3, Lm6/n;->a:Ljava/lang/String;

    move-object v4, v3

    goto :goto_19

    :cond_13
    move-object v4, v10

    :goto_19
    iget-object v2, v2, Lv0/r1;->a:Lr5/l0;

    invoke-virtual {v2, v11}, Lr5/l0;->q(I)Lr5/j0;

    move-result-object v2

    const-string v3, "iterator(...)"

    invoke-static {v2, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    :goto_1a
    invoke-virtual {v2}, Lr5/a;->hasNext()Z

    move-result v5

    const-string v6, " \u2022 "

    if-eqz v5, :cond_1f

    invoke-virtual {v2}, Lr5/a;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lv0/q1;

    iget-object v7, v5, Lv0/q1;->b:Lv0/k1;

    move-object v8, v2

    iget-object v2, v5, Lv0/q1;->b:Lv0/k1;

    iget v7, v7, Lv0/k1;->c:I

    const/4 v10, 0x1

    if-ne v7, v10, :cond_1e

    move v7, v11

    :goto_1b
    iget-object v10, v5, Lv0/q1;->d:[I

    array-length v10, v10

    if-ge v7, v10, :cond_1e

    invoke-virtual {v5, v7}, Lv0/q1;->a(I)Z

    move-result v10

    if-eqz v10, :cond_1d

    iget v10, v5, Lv0/q1;->a:I

    move v7, v11

    :goto_1c
    if-ge v7, v10, :cond_1c

    iget-object v11, v2, Lv0/k1;->d:[Lv0/t;

    aget-object v11, v11, v7

    const-string v0, "getTrackFormat(...)"

    invoke-static {v11, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, v11, Lv0/t;->d:Ljava/lang/String;

    move-object/from16 v18, v1

    if-eqz v0, :cond_16

    new-instance v1, Ljava/util/Locale;

    invoke-direct {v1, v0}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/util/Locale;->getDisplayLanguage()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_16

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v19

    if-eqz v19, :cond_14

    const/4 v1, 0x0

    :cond_14
    if-nez v1, :cond_15

    goto :goto_1e

    :cond_15
    :goto_1d
    move-object/from16 v19, v0

    goto :goto_1f

    :cond_16
    :goto_1e
    const-string v1, "Track "

    invoke-static {v1, v3}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    goto :goto_1d

    :goto_1f
    iget-object v0, v11, Lv0/t;->b:Ljava/lang/String;

    if-eqz v0, :cond_18

    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v20

    if-nez v20, :cond_17

    goto :goto_20

    :cond_17
    const/4 v0, 0x0

    :goto_20
    if-nez v0, :cond_19

    :cond_18
    const-string v0, "Broadcast Audio"

    :cond_19
    iget v11, v11, Lv0/t;->J:I

    move-object/from16 v20, v4

    if-lez v11, :cond_1a

    const-string v4, "ch"

    invoke-static {v4, v11}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    goto :goto_21

    :cond_1a
    const-string v4, "Stereo"

    :goto_21
    iget-object v11, v5, Lv0/q1;->e:[Z

    aget-boolean v28, v11, v7

    const-string v11, "getMediaTrackGroup(...)"

    invoke-static {v2, v11}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v23, Lm6/v0;

    new-instance v11, Ljava/lang/StringBuilder;

    move-object/from16 v21, v2

    const-string v2, "Audio Track "

    invoke-direct {v11, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, " \u2022 Auto-saved for this channel"

    invoke-virtual {v2, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v26

    if-eqz v28, :cond_1b

    const-string v2, "PLAYING \u2713"

    :goto_22
    move-object/from16 v27, v2

    goto :goto_23

    :cond_1b
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v2, v14}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v13}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_22

    :goto_23
    new-instance v29, Lm6/t2;

    move-object/from16 v2, v19

    move-object/from16 v19, v5

    move-object v5, v2

    move v11, v3

    move v3, v7

    move-object/from16 v4, v20

    move-object/from16 v2, v21

    move-object v7, v1

    move/from16 v20, v10

    move-object/from16 v1, v18

    move-object v10, v6

    move-object/from16 v18, v8

    move-object/from16 v6, p0

    move-object v8, v0

    move-object/from16 v0, v29

    invoke-direct/range {v0 .. v8}, Lm6/t2;-><init>(Ld1/k0;Lv0/k1;ILjava/lang/String;Ljava/lang/String;Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Ljava/lang/String;)V

    move-object v0, v6

    const v24, 0x7f0800bf

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v5, v23

    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v5, v11, 0x1

    add-int/lit8 v7, v3, 0x1

    move v3, v5

    move-object v6, v10

    move-object/from16 v8, v18

    move-object/from16 v5, v19

    move/from16 v10, v20

    const/4 v11, 0x0

    goto/16 :goto_1c

    :cond_1c
    move v11, v3

    move-object v2, v8

    :goto_24
    const/4 v10, 0x0

    const/4 v11, 0x0

    goto/16 :goto_1a

    :cond_1d
    move-object/from16 v19, v5

    move-object v10, v6

    move-object/from16 v18, v8

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x0

    goto/16 :goto_1b

    :cond_1e
    move-object/from16 v18, v8

    move-object/from16 v2, v18

    goto :goto_24

    :cond_1f
    move-object v10, v6

    new-instance v23, Lm6/v0;

    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->k2:Z

    if-eqz v2, :cond_20

    move-object/from16 v27, v15

    goto :goto_25

    :cond_20
    move-object/from16 v27, v12

    :goto_25
    new-instance v3, Lm6/s2;

    invoke-direct {v3, v0, v1}, Lm6/s2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ld1/k0;)V

    const v24, 0x7f0800d6

    const-string v25, "Subtitles / Closed Captions"

    const-string v26, "Toggle DVB / CEA-608 / WebVTT live broadcast & VOD subtitles"

    move/from16 v28, v2

    move-object/from16 v29, v3

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v23

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v2, Lm6/v0;

    new-instance v8, Lm6/l2;

    const/16 v1, 0x13

    invoke-direct {v8, v0, v1}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v7, 0x0

    const v3, 0x7f0800d6

    const-string v4, "Subtitle Size & Color Style"

    const-string v5, "Customize subtitle font size and high-contrast caption colors"

    const-string v6, "STYLE"

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v0}, La/a;->t(Lcom/harindra/iptvpro/PlayerActivity;)Z

    move-result v1

    if-eqz v1, :cond_22

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->A2:Ljava/lang/String;

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_21

    const-string v1, "From a file on storage/USB or from a URL"

    :cond_21
    :goto_26
    move-object v5, v1

    goto :goto_27

    :cond_22
    const-string v1, "Available while a Movie, Episode or Catch-up programme is playing"

    goto :goto_26

    :goto_27
    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->A2:Ljava/lang/String;

    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_23

    const-string v1, "LOADED \u2713"

    :goto_28
    move-object v6, v1

    goto :goto_29

    :cond_23
    invoke-static {v0}, La/a;->t(Lcom/harindra/iptvpro/PlayerActivity;)Z

    move-result v1

    if-eqz v1, :cond_24

    const-string v1, "IMPORT"

    goto :goto_28

    :cond_24
    const-string v1, "VOD ONLY"

    goto :goto_28

    :goto_29
    new-instance v8, Lm6/l2;

    const/16 v1, 0x14

    invoke-direct {v8, v0, v1}, Lm6/l2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    new-instance v2, Lm6/v0;

    const/4 v7, 0x0

    const v3, 0x7f0800d6

    const-string v4, "Load External Subtitle (SRT / VTT / ASS / TTML)"

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v1

    const/16 v2, 0x384

    if-eqz v1, :cond_25

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v3, "audio_loudness_boost_db_v192"

    const/4 v4, 0x0

    invoke-interface {v1, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    invoke-static {v1, v4, v2}, Lc4/b0;->i(III)I

    move-result v11

    goto :goto_2a

    :cond_25
    const/4 v4, 0x0

    move v11, v4

    :goto_2a
    const/16 v1, 0x12c

    if-eq v11, v1, :cond_28

    const/16 v1, 0x258

    if-eq v11, v1, :cond_27

    if-eq v11, v2, :cond_26

    const-string v1, "0 dB (Normal)"

    goto :goto_2b

    :cond_26
    const-string v1, "+9 dB (Max TV Boost)"

    goto :goto_2b

    :cond_27
    const-string v1, "+6 dB (Clear Dialogue)"

    goto :goto_2b

    :cond_28
    const-string v1, "+3 dB (Gentle Boost)"

    :goto_2b
    new-instance v2, Lm6/v0;

    const-string v3, "TV Audio Dialogue Boost: "

    invoke-virtual {v3, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    div-int/lit8 v1, v11, 0x64

    const-string v3, " dB"

    invoke-static {v3, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Lm6/j2;

    const/4 v1, 0x1

    invoke-direct {v8, v11, v0, v1}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v7, 0x0

    const v3, 0x7f0800bf

    const-string v5, "Amplify quiet IPTV / movie dialogue using hardware LoudnessEnhancer"

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->h2:Ljava/lang/String;

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i2:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_29

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i2:Ljava/lang/String;

    invoke-static {v10, v2}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_2c

    :cond_29
    const-string v2, ""

    :goto_2c
    const-string v3, "Real-Time Media3 Track Engine \u2022 "

    invoke-static {v3, v1, v2}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->l2:Ljava/lang/String;

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v2, v14}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v13}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "Close"

    const v1, 0x7f0800bf

    const-string v2, "Audio Tracks, Video Quality & Subtitles"

    move-object v5, v9

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final x(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 24

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v1

    const-wide/32 v3, 0x100000

    div-long v5, v1, v3

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Runtime;->totalMemory()J

    move-result-wide v7

    invoke-virtual {v1}, Ljava/lang/Runtime;->freeMemory()J

    move-result-wide v1

    sub-long/2addr v7, v1

    div-long v11, v7, v3

    invoke-static {}, Lm6/l1;->values()[Lm6/l1;

    move-result-object v13

    new-instance v14, Ljava/util/ArrayList;

    array-length v1, v13

    invoke-direct {v14, v1}, Ljava/util/ArrayList;-><init>(I)V

    array-length v15, v13

    const/16 v16, 0x0

    move/from16 v1, v16

    :goto_0
    if-ge v1, v15, :cond_5

    move-wide v8, v5

    aget-object v5, v13, v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    if-ne v5, v2, :cond_0

    const/4 v2, 0x1

    move v3, v2

    goto :goto_1

    :cond_0
    move/from16 v3, v16

    :goto_1
    iget-wide v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->c1:J

    iget-boolean v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->b1:Z

    invoke-virtual/range {v5 .. v10}, Lm6/l1;->t(JJZ)Z

    move-result v2

    new-instance v17, Lm6/v0;

    sget-object v4, Lm6/z2;->a:[I

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    aget v4, v4, v6

    const v6, 0x7f0800ce

    packed-switch v4, :pswitch_data_0

    new-instance v0, Lb5/f0;

    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    throw v0

    :pswitch_0
    const v6, 0x7f0800db

    :goto_2
    :pswitch_1
    move/from16 v18, v6

    goto :goto_3

    :pswitch_2
    const v6, 0x7f0800c8

    goto :goto_2

    :pswitch_3
    const v6, 0x7f0800cc

    goto :goto_2

    :pswitch_4
    const v6, 0x7f0800d4

    goto :goto_2

    :goto_3
    invoke-virtual {v5}, Lm6/l1;->r()Ljava/lang/String;

    move-result-object v19

    sget-object v4, Lm6/l1;->HIGH_PERFORMANCE_4GB:Lm6/l1;

    if-ne v5, v4, :cond_1

    if-nez v2, :cond_1

    iget-wide v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->c1:J

    invoke-virtual {v5}, Lm6/l1;->q()Ljava/lang/String;

    move-result-object v10

    new-instance v0, Ljava/lang/StringBuilder;

    move/from16 v20, v1

    const-string v1, "Not recommended here: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "MB RAM / "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "MB app heap \u2022 "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_4
    move-object v7, v0

    goto :goto_5

    :cond_1
    move/from16 v20, v1

    invoke-virtual {v5}, Lm6/l1;->q()Ljava/lang/String;

    move-result-object v0

    goto :goto_4

    :goto_5
    if-eqz v3, :cond_2

    const-string v0, "ACTIVE \u2713"

    :goto_6
    move-object/from16 v21, v0

    goto :goto_7

    :cond_2
    if-ne v5, v4, :cond_3

    if-eqz v2, :cond_3

    const-string v0, "SUITS THIS TV"

    goto :goto_6

    :cond_3
    if-ne v5, v4, :cond_4

    const-string v0, "NOT FOR THIS TV"

    goto :goto_6

    :cond_4
    invoke-virtual {v5}, Lm6/l1;->e()J

    move-result-wide v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, "ms"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_6

    :goto_7
    new-instance v0, Lm6/w2;

    move-object/from16 v4, p0

    move-object v1, v5

    move-wide v5, v8

    move/from16 v8, v20

    invoke-direct/range {v0 .. v6}, Lm6/w2;-><init>(Lm6/l1;ZZLcom/harindra/iptvpro/PlayerActivity;J)V

    move-object/from16 v23, v0

    move/from16 v22, v3

    move-object v0, v4

    move-object/from16 v20, v7

    invoke-direct/range {v17 .. v23}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v17

    invoke-virtual {v14, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v8, 0x1

    goto/16 :goto_0

    :cond_5
    iget-wide v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->c1:J

    sget-object v3, Lm6/y7;->a:Lk7/e;

    invoke-static {}, Lm6/y7;->j()I

    move-result v3

    div-int/lit16 v3, v3, 0x400

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v7, "Device RAM "

    invoke-direct {v4, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "MB \u2022 App heap "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, "MB \u2022 Preload cache "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "KB"

    invoke-static {v4, v3, v1}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    invoke-virtual {v1}, Lm6/l1;->f()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800ce

    const-string v2, "Performance Modes & Smart Low-Memory Guard (v18.1)"

    move-object v5, v14

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static final y(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 17

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ln6/h;

    const/4 v2, -0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "#B3000000"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "Standard White on Translucent Black"

    invoke-direct {v1, v4, v2, v3}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v2, Ln6/h;

    const-string v3, "#FDE047"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "#E6000000"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string v5, "High-Contrast Yellow on Black"

    invoke-direct {v2, v5, v3, v4}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    new-instance v3, Ln6/h;

    const-string v4, "#38BDF8"

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string v5, "#CC071022"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "Neon Cyan Crystal Captions"

    invoke-direct {v3, v6, v4, v5}, Ln6/h;-><init>(Ljava/io/Serializable;Ljava/io/Serializable;Ljava/lang/Object;)V

    const/4 v4, 0x3

    new-array v5, v4, [Ln6/h;

    const/4 v6, 0x0

    aput-object v1, v5, v6

    const/4 v1, 0x1

    aput-object v2, v5, v1

    const/4 v2, 0x2

    aput-object v3, v5, v2

    invoke-static {v5}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    new-instance v5, Ljava/util/ArrayList;

    const/4 v7, 0x6

    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ln6/h;

    iget-object v8, v7, Ln6/h;->k:Ljava/io/Serializable;

    check-cast v8, Ljava/lang/String;

    iget-object v9, v7, Ln6/h;->l:Ljava/io/Serializable;

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    iget-object v7, v7, Ln6/h;->m:Ljava/lang/Object;

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    new-instance v10, Lm6/v0;

    const-string v11, "Color: "

    invoke-virtual {v11, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    new-instance v11, Lm6/u2;

    invoke-direct {v11, v0, v9, v7, v8}, Lm6/u2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;IILjava/lang/String;)V

    const/4 v15, 0x0

    move-object/from16 v16, v11

    const v11, 0x7f0800d6

    const-string v13, "Apply high-visibility subtitle color palette"

    const-string v14, "APPLY"

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41800000    # 16.0f

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    new-instance v7, Ln6/d;

    const-string v8, "Small (16sp)"

    invoke-direct {v7, v8, v3}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    new-instance v8, Ln6/d;

    const-string v9, "Standard TV (20sp)"

    invoke-direct {v8, v9, v3}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/high16 v3, 0x41d00000    # 26.0f

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    new-instance v9, Ln6/d;

    const-string v10, "Large TV (26sp)"

    invoke-direct {v9, v10, v3}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/high16 v3, 0x42000000    # 32.0f

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    new-instance v10, Ln6/d;

    const-string v11, "Extra Large (32sp)"

    invoke-direct {v10, v11, v3}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x4

    new-array v3, v3, [Ln6/d;

    aput-object v7, v3, v6

    aput-object v8, v3, v1

    aput-object v9, v3, v2

    aput-object v10, v3, v4

    invoke-static {v3}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ln6/d;

    iget-object v3, v2, Ln6/d;->k:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v2, v2, Ln6/d;->l:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->floatValue()F

    move-result v2

    new-instance v6, Lm6/v0;

    const-string v4, "Font Size: "

    invoke-static {v4, v3}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    float-to-int v4, v2

    const-string v7, "sp"

    invoke-static {v7, v4}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/v2;

    invoke-direct {v12, v0, v2, v3}, Lm6/v2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;FLjava/lang/String;)V

    const/4 v11, 0x0

    const v7, 0x7f0800d6

    const-string v9, "Adjust subtitle readability for television viewing distance"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    const-string v4, "CAPTIONS"

    const-string v6, "Back"

    const v1, 0x7f0800d6

    const-string v2, "Subtitle Size & Color Customization"

    const-string v3, "Applied immediately to active Media3 subtitles"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final z(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 4

    const-string v0, "<this>"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->z()Landroid/view/View;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->z()Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->E()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->D2:Landroid/os/Handler;

    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->F2:Lm6/s1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object p0

    invoke-virtual {p0}, Lm6/m6;->E()J

    move-result-wide v2

    goto :goto_0

    :cond_0
    const-wide/16 v2, 0xdac

    :goto_0
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
