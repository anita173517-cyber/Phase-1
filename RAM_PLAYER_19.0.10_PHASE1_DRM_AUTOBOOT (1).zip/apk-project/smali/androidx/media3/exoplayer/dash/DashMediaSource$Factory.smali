.class public final Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr1/a0;


# instance fields
.field public final a:Le1/l;

.field public final b:La1/h;

.field public final c:Ll4/t;

.field public final d:Lp1/h0;

.field public final e:Lp1/h0;

.field public final f:J

.field public final g:J


# direct methods
.method public constructor <init>(La1/h;)V
    .locals 3

    .line 1
    new-instance v0, Le1/l;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Le1/l;-><init>(La1/h;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->a:Le1/l;

    .line 10
    .line 11
    iput-object p1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->b:La1/h;

    .line 12
    .line 13
    new-instance p1, Ll4/t;

    .line 14
    .line 15
    const/16 v1, 0xb

    .line 16
    .line 17
    invoke-direct {p1, v1}, Ll4/t;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->c:Ll4/t;

    .line 21
    .line 22
    new-instance p1, Lp1/h0;

    .line 23
    .line 24
    const/16 v1, 0x14

    .line 25
    .line 26
    invoke-direct {p1, v1}, Lp1/h0;-><init>(I)V

    .line 27
    .line 28
    .line 29
    iput-object p1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->e:Lp1/h0;

    .line 30
    .line 31
    const-wide/16 v1, 0x7530

    .line 32
    .line 33
    iput-wide v1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->f:J

    .line 34
    .line 35
    const-wide/32 v1, 0x4c4b40

    .line 36
    .line 37
    .line 38
    iput-wide v1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->g:J

    .line 39
    .line 40
    new-instance p1, Lp1/h0;

    .line 41
    .line 42
    const/16 v1, 0xa

    .line 43
    .line 44
    invoke-direct {p1, v1}, Lp1/h0;-><init>(I)V

    .line 45
    .line 46
    .line 47
    iput-object p1, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->d:Lp1/h0;

    .line 48
    .line 49
    iget-object p1, v0, Le1/l;->n:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p1, Lo/a;

    .line 52
    .line 53
    const/4 v0, 0x1

    .line 54
    iput-boolean v0, p1, Lo/a;->a:Z

    .line 55
    .line 56
    return-void
.end method


# virtual methods
.method public final a(Z)Lr1/a0;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->a:Le1/l;

    .line 2
    .line 3
    iget-object v0, v0, Le1/l;->n:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lo/a;

    .line 6
    .line 7
    iput-boolean p1, v0, Lo/a;->a:Z

    .line 8
    .line 9
    return-object p0
.end method

.method public final b(Lx1/b;)Lr1/a0;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->a:Le1/l;

    .line 2
    .line 3
    iget-object v0, v0, Le1/l;->n:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lo/a;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iput-object p1, v0, Lo/a;->c:Ljava/lang/Object;

    .line 11
    .line 12
    return-object p0
.end method

.method public final c(Lv0/k0;)Lr1/a;
    .locals 12

    .line 1
    iget-object v0, p1, Lv0/k0;->b:Lv0/f0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    new-instance v0, Lh1/e;

    .line 7
    .line 8
    invoke-direct {v0}, Lh1/e;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v2, p1, Lv0/k0;->b:Lv0/f0;

    .line 12
    .line 13
    iget-object v2, v2, Lv0/f0;->e:Ljava/util/List;

    .line 14
    .line 15
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    if-nez v3, :cond_0

    .line 20
    .line 21
    new-instance v3, Ll3/i0;

    .line 22
    .line 23
    invoke-direct {v3, v0, v2}, Ll3/i0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    move-object v3, v0

    .line 28
    :goto_0
    new-instance v0, Lg1/g;

    .line 29
    .line 30
    iget-object v2, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->c:Ll4/t;

    .line 31
    .line 32
    invoke-virtual {v2, p1}, Ll4/t;->u(Lv0/k0;)Li1/p;

    .line 33
    .line 34
    .line 35
    move-result-object v6

    .line 36
    iget-wide v8, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->f:J

    .line 37
    .line 38
    iget-wide v10, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->g:J

    .line 39
    .line 40
    iget-object v2, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->b:La1/h;

    .line 41
    .line 42
    iget-object v4, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->a:Le1/l;

    .line 43
    .line 44
    iget-object v5, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->d:Lp1/h0;

    .line 45
    .line 46
    iget-object v7, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->e:Lp1/h0;

    .line 47
    .line 48
    move-object v1, p1

    .line 49
    invoke-direct/range {v0 .. v11}, Lg1/g;-><init>(Lv0/k0;La1/h;Lv1/o;Le1/l;Lp1/h0;Li1/p;Lp1/h0;JJ)V

    .line 50
    .line 51
    .line 52
    return-object v0
.end method

.method public final d(I)Lr1/a0;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->a:Le1/l;

    .line 2
    .line 3
    iget-object v0, v0, Le1/l;->n:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lo/a;

    .line 6
    .line 7
    iput p1, v0, Lo/a;->b:I

    .line 8
    .line 9
    return-object p0
.end method
