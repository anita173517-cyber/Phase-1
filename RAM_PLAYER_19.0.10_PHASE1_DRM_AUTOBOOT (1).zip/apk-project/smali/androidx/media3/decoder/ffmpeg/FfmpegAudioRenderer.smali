.class public final Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;
.super Ld1/a;
.source "SourceFile"

# interfaces
.implements Ld1/z0;
.implements Lc1/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ld1/a;",
        "Ld1/z0;",
        "Lc1/d;"
    }
.end annotation


# instance fields
.field public final D:Ll3/i0;

.field public final E:Lf1/a0;

.field public final F:Lc1/h;

.field public G:Ld1/c;

.field public H:Lv0/t;

.field public I:I

.field public J:I

.field public K:Z

.field public L:Lc1/e;

.field public M:Lc1/h;

.field public N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

.field public O:Li1/i;

.field public P:Li1/i;

.field public Q:I

.field public R:Z

.field public S:Z

.field public T:J

.field public U:Z

.field public V:Z

.field public W:Z

.field public X:J

.field public final Y:[J

.field public Z:I

.field public a0:Z

.field public b0:Z

.field public c0:Z

.field public d0:J

.field public e0:J

.field public f0:J

.field public g0:J

.field public h0:Z

.field public i0:Ld1/o0;

.field public j0:Ld1/j0;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    .line 1
    new-array v0, v0, [Lw0/n;

    const/4 v1, 0x0

    invoke-direct {p0, v1, v1, v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;-><init>(Landroid/os/Handler;Lf1/u;[Lw0/n;)V

    return-void
.end method

.method public constructor <init>(Landroid/os/Handler;Lf1/u;Lf1/a0;)V
    .locals 2

    const/4 v0, 0x1

    .line 8
    invoke-direct {p0, v0}, Ld1/a;-><init>(I)V

    .line 9
    new-instance v1, Ll3/i0;

    invoke-direct {v1, p1, p2}, Ll3/i0;-><init>(Landroid/os/Handler;Lf1/u;)V

    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 10
    iput-object p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 11
    new-instance p1, Lc1/h;

    const/4 p2, 0x0

    .line 12
    invoke-direct {p1, p2, p2}, Lc1/h;-><init>(II)V

    .line 13
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->F:Lc1/h;

    .line 14
    iput p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 15
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 16
    invoke-virtual {p0, v0, v1}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P(J)V

    const/16 p1, 0xa

    .line 17
    new-array p1, p1, [J

    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Y:[J

    .line 18
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 19
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 20
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 21
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 22
    iput-boolean p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->h0:Z

    return-void
.end method

.method public varargs constructor <init>(Landroid/os/Handler;Lf1/u;[Lw0/n;)V
    .locals 2

    .line 2
    new-instance v0, Lf1/n0;

    invoke-direct {v0}, Lf1/n0;-><init>()V

    .line 3
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    new-instance v1, Ll4/t;

    invoke-direct {v1, p3}, Ll4/t;-><init>([Lw0/n;)V

    .line 5
    iput-object v1, v0, Lf1/n0;->c:Ll4/t;

    .line 6
    invoke-virtual {v0}, Lf1/n0;->a()Lf1/r0;

    move-result-object p3

    .line 7
    invoke-direct {p0, p1, p2, p3}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;-><init>(Landroid/os/Handler;Lf1/u;Lf1/a0;)V

    return-void
.end method


# virtual methods
.method public final B(JJ)V
    .locals 2

    .line 1
    iget-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 2
    .line 3
    const/16 p2, 0x138a

    .line 4
    .line 5
    if-eqz p1, :cond_0

    .line 6
    .line 7
    :try_start_0
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 8
    .line 9
    check-cast p1, Lf1/r0;

    .line 10
    .line 11
    invoke-virtual {p1}, Lf1/r0;->t()V

    .line 12
    .line 13
    .line 14
    iget-wide p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 15
    .line 16
    iput-wide p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J
    :try_end_0
    .catch Lf1/z; {:try_start_0 .. :try_end_0} :catch_0

    .line 17
    .line 18
    return-void

    .line 19
    :catch_0
    move-exception p1

    .line 20
    iget-object p3, p1, Lf1/z;->m:Lv0/t;

    .line 21
    .line 22
    iget-boolean p4, p1, Lf1/z;->l:Z

    .line 23
    .line 24
    invoke-virtual {p0, p1, p3, p4, p2}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    throw p1

    .line 29
    :cond_0
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 30
    .line 31
    const/4 p3, 0x0

    .line 32
    if-nez p1, :cond_2

    .line 33
    .line 34
    iget-object p1, p0, Ld1/a;->m:Ll4/c;

    .line 35
    .line 36
    invoke-virtual {p1}, Ll4/c;->e()V

    .line 37
    .line 38
    .line 39
    iget-object p4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->F:Lc1/h;

    .line 40
    .line 41
    invoke-virtual {p4}, Lc1/h;->h()V

    .line 42
    .line 43
    .line 44
    iget-object p4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->F:Lc1/h;

    .line 45
    .line 46
    const/4 v0, 0x2

    .line 47
    invoke-virtual {p0, p1, p4, v0}, Ld1/a;->A(Ll4/c;Lc1/h;I)I

    .line 48
    .line 49
    .line 50
    move-result p4

    .line 51
    const/4 v0, -0x5

    .line 52
    if-ne p4, v0, :cond_1

    .line 53
    .line 54
    invoke-virtual {p0, p1}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N(Ll4/c;)V

    .line 55
    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    const/4 p1, -0x4

    .line 59
    if-ne p4, p1, :cond_6

    .line 60
    .line 61
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->F:Lc1/h;

    .line 62
    .line 63
    const/4 p4, 0x4

    .line 64
    invoke-virtual {p1, p4}, Lc1/a;->g(I)Z

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    invoke-static {p1}, Landroid/support/v4/media/session/b;->s(Z)V

    .line 69
    .line 70
    .line 71
    const/4 p1, 0x1

    .line 72
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->V:Z

    .line 73
    .line 74
    :try_start_1
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 75
    .line 76
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 77
    .line 78
    check-cast p1, Lf1/r0;

    .line 79
    .line 80
    invoke-virtual {p1}, Lf1/r0;->t()V

    .line 81
    .line 82
    .line 83
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 84
    .line 85
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J
    :try_end_1
    .catch Lf1/z; {:try_start_1 .. :try_end_1} :catch_1

    .line 86
    .line 87
    return-void

    .line 88
    :catch_1
    move-exception p1

    .line 89
    const/4 p4, 0x0

    .line 90
    invoke-virtual {p0, p1, p4, p3, p2}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    throw p1

    .line 95
    :cond_2
    :goto_0
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M()V

    .line 96
    .line 97
    .line 98
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 99
    .line 100
    if-eqz p1, :cond_6

    .line 101
    .line 102
    const/16 p1, 0x1389

    .line 103
    .line 104
    :try_start_2
    const-string p4, "drainAndFeed"

    .line 105
    .line 106
    invoke-static {p4}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    :goto_1
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->K()Z

    .line 110
    .line 111
    .line 112
    move-result p4

    .line 113
    if-eqz p4, :cond_3

    .line 114
    .line 115
    goto :goto_1

    .line 116
    :cond_3
    :goto_2
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L()Z

    .line 117
    .line 118
    .line 119
    move-result p4

    .line 120
    if-eqz p4, :cond_4

    .line 121
    .line 122
    goto :goto_2

    .line 123
    :cond_4
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_2
    .catch Lc1/f; {:try_start_2 .. :try_end_2} :catch_5
    .catch Lf1/w; {:try_start_2 .. :try_end_2} :catch_4
    .catch Lf1/x; {:try_start_2 .. :try_end_2} :catch_3
    .catch Lf1/z; {:try_start_2 .. :try_end_2} :catch_2

    .line 124
    .line 125
    .line 126
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 127
    .line 128
    monitor-enter p1

    .line 129
    monitor-exit p1

    .line 130
    return-void

    .line 131
    :catch_2
    move-exception p1

    .line 132
    goto :goto_3

    .line 133
    :catch_3
    move-exception p2

    .line 134
    goto :goto_4

    .line 135
    :catch_4
    move-exception p2

    .line 136
    goto :goto_5

    .line 137
    :catch_5
    move-exception p1

    .line 138
    goto :goto_6

    .line 139
    :goto_3
    iget-object p3, p1, Lf1/z;->m:Lv0/t;

    .line 140
    .line 141
    iget-boolean p4, p1, Lf1/z;->l:Z

    .line 142
    .line 143
    invoke-virtual {p0, p1, p3, p4, p2}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 144
    .line 145
    .line 146
    move-result-object p1

    .line 147
    throw p1

    .line 148
    :goto_4
    iget-object p3, p2, Lf1/x;->l:Lv0/t;

    .line 149
    .line 150
    iget-boolean p4, p2, Lf1/x;->k:Z

    .line 151
    .line 152
    invoke-virtual {p0, p2, p3, p4, p1}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    throw p1

    .line 157
    :goto_5
    iget-object p4, p2, Lf1/w;->k:Lv0/t;

    .line 158
    .line 159
    invoke-virtual {p0, p2, p4, p3, p1}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    throw p1

    .line 164
    :goto_6
    const-string p2, "DecoderAudioRenderer"

    .line 165
    .line 166
    const-string p4, "Audio codec error"

    .line 167
    .line 168
    invoke-static {p2, p4, p1}, Ly0/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 169
    .line 170
    .line 171
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 172
    .line 173
    iget-object p4, p2, Ll3/i0;->k:Ljava/lang/Object;

    .line 174
    .line 175
    check-cast p4, Landroid/os/Handler;

    .line 176
    .line 177
    if-eqz p4, :cond_5

    .line 178
    .line 179
    new-instance v0, Lf1/s;

    .line 180
    .line 181
    const/4 v1, 0x0

    .line 182
    invoke-direct {v0, p2, p1, v1}, Lf1/s;-><init>(Ll3/i0;Ljava/lang/Object;I)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p4, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 186
    .line 187
    .line 188
    :cond_5
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 189
    .line 190
    const/16 p4, 0xfa3

    .line 191
    .line 192
    invoke-virtual {p0, p1, p2, p3, p4}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    throw p1

    .line 197
    :cond_6
    return-void
.end method

.method public final F(Lv0/t;)I
    .locals 7

    .line 1
    iget-object v0, p1, Lv0/t;->p:Ljava/lang/String;

    .line 2
    .line 3
    iget v1, p1, Lv0/t;->L:I

    .line 4
    .line 5
    iget v2, p1, Lv0/t;->J:I

    .line 6
    .line 7
    invoke-static {v0}, Lv0/q0;->k(Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v3, 0x0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-static {v3, v3, v3, v3}, La0/h;->i(IIII)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    return p1

    .line 19
    :cond_0
    iget-object v0, p1, Lv0/t;->p:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-static {}, Landroidx/media3/decoder/ffmpeg/FfmpegLibrary;->isAvailable()Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    const/4 v5, 0x2

    .line 29
    if-eqz v4, :cond_4

    .line 30
    .line 31
    invoke-static {v0}, Lv0/q0;->k(Ljava/lang/String;)Z

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-nez v4, :cond_1

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    invoke-static {v0}, Landroidx/media3/decoder/ffmpeg/FfmpegLibrary;->supportsFormat(Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_3

    .line 43
    .line 44
    invoke-static {v5, v2, v1}, Ly0/k0;->H(III)Lv0/t;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    iget-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 49
    .line 50
    move-object v6, v4

    .line 51
    check-cast v6, Lf1/r0;

    .line 52
    .line 53
    invoke-virtual {v6, v0}, Lf1/r0;->j(Lv0/t;)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    const/4 v6, 0x4

    .line 58
    if-eqz v0, :cond_2

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_2
    invoke-static {v6, v2, v1}, Ly0/k0;->H(III)Lv0/t;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    check-cast v4, Lf1/r0;

    .line 66
    .line 67
    invoke-virtual {v4, v0}, Lf1/r0;->j(Lv0/t;)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-eqz v0, :cond_3

    .line 72
    .line 73
    :goto_0
    iget p1, p1, Lv0/t;->T:I

    .line 74
    .line 75
    if-eqz p1, :cond_5

    .line 76
    .line 77
    move v6, v5

    .line 78
    goto :goto_2

    .line 79
    :cond_3
    const/4 v6, 0x1

    .line 80
    goto :goto_2

    .line 81
    :cond_4
    :goto_1
    move v6, v3

    .line 82
    :cond_5
    :goto_2
    if-gt v6, v5, :cond_6

    .line 83
    .line 84
    invoke-static {v6, v3, v3, v3}, La0/h;->i(IIII)I

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    return p1

    .line 89
    :cond_6
    or-int/lit16 p1, v6, 0xa8

    .line 90
    .line 91
    return p1
.end method

.method public final G()I
    .locals 1

    .line 1
    const/16 v0, 0x8

    return v0
.end method

.method public final J(Lv0/t;)Lc1/e;
    .locals 9

    .line 1
    const-string v0, "createFfmpegAudioDecoder"

    .line 2
    .line 3
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget v0, p1, Lv0/t;->q:I

    .line 7
    .line 8
    iget v1, p1, Lv0/t;->L:I

    .line 9
    .line 10
    iget v2, p1, Lv0/t;->J:I

    .line 11
    .line 12
    const/4 v3, -0x1

    .line 13
    if-eq v0, v3, :cond_0

    .line 14
    .line 15
    :goto_0
    move v7, v0

    .line 16
    goto :goto_1

    .line 17
    :cond_0
    const/16 v0, 0x1680

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :goto_1
    new-instance v3, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;

    .line 21
    .line 22
    const/4 v0, 0x2

    .line 23
    invoke-static {v0, v2, v1}, Ly0/k0;->H(III)Lv0/t;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    iget-object v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 28
    .line 29
    move-object v6, v5

    .line 30
    check-cast v6, Lf1/r0;

    .line 31
    .line 32
    invoke-virtual {v6, v4}, Lf1/r0;->j(Lv0/t;)I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    const/4 v6, 0x1

    .line 37
    if-eqz v4, :cond_1

    .line 38
    .line 39
    const/4 v4, 0x4

    .line 40
    invoke-static {v4, v2, v1}, Ly0/k0;->H(III)Lv0/t;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v5, Lf1/r0;

    .line 45
    .line 46
    invoke-virtual {v5, v1}, Lf1/r0;->j(Lv0/t;)I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    if-eq v1, v0, :cond_2

    .line 51
    .line 52
    const/4 v6, 0x0

    .line 53
    :cond_1
    :goto_2
    move v8, v6

    .line 54
    goto :goto_3

    .line 55
    :cond_2
    const-string v0, "audio/ac3"

    .line 56
    .line 57
    iget-object v1, p1, Lv0/t;->p:Ljava/lang/String;

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    xor-int/2addr v6, v0

    .line 64
    goto :goto_2

    .line 65
    :goto_3
    const/16 v5, 0x10

    .line 66
    .line 67
    const/16 v6, 0x10

    .line 68
    .line 69
    move-object v4, p1

    .line 70
    invoke-direct/range {v3 .. v8}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;-><init>(Lv0/t;IIIZ)V

    .line 71
    .line 72
    .line 73
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 74
    .line 75
    .line 76
    return-object v3
.end method

.method public final K()Z
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-nez v0, :cond_2

    .line 8
    .line 9
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 10
    .line 11
    invoke-interface {v0}, Lc1/e;->dequeueOutputBuffer()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 16
    .line 17
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 18
    .line 19
    if-nez v0, :cond_0

    .line 20
    .line 21
    return v2

    .line 22
    :cond_0
    iget v4, v0, Lc1/i;->n:I

    .line 23
    .line 24
    if-lez v4, :cond_1

    .line 25
    .line 26
    iget-object v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 27
    .line 28
    iget v6, v5, Ld1/c;->f:I

    .line 29
    .line 30
    add-int/2addr v6, v4

    .line 31
    iput v6, v5, Ld1/c;->f:I

    .line 32
    .line 33
    move-object v4, v1

    .line 34
    check-cast v4, Lf1/r0;

    .line 35
    .line 36
    iput-boolean v3, v4, Lf1/r0;->G:Z

    .line 37
    .line 38
    :cond_1
    const/high16 v4, 0x8000000

    .line 39
    .line 40
    invoke-virtual {v0, v4}, Lc1/a;->g(I)Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_2

    .line 45
    .line 46
    move-object v0, v1

    .line 47
    check-cast v0, Lf1/r0;

    .line 48
    .line 49
    iput-boolean v3, v0, Lf1/r0;->G:Z

    .line 50
    .line 51
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 52
    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Y:[J

    .line 56
    .line 57
    aget-wide v4, v0, v2

    .line 58
    .line 59
    invoke-virtual {p0, v4, v5}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P(J)V

    .line 60
    .line 61
    .line 62
    iget v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 63
    .line 64
    sub-int/2addr v4, v3

    .line 65
    iput v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 66
    .line 67
    invoke-static {v0, v3, v0, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 68
    .line 69
    .line 70
    :cond_2
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 71
    .line 72
    const/4 v4, 0x4

    .line 73
    invoke-virtual {v0, v4}, Lc1/a;->g(I)Z

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    const/4 v4, 0x0

    .line 78
    if-eqz v0, :cond_4

    .line 79
    .line 80
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 81
    .line 82
    const/4 v5, 0x2

    .line 83
    if-ne v0, v5, :cond_3

    .line 84
    .line 85
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O()V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M()V

    .line 89
    .line 90
    .line 91
    iput-boolean v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    .line 92
    .line 93
    return v2

    .line 94
    :cond_3
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 95
    .line 96
    invoke-virtual {v0}, Landroidx/media3/decoder/SimpleDecoderOutputBuffer;->i()V

    .line 97
    .line 98
    .line 99
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 100
    .line 101
    :try_start_0
    iput-boolean v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 102
    .line 103
    check-cast v1, Lf1/r0;

    .line 104
    .line 105
    invoke-virtual {v1}, Lf1/r0;->t()V

    .line 106
    .line 107
    .line 108
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 109
    .line 110
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J
    :try_end_0
    .catch Lf1/z; {:try_start_0 .. :try_end_0} :catch_0

    .line 111
    .line 112
    return v2

    .line 113
    :catch_0
    move-exception v0

    .line 114
    iget-boolean v1, v0, Lf1/z;->l:Z

    .line 115
    .line 116
    const/16 v2, 0x138a

    .line 117
    .line 118
    iget-object v3, v0, Lf1/z;->m:Lv0/t;

    .line 119
    .line 120
    invoke-virtual {p0, v0, v3, v1, v2}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    throw v0

    .line 125
    :cond_4
    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    iput-wide v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 131
    .line 132
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    .line 133
    .line 134
    if-eqz v0, :cond_5

    .line 135
    .line 136
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 137
    .line 138
    check-cast v0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;

    .line 139
    .line 140
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 141
    .line 142
    .line 143
    new-instance v5, Lv0/s;

    .line 144
    .line 145
    invoke-direct {v5}, Lv0/s;-><init>()V

    .line 146
    .line 147
    .line 148
    const-string v6, "audio/raw"

    .line 149
    .line 150
    invoke-static {v6}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v6

    .line 154
    iput-object v6, v5, Lv0/s;->o:Ljava/lang/String;

    .line 155
    .line 156
    invoke-virtual {v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;->getChannelCount()I

    .line 157
    .line 158
    .line 159
    move-result v6

    .line 160
    iput v6, v5, Lv0/s;->I:I

    .line 161
    .line 162
    invoke-virtual {v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;->getSampleRate()I

    .line 163
    .line 164
    .line 165
    move-result v6

    .line 166
    iput v6, v5, Lv0/s;->K:I

    .line 167
    .line 168
    invoke-virtual {v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioDecoder;->getEncoding()I

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    iput v0, v5, Lv0/s;->L:I

    .line 173
    .line 174
    new-instance v0, Lv0/t;

    .line 175
    .line 176
    invoke-direct {v0, v5}, Lv0/t;-><init>(Lv0/s;)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v0}, Lv0/t;->a()Lv0/s;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    iget v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->I:I

    .line 184
    .line 185
    iput v5, v0, Lv0/s;->M:I

    .line 186
    .line 187
    iget v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->J:I

    .line 188
    .line 189
    iput v5, v0, Lv0/s;->N:I

    .line 190
    .line 191
    iget-object v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 192
    .line 193
    iget-object v6, v5, Lv0/t;->m:Lv0/p0;

    .line 194
    .line 195
    iput-object v6, v0, Lv0/s;->l:Lv0/p0;

    .line 196
    .line 197
    iget-object v6, v5, Lv0/t;->a:Ljava/lang/String;

    .line 198
    .line 199
    iput-object v6, v0, Lv0/s;->a:Ljava/lang/String;

    .line 200
    .line 201
    iget-object v6, v5, Lv0/t;->b:Ljava/lang/String;

    .line 202
    .line 203
    iput-object v6, v0, Lv0/s;->b:Ljava/lang/String;

    .line 204
    .line 205
    iget-object v5, v5, Lv0/t;->c:Lr5/l0;

    .line 206
    .line 207
    invoke-static {v5}, Lr5/l0;->o(Ljava/util/Collection;)Lr5/l0;

    .line 208
    .line 209
    .line 210
    move-result-object v5

    .line 211
    iput-object v5, v0, Lv0/s;->c:Lr5/l0;

    .line 212
    .line 213
    iget-object v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 214
    .line 215
    iget-object v6, v5, Lv0/t;->d:Ljava/lang/String;

    .line 216
    .line 217
    iput-object v6, v0, Lv0/s;->d:Ljava/lang/String;

    .line 218
    .line 219
    iget v6, v5, Lv0/t;->e:I

    .line 220
    .line 221
    iput v6, v0, Lv0/s;->e:I

    .line 222
    .line 223
    iget v5, v5, Lv0/t;->f:I

    .line 224
    .line 225
    iput v5, v0, Lv0/s;->f:I

    .line 226
    .line 227
    new-instance v5, Lv0/t;

    .line 228
    .line 229
    invoke-direct {v5, v0}, Lv0/t;-><init>(Lv0/s;)V

    .line 230
    .line 231
    .line 232
    new-instance v0, Ll4/i;

    .line 233
    .line 234
    invoke-direct {v0, v5}, Ll4/i;-><init>(Lv0/t;)V

    .line 235
    .line 236
    .line 237
    iput-object v4, v0, Ll4/i;->l:Ljava/lang/Object;

    .line 238
    .line 239
    iget-object v5, p0, Ld1/a;->z:Lv0/j1;

    .line 240
    .line 241
    iput-object v5, v0, Ll4/i;->m:Ljava/lang/Object;

    .line 242
    .line 243
    iget-object v5, p0, Ld1/a;->A:Lr1/b0;

    .line 244
    .line 245
    iput-object v5, v0, Ll4/i;->n:Ljava/lang/Object;

    .line 246
    .line 247
    invoke-virtual {v0}, Ll4/i;->f()Lf1/v;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    move-object v5, v1

    .line 252
    check-cast v5, Lf1/r0;

    .line 253
    .line 254
    invoke-virtual {v5, v0}, Lf1/r0;->c(Lf1/v;)V

    .line 255
    .line 256
    .line 257
    iput-boolean v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    .line 258
    .line 259
    :cond_5
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 260
    .line 261
    iget-object v5, v0, Landroidx/media3/decoder/SimpleDecoderOutputBuffer;->q:Ljava/nio/ByteBuffer;

    .line 262
    .line 263
    iget-wide v6, v0, Lc1/i;->m:J

    .line 264
    .line 265
    check-cast v1, Lf1/r0;

    .line 266
    .line 267
    invoke-virtual {v1, v3, v6, v7, v5}, Lf1/r0;->m(IJLjava/nio/ByteBuffer;)Z

    .line 268
    .line 269
    .line 270
    move-result v0

    .line 271
    if-eqz v0, :cond_6

    .line 272
    .line 273
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 274
    .line 275
    iget v1, v0, Ld1/c;->e:I

    .line 276
    .line 277
    add-int/2addr v1, v3

    .line 278
    iput v1, v0, Ld1/c;->e:I

    .line 279
    .line 280
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 281
    .line 282
    invoke-virtual {v0}, Landroidx/media3/decoder/SimpleDecoderOutputBuffer;->i()V

    .line 283
    .line 284
    .line 285
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 286
    .line 287
    return v3

    .line 288
    :cond_6
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 289
    .line 290
    iget-wide v0, v0, Lc1/i;->m:J

    .line 291
    .line 292
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 293
    .line 294
    return v2
.end method

.method public final L()Z
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_a

    .line 5
    .line 6
    iget v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 7
    .line 8
    const/4 v3, 0x2

    .line 9
    if-eq v2, v3, :cond_a

    .line 10
    .line 11
    iget-boolean v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->V:Z

    .line 12
    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    goto/16 :goto_0

    .line 16
    .line 17
    :cond_0
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 18
    .line 19
    if-nez v2, :cond_1

    .line 20
    .line 21
    invoke-interface {v0}, Lc1/e;->dequeueInputBuffer()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Lc1/h;

    .line 26
    .line 27
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 28
    .line 29
    if-nez v0, :cond_1

    .line 30
    .line 31
    goto/16 :goto_0

    .line 32
    .line 33
    :cond_1
    iget v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 34
    .line 35
    const/4 v2, 0x4

    .line 36
    const/4 v4, 0x0

    .line 37
    const/4 v5, 0x1

    .line 38
    if-ne v0, v5, :cond_2

    .line 39
    .line 40
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 41
    .line 42
    iput v2, v0, Lc1/a;->l:I

    .line 43
    .line 44
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 45
    .line 46
    invoke-interface {v2, v0}, Lc1/e;->queueInputBuffer(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 50
    .line 51
    iput v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 52
    .line 53
    return v1

    .line 54
    :cond_2
    iget-object v0, p0, Ld1/a;->m:Ll4/c;

    .line 55
    .line 56
    invoke-virtual {v0}, Ll4/c;->e()V

    .line 57
    .line 58
    .line 59
    iget-object v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 60
    .line 61
    invoke-virtual {p0, v0, v3, v1}, Ld1/a;->A(Ll4/c;Lc1/h;I)I

    .line 62
    .line 63
    .line 64
    move-result v3

    .line 65
    const/4 v6, -0x5

    .line 66
    if-eq v3, v6, :cond_9

    .line 67
    .line 68
    const/4 v0, -0x4

    .line 69
    if-eq v3, v0, :cond_4

    .line 70
    .line 71
    const/4 v0, -0x3

    .line 72
    if-ne v3, v0, :cond_3

    .line 73
    .line 74
    invoke-virtual {p0}, Ld1/a;->m()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_a

    .line 79
    .line 80
    iget-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 81
    .line 82
    iput-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 83
    .line 84
    return v1

    .line 85
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 88
    .line 89
    .line 90
    throw v0

    .line 91
    :cond_4
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 92
    .line 93
    invoke-virtual {v0, v2}, Lc1/a;->g(I)Z

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-eqz v0, :cond_5

    .line 98
    .line 99
    iput-boolean v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->V:Z

    .line 100
    .line 101
    iget-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 102
    .line 103
    iput-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 104
    .line 105
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 106
    .line 107
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 108
    .line 109
    invoke-interface {v0, v2}, Lc1/e;->queueInputBuffer(Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 113
    .line 114
    return v1

    .line 115
    :cond_5
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->K:Z

    .line 116
    .line 117
    if-nez v0, :cond_6

    .line 118
    .line 119
    iput-boolean v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->K:Z

    .line 120
    .line 121
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 122
    .line 123
    const/high16 v1, 0x8000000

    .line 124
    .line 125
    invoke-virtual {v0, v1}, Lc1/a;->d(I)V

    .line 126
    .line 127
    .line 128
    :cond_6
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 129
    .line 130
    iget-wide v0, v0, Lc1/h;->q:J

    .line 131
    .line 132
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 133
    .line 134
    invoke-virtual {p0}, Ld1/a;->m()Z

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    if-nez v0, :cond_7

    .line 139
    .line 140
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 141
    .line 142
    const/high16 v1, 0x20000000

    .line 143
    .line 144
    invoke-virtual {v0, v1}, Lc1/a;->g(I)Z

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    if-eqz v0, :cond_8

    .line 149
    .line 150
    :cond_7
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 151
    .line 152
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 153
    .line 154
    :cond_8
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 155
    .line 156
    invoke-virtual {v0}, Lc1/h;->k()V

    .line 157
    .line 158
    .line 159
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 160
    .line 161
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 162
    .line 163
    iput-object v1, v0, Lc1/h;->m:Lv0/t;

    .line 164
    .line 165
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 166
    .line 167
    invoke-interface {v1, v0}, Lc1/e;->queueInputBuffer(Ljava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    iput-boolean v5, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->R:Z

    .line 171
    .line 172
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 173
    .line 174
    iget v1, v0, Ld1/c;->c:I

    .line 175
    .line 176
    add-int/2addr v1, v5

    .line 177
    iput v1, v0, Ld1/c;->c:I

    .line 178
    .line 179
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 180
    .line 181
    return v5

    .line 182
    :cond_9
    invoke-virtual {p0, v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N(Ll4/c;)V

    .line 183
    .line 184
    .line 185
    return v5

    .line 186
    :cond_a
    :goto_0
    return v1
.end method

.method public final M()V
    .locals 10

    .line 1
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 2
    .line 3
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P:Li1/i;

    .line 9
    .line 10
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 11
    .line 12
    invoke-static {v2, v0}, La0/h;->E(Li1/i;Li1/i;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 16
    .line 17
    if-eqz v0, :cond_2

    .line 18
    .line 19
    invoke-interface {v0}, Li1/i;->h()Lc1/b;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    if-nez v0, :cond_2

    .line 24
    .line 25
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 26
    .line 27
    invoke-interface {v0}, Li1/i;->g()Li1/h;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_1
    :goto_0
    return-void

    .line 35
    :cond_2
    :goto_1
    const/4 v7, 0x0

    .line 36
    const/16 v8, 0xfa1

    .line 37
    .line 38
    :try_start_0
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->j0:Ld1/j0;

    .line 39
    .line 40
    if-nez v0, :cond_3

    .line 41
    .line 42
    new-instance v0, Landroid/os/Handler;

    .line 43
    .line 44
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 49
    .line 50
    .line 51
    new-instance v2, Ld1/j0;

    .line 52
    .line 53
    const/4 v3, 0x1

    .line 54
    invoke-direct {v2, v3, v0}, Ld1/j0;-><init>(ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iput-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->j0:Ld1/j0;

    .line 58
    .line 59
    goto :goto_2

    .line 60
    :catch_0
    move-exception v0

    .line 61
    goto :goto_3

    .line 62
    :catch_1
    move-exception v0

    .line 63
    goto :goto_4

    .line 64
    :cond_3
    :goto_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 65
    .line 66
    .line 67
    move-result-wide v2

    .line 68
    const-string v0, "createAudioDecoder"

    .line 69
    .line 70
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 74
    .line 75
    invoke-virtual {p0, v0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->J(Lv0/t;)Lc1/e;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 80
    .line 81
    iget-wide v4, p0, Ld1/a;->v:J

    .line 82
    .line 83
    invoke-interface {v0, v4, v5}, Lc1/e;->setOutputStartTimeUs(J)V

    .line 84
    .line 85
    .line 86
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 87
    .line 88
    iget-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->j0:Ld1/j0;

    .line 89
    .line 90
    invoke-interface {v0, p0, v4}, Lc1/e;->setCallback(Lc1/d;Ljava/util/concurrent/Executor;)V

    .line 91
    .line 92
    .line 93
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 94
    .line 95
    .line 96
    move-wide v5, v2

    .line 97
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 98
    .line 99
    .line 100
    move-result-wide v3

    .line 101
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 102
    .line 103
    invoke-interface {v0}, Lc1/e;->getName()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    sub-long v5, v3, v5

    .line 108
    .line 109
    iget-object v0, v1, Ll3/i0;->k:Ljava/lang/Object;

    .line 110
    .line 111
    move-object v9, v0

    .line 112
    check-cast v9, Landroid/os/Handler;

    .line 113
    .line 114
    if-eqz v9, :cond_4

    .line 115
    .line 116
    new-instance v0, Lf1/s;

    .line 117
    .line 118
    invoke-direct/range {v0 .. v6}, Lf1/s;-><init>(Ll3/i0;Ljava/lang/String;JJ)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v9, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 122
    .line 123
    .line 124
    :cond_4
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 125
    .line 126
    iget v2, v0, Ld1/c;->a:I

    .line 127
    .line 128
    add-int/lit8 v2, v2, 0x1

    .line 129
    .line 130
    iput v2, v0, Ld1/c;->a:I
    :try_end_0
    .catch Lc1/f; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    .line 131
    .line 132
    return-void

    .line 133
    :goto_3
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 134
    .line 135
    invoke-virtual {p0, v0, v1, v7, v8}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    throw v0

    .line 140
    :goto_4
    const-string v2, "DecoderAudioRenderer"

    .line 141
    .line 142
    const-string v3, "Audio codec error"

    .line 143
    .line 144
    invoke-static {v2, v3, v0}, Ly0/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 145
    .line 146
    .line 147
    iget-object v2, v1, Ll3/i0;->k:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast v2, Landroid/os/Handler;

    .line 150
    .line 151
    if-eqz v2, :cond_5

    .line 152
    .line 153
    new-instance v3, Lf1/s;

    .line 154
    .line 155
    const/4 v4, 0x0

    .line 156
    invoke-direct {v3, v1, v0, v4}, Lf1/s;-><init>(Ll3/i0;Ljava/lang/Object;I)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 160
    .line 161
    .line 162
    :cond_5
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 163
    .line 164
    invoke-virtual {p0, v0, v1, v7, v8}, Ld1/a;->h(Ljava/lang/Throwable;Lv0/t;ZI)Ld1/k;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    throw v0
.end method

.method public final N(Ll4/c;)V
    .locals 8

    .line 1
    iget-object v0, p1, Ll4/c;->l:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v4, v0

    .line 4
    check-cast v4, Lv0/t;

    .line 5
    .line 6
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-object p1, p1, Ll4/c;->k:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p1, Li1/i;

    .line 12
    .line 13
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P:Li1/i;

    .line 14
    .line 15
    invoke-static {v0, p1}, La0/h;->E(Li1/i;Li1/i;)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P:Li1/i;

    .line 19
    .line 20
    iget-object v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 21
    .line 22
    iput-object v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 23
    .line 24
    iget v0, v4, Lv0/t;->N:I

    .line 25
    .line 26
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->I:I

    .line 27
    .line 28
    iget v0, v4, Lv0/t;->O:I

    .line 29
    .line 30
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->J:I

    .line 31
    .line 32
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 33
    .line 34
    iget-object v7, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 35
    .line 36
    if-nez v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M()V

    .line 39
    .line 40
    .line 41
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 42
    .line 43
    iget-object v0, v7, Ll3/i0;->k:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v0, Landroid/os/Handler;

    .line 46
    .line 47
    if-eqz v0, :cond_4

    .line 48
    .line 49
    new-instance v1, Ld1/x;

    .line 50
    .line 51
    const/16 v2, 0xa

    .line 52
    .line 53
    const/4 v3, 0x0

    .line 54
    invoke-direct {v1, v7, p1, v3, v2}, Ld1/x;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :cond_0
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 62
    .line 63
    if-eq p1, v1, :cond_1

    .line 64
    .line 65
    new-instance v1, Ld1/d;

    .line 66
    .line 67
    invoke-interface {v0}, Lc1/e;->getName()Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    const/4 v5, 0x0

    .line 72
    const/16 v6, 0x80

    .line 73
    .line 74
    invoke-direct/range {v1 .. v6}, Ld1/d;-><init>(Ljava/lang/String;Lv0/t;Lv0/t;II)V

    .line 75
    .line 76
    .line 77
    goto :goto_0

    .line 78
    :cond_1
    invoke-interface {v0}, Lc1/e;->getName()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    new-instance v1, Ld1/d;

    .line 83
    .line 84
    const/4 v5, 0x0

    .line 85
    const/4 v6, 0x1

    .line 86
    invoke-direct/range {v1 .. v6}, Ld1/d;-><init>(Ljava/lang/String;Lv0/t;Lv0/t;II)V

    .line 87
    .line 88
    .line 89
    :goto_0
    iget p1, v1, Ld1/d;->d:I

    .line 90
    .line 91
    if-nez p1, :cond_3

    .line 92
    .line 93
    iget-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->R:Z

    .line 94
    .line 95
    const/4 v0, 0x1

    .line 96
    if-eqz p1, :cond_2

    .line 97
    .line 98
    iput v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 99
    .line 100
    goto :goto_1

    .line 101
    :cond_2
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O()V

    .line 102
    .line 103
    .line 104
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M()V

    .line 105
    .line 106
    .line 107
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    .line 108
    .line 109
    :cond_3
    :goto_1
    iget-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 110
    .line 111
    iget-object v0, v7, Ll3/i0;->k:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v0, Landroid/os/Handler;

    .line 114
    .line 115
    if-eqz v0, :cond_4

    .line 116
    .line 117
    new-instance v2, Ld1/x;

    .line 118
    .line 119
    const/16 v3, 0xa

    .line 120
    .line 121
    invoke-direct {v2, v7, p1, v1, v3}, Ld1/x;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 125
    .line 126
    .line 127
    :cond_4
    return-void
.end method

.method public final O()V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 3
    .line 4
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 8
    .line 9
    iput-boolean v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->R:Z

    .line 10
    .line 11
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    iput-wide v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d0:J

    .line 17
    .line 18
    iput-wide v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->e0:J

    .line 19
    .line 20
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 21
    .line 22
    if-eqz v1, :cond_1

    .line 23
    .line 24
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 25
    .line 26
    iget v3, v2, Ld1/c;->b:I

    .line 27
    .line 28
    add-int/lit8 v3, v3, 0x1

    .line 29
    .line 30
    iput v3, v2, Ld1/c;->b:I

    .line 31
    .line 32
    invoke-interface {v1}, Lc1/e;->release()V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 36
    .line 37
    invoke-interface {v1}, Lc1/e;->getName()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 42
    .line 43
    iget-object v3, v2, Ll3/i0;->k:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v3, Landroid/os/Handler;

    .line 46
    .line 47
    if-eqz v3, :cond_0

    .line 48
    .line 49
    new-instance v4, Lf1/s;

    .line 50
    .line 51
    const/4 v5, 0x5

    .line 52
    invoke-direct {v4, v2, v1, v5}, Lf1/s;-><init>(Ll3/i0;Ljava/lang/Object;I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 56
    .line 57
    .line 58
    :cond_0
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 59
    .line 60
    :cond_1
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 61
    .line 62
    invoke-static {v1, v0}, La0/h;->E(Li1/i;Li1/i;)V

    .line 63
    .line 64
    .line 65
    iput-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O:Li1/i;

    .line 66
    .line 67
    return-void
.end method

.method public final P(J)V
    .locals 2

    .line 1
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->X:J

    .line 2
    .line 3
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    cmp-long v0, p1, v0

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 13
    .line 14
    check-cast v0, Lf1/r0;

    .line 15
    .line 16
    iput-wide p1, v0, Lf1/r0;->J:J

    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public final Q()V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->n()Z

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 5
    .line 6
    check-cast v0, Lf1/r0;

    .line 7
    .line 8
    invoke-virtual {v0}, Lf1/r0;->h()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    const-wide/high16 v2, -0x8000000000000000L

    .line 13
    .line 14
    cmp-long v2, v0, v2

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    iget-boolean v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->U:Z

    .line 19
    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    iget-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->T:J

    .line 24
    .line 25
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->max(JJ)J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    :goto_0
    iput-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->T:J

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->U:Z

    .line 33
    .line 34
    :cond_1
    return-void
.end method

.method public final a()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->i0:Ld1/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ld1/o0;->a()V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final b(ILjava/lang/Object;)V
    .locals 8

    .line 1
    const/4 v0, 0x2

    .line 2
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 3
    .line 4
    if-eq p1, v0, :cond_c

    .line 5
    .line 6
    const/4 v0, 0x3

    .line 7
    if-eq p1, v0, :cond_9

    .line 8
    .line 9
    const/4 v0, 0x6

    .line 10
    if-eq p1, v0, :cond_6

    .line 11
    .line 12
    const/16 v0, 0x13

    .line 13
    .line 14
    if-eq p1, v0, :cond_3

    .line 15
    .line 16
    const/16 v0, 0x14

    .line 17
    .line 18
    if-eq p1, v0, :cond_2

    .line 19
    .line 20
    packed-switch p1, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    goto/16 :goto_3

    .line 24
    .line 25
    :pswitch_0
    check-cast p2, Landroid/media/AudioDeviceInfo;

    .line 26
    .line 27
    check-cast v1, Lf1/r0;

    .line 28
    .line 29
    iput-object p2, v1, Lf1/r0;->W:Landroid/media/AudioDeviceInfo;

    .line 30
    .line 31
    iget-object p1, v1, Lf1/r0;->t:Lf1/g0;

    .line 32
    .line 33
    if-eqz p1, :cond_d

    .line 34
    .line 35
    iget-object p1, p1, Lf1/g0;->a:Landroid/media/AudioTrack;

    .line 36
    .line 37
    invoke-virtual {p1, p2}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :pswitch_1
    check-cast p2, Ld1/o0;

    .line 42
    .line 43
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->i0:Ld1/o0;

    .line 44
    .line 45
    return-void

    .line 46
    :pswitch_2
    check-cast p2, Ljava/lang/Integer;

    .line 47
    .line 48
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    check-cast v1, Lf1/r0;

    .line 53
    .line 54
    invoke-virtual {v1, p1}, Lf1/r0;->z(I)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :pswitch_3
    check-cast p2, Ljava/lang/Boolean;

    .line 59
    .line 60
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    check-cast v1, Lf1/r0;

    .line 65
    .line 66
    iput-boolean p1, v1, Lf1/r0;->y:Z

    .line 67
    .line 68
    invoke-virtual {v1}, Lf1/r0;->D()Z

    .line 69
    .line 70
    .line 71
    move-result p1

    .line 72
    if-eqz p1, :cond_0

    .line 73
    .line 74
    sget-object p1, Lv0/u0;->d:Lv0/u0;

    .line 75
    .line 76
    :goto_0
    move-object v3, p1

    .line 77
    goto :goto_1

    .line 78
    :cond_0
    iget-object p1, v1, Lf1/r0;->x:Lv0/u0;

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :goto_1
    new-instance v2, Lf1/p0;

    .line 82
    .line 83
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    invoke-direct/range {v2 .. v7}, Lf1/p0;-><init>(Lv0/u0;JJ)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v1}, Lf1/r0;->p()Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-eqz p1, :cond_1

    .line 101
    .line 102
    iput-object v2, v1, Lf1/r0;->v:Lf1/p0;

    .line 103
    .line 104
    return-void

    .line 105
    :cond_1
    iput-object v2, v1, Lf1/r0;->w:Lf1/p0;

    .line 106
    .line 107
    return-void

    .line 108
    :cond_2
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 109
    .line 110
    .line 111
    check-cast p2, Lf1/r;

    .line 112
    .line 113
    check-cast v1, Lf1/r0;

    .line 114
    .line 115
    invoke-virtual {v1, p2}, Lf1/r0;->y(Lf1/r;)V

    .line 116
    .line 117
    .line 118
    return-void

    .line 119
    :cond_3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    .line 121
    .line 122
    check-cast p2, Ljava/lang/Integer;

    .line 123
    .line 124
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 125
    .line 126
    .line 127
    move-result p1

    .line 128
    check-cast v1, Lf1/r0;

    .line 129
    .line 130
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    .line 132
    .line 133
    const/4 p2, -0x1

    .line 134
    if-eqz p1, :cond_4

    .line 135
    .line 136
    if-eq p1, p2, :cond_4

    .line 137
    .line 138
    goto :goto_2

    .line 139
    :cond_4
    move p1, p2

    .line 140
    :goto_2
    iget p2, v1, Lf1/r0;->X:I

    .line 141
    .line 142
    if-ne p2, p1, :cond_5

    .line 143
    .line 144
    goto :goto_3

    .line 145
    :cond_5
    iput p1, v1, Lf1/r0;->X:I

    .line 146
    .line 147
    invoke-virtual {v1}, Lf1/r0;->v()V

    .line 148
    .line 149
    .line 150
    return-void

    .line 151
    :cond_6
    check-cast p2, Lv0/e;

    .line 152
    .line 153
    check-cast v1, Lf1/r0;

    .line 154
    .line 155
    iget-object p1, v1, Lf1/r0;->V:Lv0/e;

    .line 156
    .line 157
    invoke-virtual {p1, p2}, Lv0/e;->equals(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result p1

    .line 161
    if-eqz p1, :cond_7

    .line 162
    .line 163
    goto :goto_3

    .line 164
    :cond_7
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    .line 166
    .line 167
    iget-object p1, v1, Lf1/r0;->t:Lf1/g0;

    .line 168
    .line 169
    if-eqz p1, :cond_8

    .line 170
    .line 171
    iget-object p1, v1, Lf1/r0;->V:Lv0/e;

    .line 172
    .line 173
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 174
    .line 175
    .line 176
    :cond_8
    iput-object p2, v1, Lf1/r0;->V:Lv0/e;

    .line 177
    .line 178
    return-void

    .line 179
    :cond_9
    check-cast p2, Lv0/d;

    .line 180
    .line 181
    check-cast v1, Lf1/r0;

    .line 182
    .line 183
    iget-object p1, v1, Lf1/r0;->u:Lv0/d;

    .line 184
    .line 185
    invoke-virtual {p1, p2}, Lv0/d;->equals(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result p1

    .line 189
    if-eqz p1, :cond_a

    .line 190
    .line 191
    goto :goto_3

    .line 192
    :cond_a
    iput-object p2, v1, Lf1/r0;->u:Lv0/d;

    .line 193
    .line 194
    iget-boolean p1, v1, Lf1/r0;->Y:Z

    .line 195
    .line 196
    if-eqz p1, :cond_b

    .line 197
    .line 198
    goto :goto_3

    .line 199
    :cond_b
    invoke-virtual {v1}, Lf1/r0;->v()V

    .line 200
    .line 201
    .line 202
    return-void

    .line 203
    :cond_c
    check-cast p2, Ljava/lang/Float;

    .line 204
    .line 205
    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    .line 206
    .line 207
    .line 208
    move-result p1

    .line 209
    check-cast v1, Lf1/r0;

    .line 210
    .line 211
    iget p2, v1, Lf1/r0;->K:F

    .line 212
    .line 213
    cmpl-float p2, p2, p1

    .line 214
    .line 215
    if-eqz p2, :cond_d

    .line 216
    .line 217
    iput p1, v1, Lf1/r0;->K:F

    .line 218
    .line 219
    invoke-virtual {v1}, Lf1/r0;->p()Z

    .line 220
    .line 221
    .line 222
    move-result p1

    .line 223
    if-eqz p1, :cond_d

    .line 224
    .line 225
    iget-object p1, v1, Lf1/r0;->t:Lf1/g0;

    .line 226
    .line 227
    iget p2, v1, Lf1/r0;->K:F

    .line 228
    .line 229
    iget-object p1, p1, Lf1/g0;->a:Landroid/media/AudioTrack;

    .line 230
    .line 231
    invoke-virtual {p1, p2}, Landroid/media/AudioTrack;->setVolume(F)I

    .line 232
    .line 233
    .line 234
    :cond_d
    :goto_3
    return-void

    .line 235
    :pswitch_data_0
    .packed-switch 0x9
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final c()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->i0:Ld1/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Ld1/o0;->a()V

    .line 6
    .line 7
    .line 8
    :cond_0
    return-void
.end method

.method public final d()Lv0/u0;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast v0, Lf1/r0;

    .line 4
    .line 5
    iget-object v0, v0, Lf1/r0;->x:Lv0/u0;

    .line 6
    .line 7
    return-object v0
.end method

.method public final e(Lv0/u0;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast v0, Lf1/r0;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lf1/r0;->B(Lv0/u0;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final f()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->a0:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iput-boolean v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->a0:Z

    .line 5
    .line 6
    return v0
.end method

.method public final g()J
    .locals 2

    .line 1
    iget v0, p0, Ld1/a;->r:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q()V

    .line 7
    .line 8
    .line 9
    :cond_0
    iget-wide v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->T:J

    .line 10
    .line 11
    return-wide v0
.end method

.method public final j(JJ)J
    .locals 7

    .line 1
    iget-object p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast p3, Lf1/r0;

    .line 4
    .line 5
    invoke-virtual {p3}, Lf1/r0;->n()Z

    .line 6
    .line 7
    .line 8
    move-result p4

    .line 9
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    if-eqz p4, :cond_0

    .line 15
    .line 16
    iget-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 17
    .line 18
    cmp-long p4, v2, v0

    .line 19
    .line 20
    if-eqz p4, :cond_0

    .line 21
    .line 22
    const/4 p4, 0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 p4, 0x0

    .line 25
    :goto_0
    iget-boolean v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->c0:Z

    .line 26
    .line 27
    const-wide/16 v3, 0x2710

    .line 28
    .line 29
    if-nez v2, :cond_2

    .line 30
    .line 31
    if-nez p4, :cond_1

    .line 32
    .line 33
    iget-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 34
    .line 35
    if-eqz p1, :cond_5

    .line 36
    .line 37
    :cond_1
    const-wide/32 p1, 0xf4240

    .line 38
    .line 39
    .line 40
    return-wide p1

    .line 41
    :cond_2
    invoke-virtual {p3}, Lf1/r0;->g()J

    .line 42
    .line 43
    .line 44
    move-result-wide v5

    .line 45
    iget-boolean p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->b0:Z

    .line 46
    .line 47
    if-eqz p3, :cond_5

    .line 48
    .line 49
    if-eqz p4, :cond_5

    .line 50
    .line 51
    cmp-long p3, v5, v0

    .line 52
    .line 53
    if-nez p3, :cond_3

    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_3
    iget-wide p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 57
    .line 58
    sub-long/2addr p3, p1

    .line 59
    invoke-static {v5, v6, p3, p4}, Ljava/lang/Math;->min(JJ)J

    .line 60
    .line 61
    .line 62
    move-result-wide p1

    .line 63
    long-to-float p1, p1

    .line 64
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d()Lv0/u0;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    if-eqz p2, :cond_4

    .line 69
    .line 70
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->d()Lv0/u0;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    iget p2, p2, Lv0/u0;->a:F

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_4
    const/high16 p2, 0x3f800000    # 1.0f

    .line 78
    .line 79
    :goto_1
    div-float/2addr p1, p2

    .line 80
    const/high16 p2, 0x40000000    # 2.0f

    .line 81
    .line 82
    div-float/2addr p1, p2

    .line 83
    float-to-long p1, p1

    .line 84
    invoke-static {v3, v4, p1, p2}, Ljava/lang/Math;->max(JJ)J

    .line 85
    .line 86
    .line 87
    move-result-wide p1

    .line 88
    return-wide p1

    .line 89
    :cond_5
    :goto_2
    return-wide v3
.end method

.method public final k()Ld1/z0;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final l()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "FfmpegAudioRenderer"

    .line 2
    .line 3
    return-object v0
.end method

.method public final n()Z
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 6
    .line 7
    check-cast v0, Lf1/r0;

    .line 8
    .line 9
    invoke-virtual {v0}, Lf1/r0;->p()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    iget-boolean v1, v0, Lf1/r0;->O:Z

    .line 16
    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    invoke-virtual {v0}, Lf1/r0;->n()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    :cond_0
    const/4 v0, 0x1

    .line 26
    return v0

    .line 27
    :cond_1
    const/4 v0, 0x0

    .line 28
    return v0
.end method

.method public final o()Z
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast v0, Lf1/r0;

    .line 4
    .line 5
    invoke-virtual {v0}, Lf1/r0;->n()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iput-wide v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 18
    .line 19
    iput-boolean v3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->h0:Z

    .line 20
    .line 21
    return v3

    .line 22
    :cond_0
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->h0:Z

    .line 23
    .line 24
    if-eqz v0, :cond_2

    .line 25
    .line 26
    iget-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->c0:Z

    .line 27
    .line 28
    if-eqz v0, :cond_2

    .line 29
    .line 30
    invoke-virtual {p0}, Ld1/a;->p()Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_2

    .line 35
    .line 36
    invoke-virtual {p0}, Ld1/a;->m()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_2

    .line 41
    .line 42
    iget-object v0, p0, Ld1/a;->q:Ly0/f0;

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 48
    .line 49
    .line 50
    move-result-wide v4

    .line 51
    iget-wide v6, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 52
    .line 53
    cmp-long v0, v6, v1

    .line 54
    .line 55
    if-nez v0, :cond_1

    .line 56
    .line 57
    iput-wide v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 58
    .line 59
    return v3

    .line 60
    :cond_1
    sub-long/2addr v4, v6

    .line 61
    const-wide/16 v0, 0x64

    .line 62
    .line 63
    cmp-long v0, v4, v0

    .line 64
    .line 65
    if-gez v0, :cond_2

    .line 66
    .line 67
    return v3

    .line 68
    :cond_2
    const/4 v0, 0x0

    .line 69
    return v0
.end method

.method public final q()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->H:Lv0/t;

    .line 5
    .line 6
    const/4 v2, 0x1

    .line 7
    iput-boolean v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->S:Z

    .line 8
    .line 9
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v2, v3}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P(J)V

    .line 15
    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    iput-boolean v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->a0:Z

    .line 19
    .line 20
    iput-boolean v4, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->b0:Z

    .line 21
    .line 22
    iput-wide v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 23
    .line 24
    :try_start_0
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P:Li1/i;

    .line 25
    .line 26
    invoke-static {v2, v1}, La0/h;->E(Li1/i;Li1/i;)V

    .line 27
    .line 28
    .line 29
    iput-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P:Li1/i;

    .line 30
    .line 31
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O()V

    .line 32
    .line 33
    .line 34
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 35
    .line 36
    check-cast v1, Lf1/r0;

    .line 37
    .line 38
    invoke-virtual {v1}, Lf1/r0;->w()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ll3/i0;->C(Ld1/c;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :catchall_0
    move-exception v1

    .line 48
    iget-object v2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 49
    .line 50
    invoke-virtual {v0, v2}, Ll3/i0;->C(Ld1/c;)V

    .line 51
    .line 52
    .line 53
    throw v1
.end method

.method public final r(ZZ)V
    .locals 3

    .line 1
    new-instance p1, Ld1/c;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->G:Ld1/c;

    .line 7
    .line 8
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->D:Ll3/i0;

    .line 9
    .line 10
    iget-object v0, p2, Ll3/i0;->k:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Landroid/os/Handler;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    new-instance v1, Lf1/s;

    .line 17
    .line 18
    const/4 v2, 0x6

    .line 19
    invoke-direct {v1, p2, p1, v2}, Lf1/s;-><init>(Ll3/i0;Ljava/lang/Object;I)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 23
    .line 24
    .line 25
    :cond_0
    iget-object p1, p0, Ld1/a;->n:Ld1/x1;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    iget-boolean p1, p1, Ld1/x1;->b:Z

    .line 31
    .line 32
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 33
    .line 34
    if-eqz p1, :cond_1

    .line 35
    .line 36
    move-object p1, p2

    .line 37
    check-cast p1, Lf1/r0;

    .line 38
    .line 39
    iget-boolean v0, p1, Lf1/r0;->S:Z

    .line 40
    .line 41
    invoke-static {v0}, Landroid/support/v4/media/session/b;->s(Z)V

    .line 42
    .line 43
    .line 44
    iget-boolean v0, p1, Lf1/r0;->Y:Z

    .line 45
    .line 46
    if-nez v0, :cond_2

    .line 47
    .line 48
    const/4 v0, 0x1

    .line 49
    iput-boolean v0, p1, Lf1/r0;->Y:Z

    .line 50
    .line 51
    invoke-virtual {p1}, Lf1/r0;->v()V

    .line 52
    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_1
    move-object p1, p2

    .line 56
    check-cast p1, Lf1/r0;

    .line 57
    .line 58
    iget-boolean v0, p1, Lf1/r0;->Y:Z

    .line 59
    .line 60
    if-eqz v0, :cond_2

    .line 61
    .line 62
    const/4 v0, 0x0

    .line 63
    iput-boolean v0, p1, Lf1/r0;->Y:Z

    .line 64
    .line 65
    invoke-virtual {p1}, Lf1/r0;->v()V

    .line 66
    .line 67
    .line 68
    :cond_2
    :goto_0
    iget-object p1, p0, Ld1/a;->p:Le1/n;

    .line 69
    .line 70
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    check-cast p2, Lf1/r0;

    .line 74
    .line 75
    iput-object p1, p2, Lf1/r0;->m:Le1/n;

    .line 76
    .line 77
    iget-object p1, p0, Ld1/a;->q:Ly0/f0;

    .line 78
    .line 79
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    iget-object v0, p2, Lf1/r0;->r:Lf1/r;

    .line 83
    .line 84
    check-cast v0, Lf1/i0;

    .line 85
    .line 86
    iput-object p1, v0, Lf1/i0;->g:Ly0/f0;

    .line 87
    .line 88
    new-instance p1, Landroidx/lifecycle/c0;

    .line 89
    .line 90
    const/16 v0, 0xf

    .line 91
    .line 92
    invoke-direct {p1, v0, p0}, Landroidx/lifecycle/c0;-><init>(ILjava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    iput-object p1, p2, Lf1/r0;->n:Landroidx/lifecycle/c0;

    .line 96
    .line 97
    return-void
.end method

.method public final s(JZZ)V
    .locals 0

    .line 1
    iget-object p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast p3, Lf1/r0;

    .line 4
    .line 5
    invoke-virtual {p3}, Lf1/r0;->f()V

    .line 6
    .line 7
    .line 8
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->T:J

    .line 9
    .line 10
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->f0:J

    .line 16
    .line 17
    iput-wide p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->h0:Z

    .line 21
    .line 22
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->a0:Z

    .line 23
    .line 24
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->b0:Z

    .line 25
    .line 26
    const/4 p2, 0x1

    .line 27
    iput-boolean p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->U:Z

    .line 28
    .line 29
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->V:Z

    .line 30
    .line 31
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->W:Z

    .line 32
    .line 33
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 34
    .line 35
    if-eqz p2, :cond_2

    .line 36
    .line 37
    iget p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q:I

    .line 38
    .line 39
    if-eqz p2, :cond_0

    .line 40
    .line 41
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->O()V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M()V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :cond_0
    const/4 p2, 0x0

    .line 49
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->M:Lc1/h;

    .line 50
    .line 51
    iget-object p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 52
    .line 53
    if-eqz p3, :cond_1

    .line 54
    .line 55
    invoke-virtual {p3}, Landroidx/media3/decoder/SimpleDecoderOutputBuffer;->i()V

    .line 56
    .line 57
    .line 58
    iput-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->N:Landroidx/media3/decoder/SimpleDecoderOutputBuffer;

    .line 59
    .line 60
    :cond_1
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->L:Lc1/e;

    .line 61
    .line 62
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 63
    .line 64
    .line 65
    invoke-interface {p2}, Lc1/e;->flush()V

    .line 66
    .line 67
    .line 68
    iget-wide p3, p0, Ld1/a;->v:J

    .line 69
    .line 70
    invoke-interface {p2, p3, p4}, Lc1/e;->setOutputStartTimeUs(J)V

    .line 71
    .line 72
    .line 73
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->R:Z

    .line 74
    .line 75
    :cond_2
    return-void
.end method

.method public final w()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 2
    .line 3
    check-cast v0, Lf1/r0;

    .line 4
    .line 5
    invoke-virtual {v0}, Lf1/r0;->r()V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->c0:Z

    .line 10
    .line 11
    return-void
.end method

.method public final x()V
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Q()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->E:Lf1/a0;

    .line 5
    .line 6
    check-cast v0, Lf1/r0;

    .line 7
    .line 8
    invoke-virtual {v0}, Lf1/r0;->q()V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->c0:Z

    .line 13
    .line 14
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->b0:Z

    .line 15
    .line 16
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    iput-wide v1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->g0:J

    .line 22
    .line 23
    iput-boolean v0, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->h0:Z

    .line 24
    .line 25
    return-void
.end method

.method public final y([Lv0/t;JJLr1/b0;)V
    .locals 2

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-boolean p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->K:Z

    .line 3
    .line 4
    iget-wide p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->X:J

    .line 5
    .line 6
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    cmp-long p1, p1, v0

    .line 12
    .line 13
    if-nez p1, :cond_0

    .line 14
    .line 15
    invoke-virtual {p0, p4, p5}, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->P(J)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 20
    .line 21
    iget-object p2, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Y:[J

    .line 22
    .line 23
    array-length p3, p2

    .line 24
    if-ne p1, p3, :cond_1

    .line 25
    .line 26
    new-instance p1, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string p3, "Too many stream changes, so dropping offset: "

    .line 29
    .line 30
    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget p3, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 34
    .line 35
    add-int/lit8 p3, p3, -0x1

    .line 36
    .line 37
    aget-wide v0, p2, p3

    .line 38
    .line 39
    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const-string p3, "DecoderAudioRenderer"

    .line 47
    .line 48
    invoke-static {p3, p1}, Ly0/a;->l(Ljava/lang/String;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    add-int/lit8 p1, p1, 0x1

    .line 53
    .line 54
    iput p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 55
    .line 56
    :goto_0
    iget p1, p0, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->Z:I

    .line 57
    .line 58
    add-int/lit8 p1, p1, -0x1

    .line 59
    .line 60
    aput-wide p4, p2, p1

    .line 61
    .line 62
    return-void
.end method
