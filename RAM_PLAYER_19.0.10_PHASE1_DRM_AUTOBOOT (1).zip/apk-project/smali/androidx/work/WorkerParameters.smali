.class public final Landroidx/work/WorkerParameters;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/UUID;

.field public b:Lc4/f;

.field public c:I

.field public d:Ljava/util/concurrent/ExecutorService;

.field public e:Ll4/i;

.field public f:Lc4/d0;
