.class public interface abstract La7/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln6/a;


# virtual methods
.method public abstract c()I
.end method
