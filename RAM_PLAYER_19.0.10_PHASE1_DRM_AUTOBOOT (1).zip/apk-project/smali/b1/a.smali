.class public final Lb1/a;
.super La1/c;
.source "SourceFile"


# instance fields
.field public final o:Lo7/d;

.field public final p:Ll4/c;

.field public final q:Ljava/lang/String;

.field public final r:Ll4/c;

.field public s:La1/q;

.field public t:Lo7/y;

.field public u:Ljava/io/InputStream;

.field public v:Z

.field public w:J

.field public x:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "media3.datasource.okhttp"

    .line 2
    .line 3
    invoke-static {v0}, Lv0/l0;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(Lo7/d;Ljava/lang/String;Ll4/c;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, La1/c;-><init>(Z)V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lb1/a;->o:Lo7/d;

    .line 9
    .line 10
    iput-object p2, p0, Lb1/a;->q:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p3, p0, Lb1/a;->r:Ll4/c;

    .line 13
    .line 14
    new-instance p1, Ll4/c;

    .line 15
    .line 16
    const/4 p2, 0x1

    .line 17
    invoke-direct {p1, p2}, Ll4/c;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lb1/a;->p:Ll4/c;

    .line 21
    .line 22
    return-void
.end method

.method public static m(Ls7/i;)Lo7/y;
    .locals 7

    .line 1
    new-instance v0, Lcom/google/common/util/concurrent/y;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Landroidx/lifecycle/c0;

    .line 7
    .line 8
    const/4 v2, 0x2

    .line 9
    invoke-direct {v1, v2, v0}, Landroidx/lifecycle/c0;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iget-object v2, p0, Ls7/i;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x1

    .line 16
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_5

    .line 21
    .line 22
    sget-object v2, Lw7/n;->a:Lw7/n;

    .line 23
    .line 24
    sget-object v2, Lw7/n;->a:Lw7/n;

    .line 25
    .line 26
    invoke-virtual {v2}, Lw7/n;->g()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    iput-object v2, p0, Ls7/i;->p:Ljava/lang/Object;

    .line 31
    .line 32
    iget-object v2, p0, Ls7/i;->k:Lo7/u;

    .line 33
    .line 34
    iget-object v2, v2, Lo7/u;->k:Lo7/l;

    .line 35
    .line 36
    new-instance v3, Ls7/f;

    .line 37
    .line 38
    invoke-direct {v3, p0, v1}, Ls7/f;-><init>(Ls7/i;Landroidx/lifecycle/c0;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    monitor-enter v2

    .line 45
    :try_start_0
    iget-object v1, v2, Lo7/l;->d:Ljava/util/ArrayDeque;

    .line 46
    .line 47
    invoke-virtual {v1, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    iget-object v1, p0, Ls7/i;->l:Le6/q;

    .line 51
    .line 52
    iget-object v1, v1, Le6/q;->c:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v1, Lo7/q;

    .line 55
    .line 56
    iget-object v1, v1, Lo7/q;->d:Ljava/lang/String;

    .line 57
    .line 58
    iget-object v4, v2, Lo7/l;->e:Ljava/util/ArrayDeque;

    .line 59
    .line 60
    invoke-virtual {v4}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    :cond_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_1

    .line 69
    .line 70
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    check-cast v5, Ls7/f;

    .line 75
    .line 76
    iget-object v6, v5, Ls7/f;->m:Ls7/i;

    .line 77
    .line 78
    iget-object v6, v6, Ls7/i;->l:Le6/q;

    .line 79
    .line 80
    iget-object v6, v6, Le6/q;->c:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v6, Lo7/q;

    .line 83
    .line 84
    iget-object v6, v6, Lo7/q;->d:Ljava/lang/String;

    .line 85
    .line 86
    invoke-static {v6, v1}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    if-eqz v6, :cond_0

    .line 91
    .line 92
    goto :goto_0

    .line 93
    :cond_1
    iget-object v4, v2, Lo7/l;->d:Ljava/util/ArrayDeque;

    .line 94
    .line 95
    invoke-virtual {v4}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    :cond_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v5

    .line 103
    if-eqz v5, :cond_3

    .line 104
    .line 105
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v5

    .line 109
    check-cast v5, Ls7/f;

    .line 110
    .line 111
    iget-object v6, v5, Ls7/f;->m:Ls7/i;

    .line 112
    .line 113
    iget-object v6, v6, Ls7/i;->l:Le6/q;

    .line 114
    .line 115
    iget-object v6, v6, Le6/q;->c:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v6, Lo7/q;

    .line 118
    .line 119
    iget-object v6, v6, Lo7/q;->d:Ljava/lang/String;

    .line 120
    .line 121
    invoke-static {v6, v1}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result v6

    .line 125
    if-eqz v6, :cond_2

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_3
    const/4 v5, 0x0

    .line 129
    :goto_0
    if-eqz v5, :cond_4

    .line 130
    .line 131
    iget-object v1, v5, Ls7/f;->l:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 132
    .line 133
    iput-object v1, v3, Ls7/f;->l:Ljava/util/concurrent/atomic/AtomicInteger;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 134
    .line 135
    :cond_4
    monitor-exit v2

    .line 136
    invoke-virtual {v2}, Lo7/l;->d()V

    .line 137
    .line 138
    .line 139
    :try_start_1
    invoke-virtual {v0}, Lcom/google/common/util/concurrent/y;->get()Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, Lo7/y;
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1 .. :try_end_1} :catch_0

    .line 144
    .line 145
    return-object v0

    .line 146
    :catch_0
    move-exception p0

    .line 147
    new-instance v0, Ljava/io/IOException;

    .line 148
    .line 149
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 150
    .line 151
    .line 152
    throw v0

    .line 153
    :catch_1
    invoke-virtual {p0}, Ls7/i;->d()V

    .line 154
    .line 155
    .line 156
    new-instance p0, Ljava/io/InterruptedIOException;

    .line 157
    .line 158
    invoke-direct {p0}, Ljava/io/InterruptedIOException;-><init>()V

    .line 159
    .line 160
    .line 161
    throw p0

    .line 162
    :catchall_0
    move-exception p0

    .line 163
    monitor-exit v2

    .line 164
    throw p0

    .line 165
    :cond_5
    const-string p0, "Already Executed"

    .line 166
    .line 167
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 168
    .line 169
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    throw v0
.end method


# virtual methods
.method public final B(La1/q;)J
    .locals 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iput-object v0, v1, Lb1/a;->s:La1/q;

    .line 6
    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    iput-wide v2, v1, Lb1/a;->x:J

    .line 10
    .line 11
    iput-wide v2, v1, Lb1/a;->w:J

    .line 12
    .line 13
    invoke-virtual {v1}, La1/c;->f()V

    .line 14
    .line 15
    .line 16
    iget-wide v4, v0, La1/q;->e:J

    .line 17
    .line 18
    iget v6, v0, La1/q;->b:I

    .line 19
    .line 20
    iget-wide v7, v0, La1/q;->f:J

    .line 21
    .line 22
    iget-object v9, v0, La1/q;->a:Landroid/net/Uri;

    .line 23
    .line 24
    invoke-virtual {v9}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v9

    .line 28
    const-string v10, "<this>"

    .line 29
    .line 30
    invoke-static {v9, v10}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    const/4 v11, 0x0

    .line 34
    :try_start_0
    new-instance v12, Lo7/p;

    .line 35
    .line 36
    invoke-direct {v12}, Lo7/p;-><init>()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v12, v11, v9}, Lo7/p;->e(Lo7/q;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v12}, Lo7/p;->c()Lo7/q;

    .line 43
    .line 44
    .line 45
    move-result-object v9
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    goto :goto_0

    .line 47
    :catch_0
    move-object v9, v11

    .line 48
    :goto_0
    if-eqz v9, :cond_e

    .line 49
    .line 50
    new-instance v12, Lb0/d;

    .line 51
    .line 52
    invoke-direct {v12}, Lb0/d;-><init>()V

    .line 53
    .line 54
    .line 55
    iput-object v9, v12, Lb0/d;->m:Ljava/lang/Object;

    .line 56
    .line 57
    new-instance v9, Ljava/util/HashMap;

    .line 58
    .line 59
    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    .line 60
    .line 61
    .line 62
    iget-object v13, v1, Lb1/a;->r:Ll4/c;

    .line 63
    .line 64
    if-eqz v13, :cond_0

    .line 65
    .line 66
    invoke-virtual {v13}, Ll4/c;->n()Ljava/util/Map;

    .line 67
    .line 68
    .line 69
    move-result-object v13

    .line 70
    invoke-virtual {v9, v13}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 71
    .line 72
    .line 73
    :cond_0
    iget-object v13, v1, Lb1/a;->p:Ll4/c;

    .line 74
    .line 75
    invoke-virtual {v13}, Ll4/c;->n()Ljava/util/Map;

    .line 76
    .line 77
    .line 78
    move-result-object v13

    .line 79
    invoke-virtual {v9, v13}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 80
    .line 81
    .line 82
    iget-object v13, v0, La1/q;->d:Ljava/util/Map;

    .line 83
    .line 84
    invoke-virtual {v9, v13}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v9}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 88
    .line 89
    .line 90
    move-result-object v9

    .line 91
    invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 92
    .line 93
    .line 94
    move-result-object v9

    .line 95
    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 96
    .line 97
    .line 98
    move-result v13

    .line 99
    if-eqz v13, :cond_1

    .line 100
    .line 101
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v13

    .line 105
    check-cast v13, Ljava/util/Map$Entry;

    .line 106
    .line 107
    invoke-interface {v13}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v14

    .line 111
    check-cast v14, Ljava/lang/String;

    .line 112
    .line 113
    invoke-interface {v13}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v13

    .line 117
    check-cast v13, Ljava/lang/String;

    .line 118
    .line 119
    invoke-virtual {v12, v14, v13}, Lb0/d;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    goto :goto_1

    .line 123
    :cond_1
    invoke-static {v4, v5, v7, v8}, La1/d0;->a(JJ)Ljava/lang/String;

    .line 124
    .line 125
    .line 126
    move-result-object v9

    .line 127
    if-eqz v9, :cond_2

    .line 128
    .line 129
    iget-object v13, v12, Lb0/d;->n:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast v13, Lg5/d;

    .line 132
    .line 133
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    const-string v14, "Range"

    .line 137
    .line 138
    invoke-static {v14}, La/a;->d(Ljava/lang/String;)V

    .line 139
    .line 140
    .line 141
    invoke-static {v9, v14}, La/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v13, v14, v9}, Lg5/d;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    :cond_2
    iget-object v9, v1, Lb1/a;->q:Ljava/lang/String;

    .line 148
    .line 149
    if-eqz v9, :cond_3

    .line 150
    .line 151
    iget-object v13, v12, Lb0/d;->n:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v13, Lg5/d;

    .line 154
    .line 155
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    const-string v14, "User-Agent"

    .line 159
    .line 160
    invoke-static {v14}, La/a;->d(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-static {v9, v14}, La/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v13, v14, v9}, Lg5/d;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    :cond_3
    iget v9, v0, La1/q;->h:I

    .line 170
    .line 171
    const/4 v13, 0x1

    .line 172
    and-int/2addr v9, v13

    .line 173
    if-ne v9, v13, :cond_4

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :cond_4
    iget-object v9, v12, Lb0/d;->n:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v9, Lg5/d;

    .line 179
    .line 180
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 181
    .line 182
    .line 183
    const-string v14, "Accept-Encoding"

    .line 184
    .line 185
    invoke-static {v14}, La/a;->d(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    const-string v15, "identity"

    .line 189
    .line 190
    invoke-static {v15, v14}, La/a;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v9, v14, v15}, Lg5/d;->f(Ljava/lang/String;Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    :goto_2
    iget-object v9, v0, La1/q;->c:[B

    .line 197
    .line 198
    if-eqz v9, :cond_5

    .line 199
    .line 200
    invoke-static {v9}, Lo7/b;->f([B)Lo7/w;

    .line 201
    .line 202
    .line 203
    move-result-object v9

    .line 204
    goto :goto_3

    .line 205
    :cond_5
    const/4 v9, 0x2

    .line 206
    if-ne v6, v9, :cond_6

    .line 207
    .line 208
    sget-object v9, Ly0/k0;->b:[B

    .line 209
    .line 210
    invoke-static {v9, v10}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    invoke-static {v9}, Lo7/b;->f([B)Lo7/w;

    .line 214
    .line 215
    .line 216
    move-result-object v9

    .line 217
    goto :goto_3

    .line 218
    :cond_6
    move-object v9, v11

    .line 219
    :goto_3
    invoke-static {v6}, La1/q;->b(I)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v6

    .line 223
    invoke-virtual {v12, v6, v9}, Lb0/d;->g(Ljava/lang/String;Lo7/w;)V

    .line 224
    .line 225
    .line 226
    invoke-virtual {v12}, Lb0/d;->d()Le6/q;

    .line 227
    .line 228
    .line 229
    move-result-object v6

    .line 230
    iget-object v9, v1, Lb1/a;->o:Lo7/d;

    .line 231
    .line 232
    check-cast v9, Lo7/u;

    .line 233
    .line 234
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 235
    .line 236
    .line 237
    new-instance v10, Ls7/i;

    .line 238
    .line 239
    invoke-direct {v10, v9, v6}, Ls7/i;-><init>(Lo7/u;Le6/q;)V

    .line 240
    .line 241
    .line 242
    :try_start_1
    invoke-static {v10}, Lb1/a;->m(Ls7/i;)Lo7/y;

    .line 243
    .line 244
    .line 245
    move-result-object v6

    .line 246
    iput-object v6, v1, Lb1/a;->t:Lo7/y;

    .line 247
    .line 248
    iget-object v9, v6, Lo7/y;->q:Lo7/a0;

    .line 249
    .line 250
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 251
    .line 252
    .line 253
    invoke-virtual {v9}, Lo7/a0;->a()Ljava/io/InputStream;

    .line 254
    .line 255
    .line 256
    move-result-object v10

    .line 257
    iput-object v10, v1, Lb1/a;->u:Ljava/io/InputStream;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3

    .line 258
    .line 259
    iget v10, v6, Lo7/y;->n:I

    .line 260
    .line 261
    invoke-virtual {v6}, Lo7/y;->c()Z

    .line 262
    .line 263
    .line 264
    move-result v12

    .line 265
    const-string v14, "Content-Range"

    .line 266
    .line 267
    const-wide/16 v15, -0x1

    .line 268
    .line 269
    if-nez v12, :cond_a

    .line 270
    .line 271
    const/16 v9, 0x1a0

    .line 272
    .line 273
    if-ne v10, v9, :cond_8

    .line 274
    .line 275
    iget-object v12, v6, Lo7/y;->p:Lo7/o;

    .line 276
    .line 277
    invoke-virtual {v12, v14}, Lo7/o;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object v12

    .line 281
    invoke-static {v12}, La1/d0;->c(Ljava/lang/String;)J

    .line 282
    .line 283
    .line 284
    move-result-wide v17

    .line 285
    cmp-long v4, v4, v17

    .line 286
    .line 287
    if-nez v4, :cond_8

    .line 288
    .line 289
    iput-boolean v13, v1, Lb1/a;->v:Z

    .line 290
    .line 291
    invoke-virtual/range {p0 .. p1}, La1/c;->g(La1/q;)V

    .line 292
    .line 293
    .line 294
    cmp-long v0, v7, v15

    .line 295
    .line 296
    if-eqz v0, :cond_7

    .line 297
    .line 298
    move-wide v2, v7

    .line 299
    :cond_7
    return-wide v2

    .line 300
    :cond_8
    :try_start_2
    iget-object v0, v1, Lb1/a;->u:Ljava/io/InputStream;

    .line 301
    .line 302
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 303
    .line 304
    .line 305
    invoke-static {v0}, Ls5/g;->b(Ljava/io/InputStream;)[B
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    .line 306
    .line 307
    .line 308
    goto :goto_4

    .line 309
    :catch_1
    sget-object v0, Ly0/k0;->a:Ljava/lang/String;

    .line 310
    .line 311
    :goto_4
    iget-object v0, v6, Lo7/y;->p:Lo7/o;

    .line 312
    .line 313
    invoke-virtual {v0}, Lo7/o;->i()Ljava/util/TreeMap;

    .line 314
    .line 315
    .line 316
    move-result-object v0

    .line 317
    invoke-virtual {v1}, Lb1/a;->i()V

    .line 318
    .line 319
    .line 320
    if-ne v10, v9, :cond_9

    .line 321
    .line 322
    new-instance v11, La1/n;

    .line 323
    .line 324
    const/16 v2, 0x7d8

    .line 325
    .line 326
    invoke-direct {v11, v2}, La1/n;-><init>(I)V

    .line 327
    .line 328
    .line 329
    :cond_9
    new-instance v2, La1/c0;

    .line 330
    .line 331
    invoke-direct {v2, v10, v11, v0}, La1/c0;-><init>(ILa1/n;Ljava/util/Map;)V

    .line 332
    .line 333
    .line 334
    throw v2

    .line 335
    :cond_a
    invoke-virtual {v9}, Lo7/a0;->e()Lo7/s;

    .line 336
    .line 337
    .line 338
    const/16 v9, 0xc8

    .line 339
    .line 340
    if-ne v10, v9, :cond_b

    .line 341
    .line 342
    cmp-long v9, v4, v2

    .line 343
    .line 344
    if-eqz v9, :cond_b

    .line 345
    .line 346
    move-wide v2, v4

    .line 347
    :cond_b
    cmp-long v4, v7, v15

    .line 348
    .line 349
    if-eqz v4, :cond_c

    .line 350
    .line 351
    iput-wide v7, v1, Lb1/a;->w:J

    .line 352
    .line 353
    goto :goto_5

    .line 354
    :cond_c
    const-string v4, "Content-Length"

    .line 355
    .line 356
    invoke-static {v4, v6}, Lo7/y;->a(Ljava/lang/String;Lo7/y;)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v4

    .line 360
    invoke-static {v14, v6}, Lo7/y;->a(Ljava/lang/String;Lo7/y;)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v5

    .line 364
    invoke-static {v4, v5}, La1/d0;->b(Ljava/lang/String;Ljava/lang/String;)J

    .line 365
    .line 366
    .line 367
    move-result-wide v4

    .line 368
    cmp-long v6, v4, v15

    .line 369
    .line 370
    if-eqz v6, :cond_d

    .line 371
    .line 372
    sub-long v15, v4, v2

    .line 373
    .line 374
    :cond_d
    move-wide v4, v15

    .line 375
    iput-wide v4, v1, Lb1/a;->w:J

    .line 376
    .line 377
    :goto_5
    iput-boolean v13, v1, Lb1/a;->v:Z

    .line 378
    .line 379
    invoke-virtual/range {p0 .. p1}, La1/c;->g(La1/q;)V

    .line 380
    .line 381
    .line 382
    :try_start_3
    invoke-virtual {v1, v2, v3}, Lb1/a;->n(J)V
    :try_end_3
    .catch La1/a0; {:try_start_3 .. :try_end_3} :catch_2

    .line 383
    .line 384
    .line 385
    iget-wide v2, v1, Lb1/a;->w:J

    .line 386
    .line 387
    return-wide v2

    .line 388
    :catch_2
    move-exception v0

    .line 389
    invoke-virtual {v1}, Lb1/a;->i()V

    .line 390
    .line 391
    .line 392
    throw v0

    .line 393
    :catch_3
    move-exception v0

    .line 394
    invoke-static {v13, v0}, La1/a0;->a(ILjava/io/IOException;)La1/a0;

    .line 395
    .line 396
    .line 397
    move-result-object v0

    .line 398
    throw v0

    .line 399
    :cond_e
    new-instance v0, La1/a0;

    .line 400
    .line 401
    const-string v2, "Malformed URL"

    .line 402
    .line 403
    const/16 v3, 0x3ec

    .line 404
    .line 405
    invoke-direct {v0, v2, v3}, La1/a0;-><init>(Ljava/lang/String;I)V

    .line 406
    .line 407
    .line 408
    throw v0
.end method

.method public final close()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb1/a;->v:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Lb1/a;->v:Z

    .line 7
    .line 8
    invoke-virtual {p0}, La1/c;->c()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Lb1/a;->i()V

    .line 12
    .line 13
    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    iput-object v0, p0, Lb1/a;->t:Lo7/y;

    .line 16
    .line 17
    iput-object v0, p0, Lb1/a;->s:La1/q;

    .line 18
    .line 19
    return-void
.end method

.method public final i()V
    .locals 1

    .line 1
    iget-object v0, p0, Lb1/a;->t:Lo7/y;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, v0, Lo7/y;->q:Lo7/a0;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, Lo7/a0;->close()V

    .line 11
    .line 12
    .line 13
    :cond_0
    const/4 v0, 0x0

    .line 14
    iput-object v0, p0, Lb1/a;->u:Ljava/io/InputStream;

    .line 15
    .line 16
    return-void
.end method

.method public final l()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Lb1/a;->t:Lo7/y;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 6
    .line 7
    return-object v0

    .line 8
    :cond_0
    iget-object v0, v0, Lo7/y;->p:Lo7/o;

    .line 9
    .line 10
    invoke-virtual {v0}, Lo7/o;->i()Ljava/util/TreeMap;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    return-object v0
.end method

.method public final n(J)V
    .locals 7

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long v2, p1, v0

    .line 4
    .line 5
    if-nez v2, :cond_0

    .line 6
    .line 7
    goto :goto_2

    .line 8
    :cond_0
    const/16 v2, 0x1000

    .line 9
    .line 10
    new-array v3, v2, [B

    .line 11
    .line 12
    :goto_0
    cmp-long v4, p1, v0

    .line 13
    .line 14
    if-lez v4, :cond_4

    .line 15
    .line 16
    int-to-long v4, v2

    .line 17
    :try_start_0
    invoke-static {p1, p2, v4, v5}, Ljava/lang/Math;->min(JJ)J

    .line 18
    .line 19
    .line 20
    move-result-wide v4

    .line 21
    long-to-int v4, v4

    .line 22
    iget-object v5, p0, Lb1/a;->u:Ljava/io/InputStream;

    .line 23
    .line 24
    sget-object v6, Ly0/k0;->a:Ljava/lang/String;

    .line 25
    .line 26
    const/4 v6, 0x0

    .line 27
    invoke-virtual {v5, v3, v6, v4}, Ljava/io/InputStream;->read([BII)I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 32
    .line 33
    .line 34
    move-result-object v5

    .line 35
    invoke-virtual {v5}, Ljava/lang/Thread;->isInterrupted()Z

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-nez v5, :cond_2

    .line 40
    .line 41
    const/4 v5, -0x1

    .line 42
    if-eq v4, v5, :cond_1

    .line 43
    .line 44
    int-to-long v5, v4

    .line 45
    sub-long/2addr p1, v5

    .line 46
    invoke-virtual {p0, v4}, La1/c;->a(I)V

    .line 47
    .line 48
    .line 49
    goto :goto_0

    .line 50
    :catch_0
    move-exception p1

    .line 51
    goto :goto_1

    .line 52
    :cond_1
    new-instance p1, La1/a0;

    .line 53
    .line 54
    const/16 p2, 0x7d8

    .line 55
    .line 56
    invoke-direct {p1, p2}, La1/a0;-><init>(I)V

    .line 57
    .line 58
    .line 59
    throw p1

    .line 60
    :cond_2
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 61
    .line 62
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 63
    .line 64
    .line 65
    throw p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 66
    :goto_1
    instance-of p2, p1, La1/a0;

    .line 67
    .line 68
    if-eqz p2, :cond_3

    .line 69
    .line 70
    check-cast p1, La1/a0;

    .line 71
    .line 72
    throw p1

    .line 73
    :cond_3
    new-instance p1, La1/a0;

    .line 74
    .line 75
    const/16 p2, 0x7d0

    .line 76
    .line 77
    invoke-direct {p1, p2}, La1/a0;-><init>(I)V

    .line 78
    .line 79
    .line 80
    throw p1

    .line 81
    :cond_4
    :goto_2
    return-void
.end method

.method public final read([BII)I
    .locals 6

    .line 1
    if-nez p3, :cond_0

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    return p1

    .line 5
    :cond_0
    :try_start_0
    iget-wide v0, p0, Lb1/a;->w:J

    .line 6
    .line 7
    const-wide/16 v2, -0x1

    .line 8
    .line 9
    cmp-long v2, v0, v2

    .line 10
    .line 11
    const/4 v3, -0x1

    .line 12
    if-eqz v2, :cond_2

    .line 13
    .line 14
    iget-wide v4, p0, Lb1/a;->x:J

    .line 15
    .line 16
    sub-long/2addr v0, v4

    .line 17
    const-wide/16 v4, 0x0

    .line 18
    .line 19
    cmp-long v2, v0, v4

    .line 20
    .line 21
    if-nez v2, :cond_1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    int-to-long v4, p3

    .line 25
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    long-to-int p3, v0

    .line 30
    :cond_2
    iget-object v0, p0, Lb1/a;->u:Ljava/io/InputStream;

    .line 31
    .line 32
    sget-object v1, Ly0/k0;->a:Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    if-ne p1, v3, :cond_3

    .line 39
    .line 40
    :goto_0
    return v3

    .line 41
    :cond_3
    iget-wide p2, p0, Lb1/a;->x:J

    .line 42
    .line 43
    int-to-long v0, p1

    .line 44
    add-long/2addr p2, v0

    .line 45
    iput-wide p2, p0, Lb1/a;->x:J

    .line 46
    .line 47
    invoke-virtual {p0, p1}, La1/c;->a(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 48
    .line 49
    .line 50
    return p1

    .line 51
    :catch_0
    move-exception p1

    .line 52
    sget-object p2, Ly0/k0;->a:Ljava/lang/String;

    .line 53
    .line 54
    const/4 p2, 0x2

    .line 55
    invoke-static {p2, p1}, La1/a0;->a(ILjava/io/IOException;)La1/a0;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    throw p1
.end method

.method public final w()Landroid/net/Uri;
    .locals 1

    .line 1
    iget-object v0, p0, Lb1/a;->t:Lo7/y;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, v0, Lo7/y;->k:Le6/q;

    .line 6
    .line 7
    iget-object v0, v0, Le6/q;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lo7/q;

    .line 10
    .line 11
    iget-object v0, v0, Lo7/q;->h:Ljava/lang/String;

    .line 12
    .line 13
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    return-object v0

    .line 18
    :cond_0
    iget-object v0, p0, Lb1/a;->s:La1/q;

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    iget-object v0, v0, La1/q;->a:Landroid/net/Uri;

    .line 23
    .line 24
    return-object v0

    .line 25
    :cond_1
    const/4 v0, 0x0

    .line 26
    return-object v0
.end method
