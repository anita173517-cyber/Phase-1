.class public abstract Lb4/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Ljava/lang/Boolean;


# direct methods
.method public static A(Landroid/os/Bundle;)Lb4/d;
    .locals 1

    const-string v0, "android.support.v4.media.session.SESSION_TOKEN2"

    :try_start_0
    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    check-cast p0, Landroid/os/Bundle;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const-class v0, Lb4/a;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const-string v0, "a"

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    instance-of v0, p0, Landroidx/versionedparcelable/ParcelImpl;

    if-eqz v0, :cond_1

    check-cast p0, Landroidx/versionedparcelable/ParcelImpl;

    iget-object p0, p0, Landroidx/versionedparcelable/ParcelImpl;->k:Lb4/d;

    return-object p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid parcel"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static varargs B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 6

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    array-length v2, p1

    mul-int/lit8 v2, v2, 0x10

    add-int/2addr v2, v1

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    array-length v3, p1

    if-ge v1, v3, :cond_1

    const-string v3, "%s"

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v0, p0, v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v1, 0x1

    aget-object v1, p1, v1

    invoke-static {v1}, Lb4/a;->C(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v3, 0x2

    move v5, v2

    move v2, v1

    move v1, v5

    goto :goto_0

    :cond_1
    :goto_1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    invoke-virtual {v0, p0, v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    array-length p0, p1

    if-ge v1, p0, :cond_3

    const-string p0, " ["

    :goto_2
    array-length v2, p1

    if-ge v1, v2, :cond_2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object p0, p1, v1

    invoke-static {p0}, Lb4/a;->C(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    const-string p0, ", "

    goto :goto_2

    :cond_2
    const/16 p0, 0x5d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static C(Ljava/lang/Object;)Ljava/lang/String;
    .locals 5

    if-nez p0, :cond_0

    const-string p0, "null"

    return-object p0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x40

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v1, "com.google.common.base.Strings"

    invoke-static {v1}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v1

    sget-object v2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Exception during lenientFormat for "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3, v0}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "<"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " threw "

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ">"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static D(Ljava/lang/String;JLjava/util/Map;)V
    .locals 7

    const-string v0, "extras"

    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Lb4/a;->u()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/16 v4, 0x5f

    if-ge v3, v1, :cond_3

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v6

    if-nez v6, :cond_1

    if-ne v5, v4, :cond_2

    :cond_1
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    :cond_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "RAMBENCH "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "_ms="

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide/16 v5, 0x0

    cmp-long p0, p1, v5

    if-gez p0, :cond_4

    move-wide p1, v5

    :cond_4
    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-interface {p3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    move v3, v2

    :goto_2
    if-ge v3, v1, :cond_7

    invoke-virtual {p2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v6

    if-nez v6, :cond_5

    if-ne v5, v4, :cond_6

    :cond_5
    invoke-virtual {p3, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    :cond_6
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_7
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    move v3, v2

    :goto_3
    if-ge v3, v1, :cond_a

    invoke-virtual {p1, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v6

    if-nez v6, :cond_8

    if-eq v5, v4, :cond_8

    const/16 v6, 0x2e

    if-eq v5, v6, :cond_8

    const/16 v6, 0x2d

    if-ne v5, v6, :cond_9

    :cond_8
    invoke-virtual {p3, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    :cond_9
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_a
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 p3, 0x18

    invoke-static {p1, p3}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    const/16 p3, 0x20

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p2, 0x3d

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "toString(...)"

    invoke-static {p0, p1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "RamBench"

    invoke-static {p1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static E(Ljava/lang/Object;Lcom/google/crypto/tink/shaded/protobuf/e1;[BIILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 6

    add-int/lit8 v0, p3, 0x1

    aget-byte p3, p2, p3

    if-gez p3, :cond_0

    invoke-static {p3, p2, v0, p5}, Lb4/a;->q(I[BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result v0

    iget p3, p5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    :cond_0
    move v3, v0

    if-ltz p3, :cond_1

    sub-int/2addr p4, v3

    if-gt p3, p4, :cond_1

    add-int v4, v3, p3

    move-object v1, p0

    move-object v0, p1

    move-object v2, p2

    move-object v5, p5

    invoke-interface/range {v0 .. v5}, Lcom/google/crypto/tink/shaded/protobuf/e1;->c(Ljava/lang/Object;[BIILcom/google/crypto/tink/shaded/protobuf/d;)V

    iput-object v1, v5, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    return v4

    :cond_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->g()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0
.end method

.method public static F(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;
    .locals 8

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v1, 0x0

    :try_start_0
    const-string v0, "r"

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;

    move-result-object p0

    if-nez p0, :cond_0

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v1

    :cond_0
    :try_start_1
    new-instance p1, Ljava/io/FileInputStream;

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {p1}, Ljava/io/FileInputStream;->getChannel()Ljava/nio/channels/FileChannel;

    move-result-object v2

    invoke-virtual {v2}, Ljava/nio/channels/FileChannel;->size()J

    move-result-wide v6

    sget-object v3, Ljava/nio/channels/FileChannel$MapMode;->READ_ONLY:Ljava/nio/channels/FileChannel$MapMode;

    const-wide/16 v4, 0x0

    invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->map(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    invoke-virtual {p1}, Ljava/io/FileInputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    return-object v0

    :catchall_0
    move-exception v0

    move-object p1, v0

    goto :goto_1

    :catchall_1
    move-exception v0

    move-object v2, v0

    :try_start_5
    invoke-virtual {p1}, Ljava/io/FileInputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception v0

    move-object p1, v0

    :try_start_6
    invoke-virtual {v2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_1
    :try_start_7
    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_2

    :catchall_3
    move-exception v0

    move-object p0, v0

    :try_start_8
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p1
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0

    :catch_0
    :cond_1
    return-object v1
.end method

.method public static final G(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;)V
    .locals 13

    const-string v2, "<this>"

    invoke-static {p0, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object v2, p1, Lm6/n;->c:Ljava/lang/String;

    const-string v3, "Add \'"

    const-string v4, "\' to Custom Collection"

    invoke-static {v3, v2, v4}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lm6/u0;

    const/4 v8, 0x0

    const/16 v9, 0x10

    const-string v4, "COLLECTION / GROUP NAME"

    const-string v5, "Sports VIP"

    const v6, 0x7f0800c0

    const-string v7, "My Top Channels"

    invoke-direct/range {v3 .. v9}, Lm6/u0;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;II)V

    invoke-static {v3}, Lcom/bumptech/glide/c;->m(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    new-instance v11, Lm6/y3;

    const/4 v3, 0x1

    invoke-direct {v11, p0, p1, v3}, Lm6/y3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/16 v12, 0x9e0

    const v1, 0x7f0800c0

    const-string v3, "Enter a collection name (e.g. Sports VIP, Family, News, Evening)"

    const-string v4, "COLLECTION"

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v8, "Save to Collection"

    const v9, 0x7f080051

    const/4 v10, 0x0

    move-object v0, p0

    invoke-static/range {v0 .. v12}, Landroid/support/v4/media/session/b;->X(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lz6/a;Ljava/lang/String;IILz6/l;I)V

    return-void
.end method

.method public static H(ILjava/util/ArrayList;)Lm6/d7;
    .locals 10

    new-instance v0, Le7/d;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p1}, Le7/d;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0}, Le7/d;->iterator()Ljava/util/Iterator;

    move-result-object v0

    move v2, v1

    :cond_0
    :goto_0
    move-object v3, v0

    check-cast v3, Lo6/w;

    iget-object v3, v3, Lo6/w;->k:Ljava/util/ListIterator;

    invoke-interface {v3}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_3

    invoke-interface {v3}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ln6/d;

    iget-object v4, v3, Ln6/d;->k:Ljava/lang/Object;

    check-cast v4, Lm6/l6;

    iget-object v3, v3, Ln6/d;->l:Ljava/lang/Object;

    check-cast v3, Ljava/util/Map;

    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    :try_start_0
    invoke-virtual {v4, v8}, Lm6/l6;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v8, v9}, Lb4/a;->T(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    xor-int/2addr v8, v1

    goto :goto_2

    :catch_0
    move v8, v1

    :goto_2
    if-eqz v8, :cond_1

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    invoke-interface {v6, v8, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    invoke-interface {v6}, Ljava/util/Map;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-static {v4, v6}, Lb4/a;->e(Lm6/l6;Ljava/util/Map;)Z

    move-result v3

    if-nez v3, :cond_0

    move v2, v5

    goto :goto_0

    :cond_3
    new-instance v0, Lm6/d7;

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_4

    if-eqz v2, :cond_4

    move p1, v1

    goto :goto_3

    :cond_4
    move p1, v5

    :goto_3
    xor-int/2addr v1, v2

    invoke-direct {v0, v5, p0, p1, v1}, Lm6/d7;-><init>(ZIZZ)V

    return-object v0
.end method

.method public static I(Ljava/util/List;)Lm6/d7;
    .locals 10

    new-instance v0, Ljava/util/ArrayList;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    add-int/lit8 v3, v2, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lm6/f7;

    new-instance v5, Ljava/util/LinkedHashMap;

    iget-object v6, v4, Lm6/f7;->b:Ljava/util/Map;

    iget-object v4, v4, Lm6/f7;->a:Lm6/l6;

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v7

    invoke-direct {v5, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    :try_start_0
    invoke-interface {v6}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_0

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v4, v8}, Lm6/l6;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    invoke-interface {v5, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :cond_0
    invoke-static {v4, v6}, Lb4/a;->e(Lm6/l6;Ljava/util/Map;)Z

    move-result v6

    if-nez v6, :cond_1

    new-instance p0, Ln6/d;

    invoke-direct {p0, v4, v5}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v2, v0}, Lb4/a;->H(ILjava/util/ArrayList;)Lm6/d7;

    move-result-object p0

    return-object p0

    :cond_1
    new-instance v2, Ln6/d;

    invoke-direct {v2, v4, v5}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v2, v3

    goto :goto_0

    :catch_0
    invoke-static {v2, v0}, Lb4/a;->H(ILjava/util/ArrayList;)Lm6/d7;

    move-result-object p0

    return-object p0

    :cond_2
    new-instance p0, Lm6/d7;

    const/4 v0, -0x1

    const/4 v2, 0x1

    invoke-direct {p0, v2, v0, v1, v1}, Lm6/d7;-><init>(ZIZZ)V

    return-object p0
.end method

.method public static final J(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 22

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    invoke-virtual {v1}, Lm6/m6;->R()Lm6/l8;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    invoke-virtual {v2}, Lm6/m6;->F()I

    move-result v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    invoke-virtual {v3}, Lm6/m6;->X()Z

    move-result v3

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v4, v4, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v5, "high_contrast_text_v190"

    const/4 v6, 0x0

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v4, v4, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v5, "startup_destination_v190"

    const-string v7, "LIVE_TV"

    invoke-interface {v4, v5, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_0

    move-object v4, v7

    :cond_0
    new-instance v5, Ljava/util/ArrayList;

    const/16 v7, 0xc

    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(I)V

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->v2:Ljava/util/List;

    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move v8, v6

    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_4

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    add-int/lit8 v10, v8, 0x1

    if-ltz v8, :cond_3

    check-cast v9, Lm6/j8;

    iget v11, v0, Lcom/harindra/iptvpro/PlayerActivity;->w2:I

    if-ne v8, v11, :cond_1

    const/4 v11, 0x1

    move/from16 v18, v11

    goto :goto_1

    :cond_1
    move/from16 v18, v6

    :goto_1
    new-instance v13, Lm6/v0;

    iget-object v11, v9, Lm6/j8;->a:Ljava/lang/String;

    const-string v14, "Theme: "

    invoke-virtual {v14, v11}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    iget-object v9, v9, Lm6/j8;->b:Ljava/lang/String;

    if-eqz v18, :cond_2

    const-string v11, "ACTIVE \u2713"

    :goto_2
    move-object/from16 v17, v11

    goto :goto_3

    :cond_2
    const-string v11, "APPLY"

    goto :goto_2

    :goto_3
    new-instance v11, Lm6/j2;

    const/16 v14, 0xc

    invoke-direct {v11, v0, v8, v14}, Lm6/j2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;II)V

    const v14, 0x7f0800d8

    move-object/from16 v16, v9

    move-object/from16 v19, v11

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v8, v10

    goto :goto_0

    :cond_3
    invoke-static {}, Lo6/k;->N()V

    const/4 v0, 0x0

    throw v0

    :cond_4
    new-instance v13, Lm6/v0;

    invoke-virtual {v1}, Lm6/l8;->b()Ljava/lang/String;

    move-result-object v6

    const-string v7, "UI & Poster Grid Density: "

    invoke-static {v7, v6}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v1}, Lm6/l8;->c()I

    move-result v6

    const-string v7, " COLS"

    invoke-static {v7, v6}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v17

    new-instance v6, Lm6/x2;

    const/16 v7, 0xa

    invoke-direct {v6, v1, v7, v0}, Lm6/x2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const/16 v18, 0x0

    const v14, 0x7f0800c7

    const-string v16, "Tap to cycle: Compact (6 Cols) \u2192 Standard (5 Cols) \u2192 Cinematic (4 Cols)"

    move-object/from16 v19, v6

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v14, Lm6/v0;

    const-string v1, "TV Overscan Safe-Area Margin: "

    const-string v6, "dp"

    invoke-static {v2, v1, v6}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-static {v6, v2}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v18

    new-instance v1, Lm6/j2;

    const/16 v6, 0xd

    invoke-direct {v1, v2, v0, v6}, Lm6/j2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v19, 0x0

    const v15, 0x7f0800be

    const-string v17, "Adds safe border padding for televisions that crop screen edges (0dp / 8dp / 16dp / 24dp)"

    move-object/from16 v20, v1

    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v15, Lm6/v0;

    if-eqz v3, :cond_5

    const-string v1, "24-Hour (19:30)"

    goto :goto_4

    :cond_5
    const-string v1, "12-Hour AM/PM (07:30 PM)"

    :goto_4
    const-string v2, "Clock Format: "

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    if-eqz v3, :cond_6

    const-string v1, "24H"

    :goto_5
    move-object/from16 v19, v1

    goto :goto_6

    :cond_6
    const-string v1, "12H"

    goto :goto_5

    :goto_6
    new-instance v1, Lm6/k2;

    const/4 v2, 0x5

    invoke-direct {v1, v0, v3, v2}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const/16 v20, 0x0

    const v16, 0x7f0800d3

    const-string v18, "Toggle 12-hour vs 24-hour time formatting across headers and EPG"

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v7, Lm6/v0;

    if-eqz v12, :cond_7

    const-string v1, "ON \u2713"

    :goto_7
    move-object v11, v1

    goto :goto_8

    :cond_7
    const-string v1, "OFF"

    goto :goto_7

    :goto_8
    new-instance v13, Lm6/k2;

    const/4 v1, 0x6

    invoke-direct {v13, v0, v12, v1}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const v8, 0x7f0800d6

    const-string v9, "High-Contrast TV Text Mode"

    const-string v10, "Enhances text brightness and contrast for viewing from a distance"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v13, Lm6/v0;

    const-string v1, "Default Startup Destination: "

    invoke-virtual {v1, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    new-instance v1, Lm6/m2;

    const/16 v2, 0x9

    invoke-direct {v1, v4, v0, v2}, Lm6/m2;-><init>(Ljava/lang/String;Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v18, 0x0

    const v14, 0x7f0800c4

    const-string v16, "Choose whether launching the app opens Live TV directly or the Cinematic Home Hub"

    move-object/from16 v19, v1

    move-object/from16 v17, v4

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "picture_brightness_mode_v192"

    const-string v3, "STANDARD"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_8

    move-object v10, v3

    goto :goto_9

    :cond_8
    move-object v10, v1

    :goto_9
    new-instance v6, Lm6/v0;

    const-string v1, "TV Picture & Brightness Mode: "

    invoke-virtual {v1, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v12, Lm6/m2;

    const/16 v1, 0xa

    invoke-direct {v12, v10, v0, v1}, Lm6/m2;-><init>(Ljava/lang/String;Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800db

    const-string v9, "Tap to cycle: STANDARD \u2192 CINEMA_DIM \u2192 NIGHT_EYECARE \u2192 VIVID_MAX"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v7, Lm6/v0;

    new-instance v13, Lm6/j5;

    const/16 v1, 0xf

    invoke-direct {v13, v0, v1}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800d6

    const-string v9, "Subtitle Font Size & Color Style"

    const-string v10, "Customize closed caption size (16sp\u201332sp) and high-contrast colors"

    const-string v11, "CAPTIONS"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v4, "DISPLAY"

    const-string v6, "Back"

    const v1, 0x7f0800d8

    const-string v2, "Appearance, Density, Overscan & Comfort"

    const-string v3, "Customize themes, poster grid density, safe-area margins & TV readability"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final K(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 40

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "Settings Center"

    invoke-static {v0, v1}, Lc4/b0;->M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "stop_live_tv_in_background_v190"

    const/4 v3, 0x1

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v2, v2, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v4, "auto_reconnect_live_on_return_v190"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    invoke-virtual {v4}, Lm6/m6;->N()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long/2addr v4, v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    invoke-virtual {v6}, Lm6/m6;->S()F

    move-result v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v7

    invoke-virtual {v7}, Lm6/m6;->R()Lm6/l8;

    move-result-object v7

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v8

    invoke-virtual {v8}, Lm6/m6;->F()I

    move-result v8

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v9

    invoke-virtual {v9}, Lm6/m6;->X()Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v9

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v9, v10}, Lm6/m6;->u(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v9

    new-instance v10, Lm6/v0;

    invoke-static {v0}, Lc4/b0;->c(Lcom/harindra/iptvpro/PlayerActivity;)Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    const-string v12, "\ud83d\udd0d Search All "

    const-string v13, " Settings Topics"

    invoke-static {v11, v12, v13}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    new-instance v11, Lm6/r4;

    const/16 v13, 0x12

    invoke-direct {v11, v0, v13}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    move-object/from16 v16, v11

    const v11, 0x7f0800cf

    move v14, v13

    const-string v13, "Instantly jump to any setting (Audio Delay, Subtitle Delay, Blacklist, Auto-Refresh, Privacy, Health...)"

    move v15, v14

    const-string v14, "SEARCH"

    move/from16 v17, v15

    const/4 v15, 0x1

    move/from16 v18, v3

    move/from16 v3, v17

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v11, Lm6/v0;

    new-instance v12, Lm6/r4;

    const/16 v13, 0x13

    invoke-direct {v12, v0, v13}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v16, 0x0

    move-object/from16 v17, v12

    const v12, 0x7f0800cc

    move v14, v13

    const-string v13, "\ud83e\ude7a App Health Dashboard & Hardware Capabilities"

    move v15, v14

    const-string v14, "Live Media3 status, HDR/Audio capabilities, Storage, Cache, Last & Next Refresh"

    move/from16 v19, v15

    const-string v15, "HEALTH"

    invoke-direct/range {v11 .. v17}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v20, Lm6/v0;

    new-instance v12, Lm6/r4;

    const/16 v13, 0x14

    invoke-direct {v12, v0, v13}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v25, 0x0

    const v21, 0x7f0800c6

    const-string v22, "\ud83d\udee1\ufe0f Privacy Controls & History Management"

    const-string v23, "Clear Search History, Watch History, Continue Watching & manage saved credentials"

    const-string v24, "PRIVACY"

    move-object/from16 v26, v12

    invoke-direct/range {v20 .. v26}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v21, Lm6/v0;

    const-string v12, "ON"

    const-string v14, "OFF"

    if-eqz v1, :cond_0

    move-object v1, v12

    goto :goto_0

    :cond_0
    move-object v1, v14

    :goto_0
    if-eqz v2, :cond_1

    move-object v2, v12

    goto :goto_1

    :cond_1
    move-object v2, v14

    :goto_1
    const-string v15, " \u2022 Return Auto-Play: "

    const-string v13, " \u2022 Seek: "

    const-string v3, "Bg Stop: "

    invoke-static {v3, v1, v15, v2, v13}, Lq3/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "s \u2022 Speed: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v2, "x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v24

    new-instance v1, Lm6/r4;

    const/16 v2, 0x15

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v22, 0x7f0800ca

    const-string v23, "1. Playback & Live TV Background Control"

    const-string v25, "PLAYBACK"

    const/16 v26, 0x1

    move-object/from16 v27, v1

    invoke-direct/range {v21 .. v27}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v22, Lm6/v0;

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->m2:Lm6/h;

    invoke-virtual {v1}, Lm6/h;->b()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->m2:Lm6/h;

    invoke-virtual {v2}, Lm6/h;->e()I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v6, "Active: "

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " ("

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "ms start)"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v25

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->m2:Lm6/h;

    invoke-virtual {v1}, Lm6/h;->a()Ljava/lang/String;

    move-result-object v26

    new-instance v1, Lm6/r4;

    const/16 v2, 0x16

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v27, 0x0

    const v23, 0x7f0800cc

    const-string v24, "2. Buffer Profiles (512MB Tuned)"

    move-object/from16 v28, v1

    invoke-direct/range {v22 .. v28}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v23, Lm6/v0;

    new-instance v1, Lm6/r4;

    const/16 v2, 0x17

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v28, 0x0

    const v24, 0x7f0800c8

    const-string v25, "3. Network & Connectivity Health Center"

    const-string v26, "Inspect real connection status, DNS cache, timeouts & Data Saver mode"

    const-string v27, "NETWORK"

    move-object/from16 v29, v1

    invoke-direct/range {v23 .. v29}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v24, Lm6/v0;

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    invoke-virtual {v1}, Lm6/l1;->r()Ljava/lang/String;

    move-result-object v1

    const-string v2, " \u2022 Auto / Balanced / Fast / Low-RAM / Saver / 4GB"

    invoke-static {v6, v1, v2}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    invoke-virtual {v1}, Lm6/l1;->f()Ljava/lang/String;

    move-result-object v28

    new-instance v1, Lm6/r4;

    const/16 v2, 0x18

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v29, 0x0

    const v25, 0x7f0800ce

    const-string v26, "4. Performance & Adaptive Engine"

    move-object/from16 v30, v1

    invoke-direct/range {v24 .. v30}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v25, Lm6/v0;

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->v2:Ljava/util/List;

    iget v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->w2:I

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/j8;

    iget-object v1, v1, Lm6/j8;->a:Ljava/lang/String;

    invoke-virtual {v7}, Lm6/l8;->a()Ljava/lang/String;

    move-result-object v2

    const-string v3, " \u2022 Density: "

    const-string v6, " \u2022 Overscan: "

    const-string v7, "Theme: "

    invoke-static {v7, v1, v3, v2, v6}, Lq3/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "dp \u2022 Customize Home/Sidebar"

    invoke-static {v1, v8, v2}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v28

    new-instance v1, Lm6/r4;

    const/16 v2, 0x19

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v30, 0x0

    const v26, 0x7f0800d8

    const-string v27, "5. Appearance, Home Rows & Sidebar Customization"

    const-string v29, "DISPLAY"

    move-object/from16 v31, v1

    invoke-direct/range {v25 .. v31}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v26, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "remote_long_press_ok_v190"

    const-string v3, "QUICK_MENU"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_2

    goto :goto_2

    :cond_2
    move-object v3, v1

    :goto_2
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Long-Press OK: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " \u2022 Seek Step: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "s"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v29

    new-instance v1, Lm6/r4;

    const/16 v2, 0x1a

    invoke-direct {v1, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v31, 0x0

    const v27, 0x7f0800c1

    const-string v28, "6. TV Remote Shortcuts & Key Mapping"

    const-string v30, "REMOTE"

    move-object/from16 v32, v1

    invoke-direct/range {v26 .. v32}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v1, Lm6/v0;

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i1:Ljava/util/Map;

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " EPG Channels Indexed \u2022 "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " Active Reminders"

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v7, Lm6/r4;

    const/16 v2, 0x1b

    invoke-direct {v7, v0, v2}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v6, 0x0

    const v2, 0x7f0800c2

    const-string v3, "7. EPG TV Guide & Programme Reminders"

    const-string v5, "EPG GUIDE"

    invoke-direct/range {v1 .. v7}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v2, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    invoke-virtual {v3}, Lm6/m6;->e()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const-string v4, " PROFILES"

    invoke-static {v4, v3}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    new-instance v8, Lm6/r4;

    const/16 v3, 0x1c

    invoke-direct {v8, v0, v3}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v7, 0x0

    const v3, 0x7f0800bd

    const-string v4, "8. Profiles & Multi-Account Manager"

    const-string v5, "Switch, create, edit or delete M3U and Xtream Codes accounts safely"

    invoke-direct/range {v2 .. v8}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v3, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    invoke-virtual {v4}, Lm6/m6;->A()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v4

    const-string v5, "Manage 4-digit PIN & locked channel categories ("

    const-string v6, " locked)"

    invoke-static {v4, v5, v6}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    invoke-virtual {v4}, Lm6/m6;->U()Z

    move-result v4

    if-eqz v4, :cond_3

    const-string v4, "LOCKED \ud83d\udd12"

    move-object v7, v4

    goto :goto_3

    :cond_3
    move-object v7, v14

    :goto_3
    new-instance v9, Lm6/j5;

    const/4 v13, 0x4

    invoke-direct {v9, v0, v13}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v8, 0x0

    const v4, 0x7f0800c6

    const-string v5, "9. Parental Controls (Salted SHA-256 PIN)"

    invoke-direct/range {v3 .. v9}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v27, Lm6/v0;

    new-instance v4, Lm6/j5;

    const/16 v5, 0xd

    invoke-direct {v4, v0, v5}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v32, 0x0

    const v28, 0x7f0800d9

    const-string v29, "10. Storage & Cache Manager"

    const-string v30, "Inspect SXB2 cache, EPG cache, artwork cache & free device storage safely"

    const-string v31, "STORAGE"

    move-object/from16 v33, v4

    invoke-direct/range {v27 .. v33}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v28, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-static {v4, v6}, Lm6/m6;->K(Lm6/m6;Ljava/lang/String;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    invoke-static {v4}, Lm6/m6;->t(Lm6/m6;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    add-int/2addr v4, v6

    const-string v6, " ITEMS"

    invoke-static {v6, v4}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v32

    new-instance v4, Lm6/j5;

    const/16 v6, 0xe

    invoke-direct {v4, v0, v6}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v33, 0x0

    const v29, 0x7f0800d9

    const-string v30, "10b. Recycle Bin (Restore Deleted Items)"

    const-string v31, "Deleted accounts, collections, EPG reminders & custom names \u2022 Kept 30 days"

    move-object/from16 v34, v4

    invoke-direct/range {v28 .. v34}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v29, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v4, v7}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_4

    move-object v4, v14

    goto :goto_4

    :cond_4
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v4, v7}, Lm6/m6;->n(Ljava/lang/String;)I

    move-result v4

    const-string v7, "h"

    invoke-static {v7, v4}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    :goto_4
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v7

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v7, v8}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/HashSet;->size()I

    move-result v7

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Auto-Refresh: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " \u2022 Blacklist: "

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " \u2022 Health"

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v32

    new-instance v4, Lm6/j5;

    const/16 v7, 0x10

    invoke-direct {v4, v0, v7}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v34, 0x0

    const v30, 0x7f0800cb

    const-string v31, "11. Playlist Auto-Refresh, Blacklist & Health"

    const-string v33, "PLAYLIST"

    move-object/from16 v35, v4

    invoke-direct/range {v29 .. v35}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v30, Lm6/v0;

    new-instance v4, Lm6/j5;

    const/16 v8, 0x11

    invoke-direct {v4, v0, v8}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v35, 0x0

    const v31, 0x7f0800c6

    const-string v32, "12. Diagnostics, Playback Telemetry & Recovery Center"

    const-string v33, "Real Media3 codec/FPS/bitrate stats, troubleshooting & redacted export"

    const-string v34, "DIAGNOSTICS"

    move-object/from16 v36, v4

    invoke-direct/range {v30 .. v36}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v31, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v4, v4, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v9, "high_contrast_text_v190"

    const/4 v15, 0x0

    invoke-interface {v4, v9, v15}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_5

    move-object v4, v12

    goto :goto_5

    :cond_5
    move-object v4, v14

    :goto_5
    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->n2:Lm6/l1;

    invoke-virtual {v9}, Lm6/l1;->p()Z

    move-result v9

    if-eqz v9, :cond_6

    goto :goto_6

    :cond_6
    move-object v12, v14

    :goto_6
    const-string v9, "High-Contrast Text: "

    const-string v14, " \u2022 Reduced Motion: "

    invoke-static {v9, v4, v14, v12}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v34

    new-instance v4, Lm6/j5;

    const/16 v14, 0x12

    invoke-direct {v4, v0, v14}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v36, 0x0

    const v32, 0x7f0800d6

    const-string v33, "13. Accessibility & TV Viewing Comfort"

    const-string v35, "COMFORT"

    move-object/from16 v37, v4

    invoke-direct/range {v31 .. v37}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v32, Lm6/v0;

    new-instance v4, Lm6/j5;

    const/16 v14, 0x13

    invoke-direct {v4, v0, v14}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v37, 0x0

    const v33, 0x7f0800d7

    const-string v34, "14. Backup & Restore (SXBK_V19) + Reset Defaults"

    const-string v35, "Export/import profiles, favorites, watchlists & settings or restore defaults"

    const-string v36, "BACKUP"

    move-object/from16 v38, v4

    invoke-direct/range {v32 .. v38}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v33, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v4, v4, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v9, "idle_screensaver_mins_v190"

    const/16 v12, 0xa

    invoke-interface {v4, v9, v12}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    const/16 v9, 0x3c

    invoke-static {v4, v15, v9}, Lc4/b0;->i(III)I

    move-result v4

    const-string v9, "RAM PLAYER v19.0 AMOLED 3D \u2022 Idle Screensaver ("

    move/from16 v19, v5

    const-string v5, "m) \u2022 Setup Wizard"

    invoke-static {v4, v9, v5}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    new-instance v4, Lm6/j5;

    const/16 v5, 0x14

    invoke-direct {v4, v0, v5}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v38, 0x0

    const v34, 0x7f0800ce

    const-string v35, "15. About, Setup Wizard, Screensaver & Update Center"

    const-string v37, "v19.0 AMOLED"

    move-object/from16 v39, v4

    invoke-direct/range {v33 .. v39}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-array v4, v14, [Lm6/v0;

    aput-object v10, v4, v15

    aput-object v11, v4, v18

    const/4 v5, 0x2

    aput-object v20, v4, v5

    const/4 v5, 0x3

    aput-object v21, v4, v5

    aput-object v22, v4, v13

    const/4 v5, 0x5

    aput-object v23, v4, v5

    const/4 v5, 0x6

    aput-object v24, v4, v5

    const/4 v5, 0x7

    aput-object v25, v4, v5

    const/16 v5, 0x8

    aput-object v26, v4, v5

    const/16 v5, 0x9

    aput-object v1, v4, v5

    aput-object v2, v4, v12

    const/16 v1, 0xb

    aput-object v3, v4, v1

    const/16 v1, 0xc

    aput-object v27, v4, v1

    aput-object v28, v4, v19

    aput-object v29, v4, v6

    const/16 v1, 0xf

    aput-object v30, v4, v1

    aput-object v31, v4, v7

    aput-object v32, v4, v8

    const/16 v17, 0x12

    aput-object v33, v4, v17

    invoke-static {v4}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v4, "16 CATEGORIES"

    const-string v6, "Close"

    const v1, 0x7f0800d8

    const-string v2, "RAM PLAYER 16-Category Settings Center"

    const-string v3, "All settings persist safely per device/profile with zero data loss"

    invoke-static {v0, v5}, Lcom/harindra/iptvpro/ultra/Ultra;->augmentSettings(Lcom/harindra/iptvpro/PlayerActivity;Ljava/util/List;)Ljava/util/List;

    move-result-object v5

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final L(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 39

    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->a3:Ljava/util/ArrayList;

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    const-string v3, "Home Hub"

    invoke-static {v0, v3}, Lc4/b0;->M(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lm6/m6;->p(Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    goto :goto_0

    :cond_0
    sget-object v3, Lo6/r;->k:Lo6/r;

    :goto_0
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v4

    sget-object v5, Lo6/t;->k:Lo6/t;

    if-eqz v4, :cond_1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v4, v6}, Lm6/m6;->B(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v4

    goto :goto_1

    :cond_1
    move-object v4, v5

    :goto_1
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v5

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v5, v6}, Lm6/m6;->O(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v5

    :cond_2
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v6, v7}, Lm6/m6;->q(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v6

    goto :goto_2

    :cond_3
    sget-object v6, Lo6/s;->k:Lo6/s;

    :goto_2
    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->x1:Ljava/lang/Object;

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    iget-object v10, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v11, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    const-string v12, "vodMovies"

    invoke-static {v7, v12}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v12, "vodIndexById"

    invoke-static {v8, v12}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v12, "seriesGroups"

    invoke-static {v9, v12}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v12, "liveChannels"

    invoke-static {v10, v12}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Lo6/j;->W(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lm6/n1;

    const-string v13, " \u2022 "

    const-string v14, ""

    if-eqz v12, :cond_9

    iget-object v15, v12, Lm6/n1;->e:Lm6/c0;

    move-object/from16 v27, v1

    sget-object v1, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    move-object/from16 v28, v2

    const-string v2, "%) \u2022 "

    if-ne v15, v1, :cond_6

    iget-object v9, v12, Lm6/n1;->a:Ljava/lang/String;

    invoke-interface {v8, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    if-eqz v8, :cond_4

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v9

    invoke-static {v9, v7}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lm6/n;

    goto :goto_3

    :cond_4
    const/4 v9, 0x0

    :goto_3
    if-eqz v9, :cond_a

    if-eqz v8, :cond_a

    invoke-virtual {v9}, Lm6/n;->a()Ljava/lang/String;

    move-result-object v18

    invoke-virtual {v12}, Lm6/n1;->b()I

    move-result v7

    iget-object v10, v9, Lm6/n;->d:Ljava/lang/String;

    invoke-virtual {v9}, Lm6/n;->e()Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v15

    if-nez v15, :cond_5

    invoke-virtual {v13, v11}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :cond_5
    new-instance v11, Ljava/lang/StringBuilder;

    const-string v15, "Continue Watching ("

    invoke-direct {v11, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v12}, Lm6/n1;->b()I

    move-result v2

    const-string v7, "RESUME "

    const-string v10, "%"

    invoke-static {v2, v7, v10}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    iget-object v2, v9, Lm6/n;->f:Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v23

    iget-wide v7, v12, Lm6/n1;->b:J

    new-instance v17, Lm6/m1;

    const/16 v26, 0x40

    move-object/from16 v22, v1

    move-object/from16 v21, v2

    move-wide/from16 v24, v7

    invoke-direct/range {v17 .. v26}, Lm6/m1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lm6/c0;IJI)V

    :goto_4
    move-object/from16 v1, v17

    move-object/from16 v17, v3

    move-object v3, v5

    goto/16 :goto_14

    :cond_6
    sget-object v1, Lm6/c0;->XTREAM_SERIES_EPISODE:Lm6/c0;

    if-ne v15, v1, :cond_a

    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_7
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_8

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    move-object v9, v8

    check-cast v9, Lm6/m7;

    iget-object v9, v9, Lm6/m7;->a:Ljava/lang/String;

    iget-object v15, v12, Lm6/n1;->f:Ljava/lang/String;

    invoke-static {v9, v15}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_7

    goto :goto_5

    :cond_8
    const/4 v8, 0x0

    :goto_5
    check-cast v8, Lm6/m7;

    if-eqz v8, :cond_a

    new-instance v17, Lm6/m1;

    iget-object v1, v8, Lm6/m7;->c:Ljava/lang/String;

    iget v7, v12, Lm6/n1;->g:I

    iget v9, v12, Lm6/n1;->h:I

    invoke-virtual {v12}, Lm6/n1;->b()I

    move-result v10

    iget-object v11, v8, Lm6/m7;->d:Ljava/lang/String;

    const-string v14, "E"

    const-string v15, " ("

    move-object/from16 v18, v1

    const-string v1, "Continue S"

    invoke-static {v7, v9, v1, v14, v15}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    iget-object v1, v8, Lm6/m7;->f:Ljava/lang/String;

    sget-object v22, Lm6/c0;->XTREAM_SERIES:Lm6/c0;

    const/16 v23, -0x1

    iget-wide v9, v12, Lm6/n1;->b:J

    const-string v20, "RESUME SERIES"

    move-object/from16 v21, v1

    move-object/from16 v24, v8

    move-wide/from16 v25, v9

    invoke-direct/range {v17 .. v26}, Lm6/m1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lm6/c0;ILm6/m7;J)V

    goto :goto_4

    :cond_9
    move-object/from16 v27, v1

    move-object/from16 v28, v2

    :cond_a
    invoke-static {v7}, Lo6/k;->I(Ljava/util/Collection;)Lb7/c;

    move-result-object v1

    invoke-virtual {v1}, Lb7/a;->iterator()Ljava/util/Iterator;

    move-result-object v1

    check-cast v1, Lb7/b;

    iget-boolean v2, v1, Lb7/b;->m:Z

    if-nez v2, :cond_b

    move-object/from16 v17, v3

    const/4 v2, 0x0

    goto :goto_8

    :cond_b
    invoke-virtual {v1}, Lb7/b;->next()Ljava/lang/Object;

    move-result-object v2

    iget-boolean v8, v1, Lb7/b;->m:Z

    if-nez v8, :cond_c

    move-object/from16 v17, v3

    goto :goto_8

    :cond_c
    move-object v8, v2

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lm6/n;

    iget-wide v8, v8, Lm6/n;->s:J

    :goto_6
    invoke-virtual {v1}, Lb7/b;->next()Ljava/lang/Object;

    move-result-object v12

    move-object v15, v12

    check-cast v15, Ljava/lang/Number;

    invoke-virtual {v15}, Ljava/lang/Number;->intValue()I

    move-result v15

    invoke-interface {v7, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lm6/n;

    move-object/from16 v18, v2

    move-object/from16 v17, v3

    iget-wide v2, v15, Lm6/n;->s:J

    cmp-long v15, v8, v2

    if-gez v15, :cond_d

    move-wide v8, v2

    move-object v2, v12

    goto :goto_7

    :cond_d
    move-object/from16 v2, v18

    :goto_7
    iget-boolean v3, v1, Lb7/b;->m:Z

    if-nez v3, :cond_26

    :goto_8
    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_f

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-interface {v7, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    invoke-virtual {v1}, Lm6/n;->a()Ljava/lang/String;

    move-result-object v30

    iget-object v3, v1, Lm6/n;->d:Ljava/lang/String;

    invoke-virtual {v1}, Lm6/n;->e()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_e

    invoke-virtual {v13, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :cond_e
    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "Featured VOD Movie \u2022 "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v31

    iget-object v1, v1, Lm6/n;->f:Ljava/lang/String;

    sget-object v34, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v35

    new-instance v29, Lm6/m1;

    const-string v32, "FEATURED MOVIE"

    const-wide/16 v36, 0x0

    const/16 v38, 0xc0

    move-object/from16 v33, v1

    invoke-direct/range {v29 .. v38}, Lm6/m1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lm6/c0;IJI)V

    :goto_9
    move-object v3, v5

    move-object/from16 v1, v29

    goto/16 :goto_14

    :cond_f
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    if-gez v1, :cond_10

    move v1, v2

    :cond_10
    invoke-static {v11, v2, v1}, Lc4/b0;->i(III)I

    move-result v1

    invoke-static {v1, v10}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lm6/n;

    new-instance v29, Lm6/m1;

    if-eqz v2, :cond_12

    iget-object v3, v2, Lm6/n;->c:Ljava/lang/String;

    if-nez v3, :cond_11

    goto :goto_b

    :cond_11
    :goto_a
    move-object/from16 v30, v3

    goto :goto_c

    :cond_12
    :goto_b
    const-string v3, "StreamX Live Television"

    goto :goto_a

    :goto_c
    if-eqz v2, :cond_13

    invoke-virtual {v2}, Lm6/n;->c()Ljava/lang/String;

    move-result-object v3

    iget-object v7, v2, Lm6/n;->d:Ljava/lang/String;

    const-string v8, "Channel "

    const-string v9, " \u2022 Ready to Watch"

    invoke-static {v8, v3, v13, v7, v9}, La0/h;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_d
    move-object/from16 v31, v3

    goto :goto_e

    :cond_13
    const-string v3, "Connect your M3U or Xtream account"

    goto :goto_d

    :goto_e
    if-eqz v2, :cond_14

    iget-object v15, v2, Lm6/n;->f:Ljava/lang/String;

    goto :goto_f

    :cond_14
    const/4 v15, 0x0

    :goto_f
    if-nez v15, :cond_15

    move-object/from16 v33, v14

    goto :goto_10

    :cond_15
    move-object/from16 v33, v15

    :goto_10
    if-eqz v2, :cond_17

    iget-object v2, v2, Lm6/n;->i:Lm6/c0;

    if-nez v2, :cond_16

    goto :goto_12

    :cond_16
    :goto_11
    move-object/from16 v34, v2

    goto :goto_13

    :cond_17
    :goto_12
    sget-object v2, Lm6/c0;->M3U_LIVE:Lm6/c0;

    goto :goto_11

    :goto_13
    const-wide/16 v36, 0x0

    const/16 v38, 0xc0

    const-string v32, "LIVE TV"

    move/from16 v35, v1

    invoke-direct/range {v29 .. v38}, Lm6/m1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lm6/c0;IJI)V

    goto :goto_9

    :goto_14
    new-instance v5, Ljava/util/ArrayList;

    const/16 v2, 0xe

    invoke-direct {v5, v2}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v7}, Lm6/m6;->y(Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v7

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v7, v8}, Lm6/m6;->w(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v7

    new-instance v18, Lm6/v0;

    iget-object v8, v1, Lm6/m1;->a:Ljava/lang/String;

    const-string v9, "\u2605 Featured / Hero: "

    invoke-static {v9, v8}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    new-instance v8, Lm6/x2;

    const/4 v9, 0x4

    invoke-direct {v8, v1, v9, v0}, Lm6/x2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const v19, 0x7f0800ca

    iget-object v9, v1, Lm6/m1;->b:Ljava/lang/String;

    iget-object v1, v1, Lm6/m1;->c:Ljava/lang/String;

    const/16 v23, 0x1

    move-object/from16 v22, v1

    move-object/from16 v24, v8

    move-object/from16 v21, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v18

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v8}, Lm6/m6;->G(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-interface/range {v28 .. v28}, Ljava/util/Set;->size()I

    move-result v8

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v9

    add-int/2addr v9, v8

    invoke-interface {v3}, Ljava/util/Set;->size()I

    move-result v8

    add-int/2addr v8, v9

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_18
    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const-string v10, " Movies \u2022 "

    if-eqz v9, :cond_23

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v7, v9}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_18

    invoke-virtual {v9}, Ljava/lang/String;->hashCode()I

    move-result v11

    const-string v12, ")"

    sparse-switch v11, :sswitch_data_0

    goto :goto_15

    :sswitch_0
    const-string v10, "SERIES_WATCHLIST"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_19

    goto :goto_15

    :cond_19
    new-instance v18, Lm6/v0;

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    const-string v10, "\ud83d\udcfa VOD Series ("

    invoke-static {v9, v10, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    sget-object v10, Lm6/n6;->XTREAM:Lm6/n6;

    if-ne v9, v10, :cond_1a

    const-string v9, "Browse provider VOD Series with Seasons & Episodes"

    :goto_16
    move-object/from16 v21, v9

    goto :goto_17

    :cond_1a
    const-string v9, "Connect Xtream Codes for VOD Series"

    goto :goto_16

    :goto_17
    new-instance v9, Lm6/a3;

    const/16 v10, 0x1b

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800d0

    const-string v22, "SERIES"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_15

    :sswitch_1
    const-string v11, "FAVORITES_LIVE"

    invoke-virtual {v9, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1b

    goto :goto_15

    :cond_1b
    new-instance v18, Lm6/v0;

    const-string v9, "\u2605 Personal Watchlist & Favorites ("

    const-string v11, " Saved)"

    invoke-static {v8, v9, v11}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-interface/range {v28 .. v28}, Ljava/util/Set;->size()I

    move-result v9

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v11

    invoke-interface {v3}, Ljava/util/Set;->size()I

    move-result v12

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v14

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " Live TV Favorites \u2022 "

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " Series \u2022 "

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " Custom Groups"

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v21

    new-instance v9, Lm6/a3;

    const/16 v10, 0x19

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800d5

    const-string v22, "WATCHLIST"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :sswitch_2
    const-string v10, "CONTINUE_WATCHING"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1c

    goto/16 :goto_15

    :cond_1c
    new-instance v18, Lm6/v0;

    invoke-interface/range {v17 .. v17}, Ljava/util/List;->size()I

    move-result v9

    const-string v10, "\u25b6 Continue Watching ("

    const-string v11, " Active Items)"

    invoke-static {v9, v10, v11}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-interface/range {v17 .. v17}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_1d

    const-string v9, "Resume Movies & Series Episodes from your exact saved timestamp"

    :goto_18
    move-object/from16 v21, v9

    goto :goto_19

    :cond_1d
    const-string v9, "No Movies or Episodes in progress yet"

    goto :goto_18

    :goto_19
    invoke-interface/range {v17 .. v17}, Ljava/util/List;->size()I

    move-result v9

    const-string v10, " RESUME"

    invoke-static {v10, v9}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v22

    new-instance v9, Lm6/a3;

    const/16 v10, 0x16

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800c3

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :sswitch_3
    const-string v10, "PINNED_CHANNELS"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1e

    goto/16 :goto_15

    :cond_1e
    new-instance v18, Lm6/v0;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-string v10, "\ud83d\udccc Pinned Live Channels ("

    invoke-static {v9, v10, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-string v10, " PINNED"

    invoke-static {v10, v9}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v22

    new-instance v9, Lm6/a3;

    const/16 v10, 0x17

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800d5

    const-string v21, "Jump directly to your pinned channels"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :sswitch_4
    const-string v10, "MOVIES_WATCHLIST"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1f

    goto/16 :goto_15

    :cond_1f
    new-instance v18, Lm6/v0;

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    const-string v10, "\ud83c\udfac VOD Movies ("

    invoke-static {v9, v10, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->c2:Lm6/n6;

    sget-object v10, Lm6/n6;->XTREAM:Lm6/n6;

    if-ne v9, v10, :cond_20

    const-string v9, "Browse provider VOD Movies poster grid"

    :goto_1a
    move-object/from16 v21, v9

    goto :goto_1b

    :cond_20
    const-string v9, "Connect Xtream Codes for VOD Movies"

    goto :goto_1a

    :goto_1b
    new-instance v9, Lm6/a3;

    const/16 v10, 0x1a

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800c7

    const-string v22, "MOVIES"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :sswitch_5
    const-string v10, "RECENT_LIVE"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_21

    goto/16 :goto_15

    :cond_21
    new-instance v18, Lm6/v0;

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-string v10, "\u27f2 Recently Watched Live TV Channels ("

    invoke-static {v9, v10, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v9

    const-string v10, " RECENT"

    invoke-static {v10, v9}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v22

    new-instance v9, Lm6/a3;

    const/16 v10, 0x18

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800c5

    const-string v21, "Quickly tune back to your recently watched television channels"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :sswitch_6
    const-string v10, "CUSTOM_GROUPS"

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_22

    goto/16 :goto_15

    :cond_22
    new-instance v18, Lm6/v0;

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v9

    const-string v10, "\ud83d\udcc2 Custom Channel Collections ("

    invoke-static {v9, v10, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v9

    const-string v10, " GROUPS"

    invoke-static {v10, v9}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v22

    new-instance v9, Lm6/a3;

    const/16 v10, 0x1d

    invoke-direct {v9, v0, v10}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800c0

    const-string v21, "Browse your custom organized channel groups"

    move-object/from16 v24, v9

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v9, v18

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_15

    :cond_23
    new-instance v18, Lm6/v0;

    new-instance v1, Lm6/x3;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800d2

    const-string v20, "\ud83c\udf9b\ufe0f Customize Home Rows (Show / Hide / Reorder)"

    const-string v21, "Hide or reorder Home Hub rows per profile"

    const-string v22, "CUSTOMIZE"

    move-object/from16 v24, v1

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v18

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v14, Lm6/v0;

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const-string v2, "\ud83d\udce1 Live TV Channels & EPG Guide ("

    const-string v3, " Channels)"

    invoke-static {v1, v2, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    new-instance v1, Lm6/x3;

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v19, 0x0

    const v15, 0x7f0800c1

    const-string v17, "Browse Live TV categories, What\'s On Now EPG guide & custom collections"

    const-string v18, "LIVE TV"

    move-object/from16 v20, v1

    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v15, Lm6/v0;

    new-instance v1, Lm6/a3;

    const/16 v2, 0x14

    invoke-direct {v1, v0, v2}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v20, 0x0

    const v16, 0x7f0800cf

    const-string v17, "\ud83d\udd0d Universal Smart Search"

    const-string v18, "Instant typo-tolerant search across Live TV, Movies, Series & Categories"

    const-string v19, "SEARCH"

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v16, Lm6/v0;

    new-instance v1, Lm6/a3;

    const/16 v2, 0x15

    invoke-direct {v1, v0, v2}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v21, 0x0

    const v17, 0x7f0800d8

    const-string v18, "\u2699\ufe0f 15-Category Settings, Diagnostics & Backup Center"

    const-string v19, "Playback, Buffer, Performance, Density, Overscan, Playlist Health, Storage & Backup"

    const-string v20, "SETTINGS"

    move-object/from16 v22, v1

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v16

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    if-eqz v1, :cond_24

    iget-object v1, v1, Lm6/w8;->a:Ljava/lang/String;

    if-nez v1, :cond_25

    :cond_24
    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->f2:Ljava/lang/String;

    :cond_25
    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Profile: "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Live \u2022 "

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Series"

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    invoke-virtual {v1}, Lm6/m6;->R()Lm6/l8;

    move-result-object v1

    invoke-virtual {v1}, Lm6/l8;->a()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800c4

    const-string v2, "RAM PLAYER Cinematic Home Hub"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void

    :cond_26
    move-object/from16 v0, p0

    move-object/from16 v3, v17

    goto/16 :goto_6

    :sswitch_data_0
    .sparse-switch
        -0x7860c59e -> :sswitch_6
        0x9826850 -> :sswitch_5
        0xd2523d1 -> :sswitch_4
        0xf719057 -> :sswitch_3
        0x2ddabd4b -> :sswitch_2
        0x4c25b1f4 -> :sswitch_1
        0x4c870a05 -> :sswitch_0
    .end sparse-switch
.end method

.method public static final M(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 27

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->p(Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->T(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v2

    new-instance v5, Ljava/util/ArrayList;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    add-int/lit8 v3, v3, 0x4

    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    const/16 v3, 0x19

    invoke-static {v3, v1}, Lo6/j;->h0(ILjava/util/List;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_8

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lm6/n1;

    iget-object v6, v4, Lm6/n1;->e:Lm6/c0;

    iget v7, v4, Lm6/n1;->g:I

    iget-wide v8, v4, Lm6/n1;->b:J

    sget-object v10, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    const-string v11, "%"

    const-string v12, " min \u2022 "

    const-string v13, "Watched "

    const-string v14, "%)"

    const-string v15, " ("

    const-wide/16 v16, 0x1

    const-wide/32 v18, 0xea60

    const/16 v20, 0x0

    if-ne v6, v10, :cond_4

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->x1:Ljava/lang/Object;

    iget-object v7, v4, Lm6/n1;->a:Ljava/lang/String;

    invoke-interface {v6, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    if-eqz v6, :cond_1

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-static {v10, v7}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v20, v7

    check-cast v20, Lm6/n;

    :cond_1
    move-object/from16 v7, v20

    if-eqz v7, :cond_0

    if-eqz v6, :cond_0

    div-long v8, v8, v18

    cmp-long v10, v8, v16

    if-gez v10, :cond_2

    move-wide/from16 v8, v16

    :cond_2
    new-instance v16, Lm6/v0;

    invoke-virtual {v7}, Lm6/n;->a()Ljava/lang/String;

    move-result-object v10

    move-object/from16 v23, v1

    invoke-virtual {v4}, Lm6/n1;->b()I

    move-result v1

    move-object/from16 v24, v2

    new-instance v2, Ljava/lang/StringBuilder;

    move-object/from16 v25, v3

    const-string v3, "\u25b6 [MOVIE] "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    iget-object v1, v7, Lm6/n;->d:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " \u2022 Tap to open Movie Details / Resume"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v4}, Lm6/n1;->b()I

    move-result v1

    invoke-static {v11, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v20

    new-instance v1, Lm6/x2;

    const/4 v2, 0x5

    invoke-direct {v1, v0, v6, v2}, Lm6/x2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;I)V

    const v17, 0x7f0800c7

    const/16 v21, 0x1

    move-object/from16 v22, v1

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v16

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    :goto_1
    move-object/from16 v1, v23

    move-object/from16 v2, v24

    move-object/from16 v3, v25

    goto/16 :goto_0

    :cond_4
    move-object/from16 v23, v1

    move-object/from16 v24, v2

    move-object/from16 v25, v3

    sget-object v1, Lm6/c0;->XTREAM_SERIES_EPISODE:Lm6/c0;

    if-ne v6, v1, :cond_3

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Lm6/m7;

    iget-object v3, v3, Lm6/m7;->a:Ljava/lang/String;

    iget-object v6, v4, Lm6/n1;->f:Ljava/lang/String;

    invoke-static {v3, v6}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    move-object/from16 v20, v2

    :cond_6
    move-object/from16 v1, v20

    check-cast v1, Lm6/m7;

    if-eqz v1, :cond_3

    div-long v8, v8, v18

    cmp-long v2, v8, v16

    if-gez v2, :cond_7

    move-wide/from16 v8, v16

    :cond_7
    new-instance v16, Lm6/v0;

    iget-object v2, v1, Lm6/m7;->c:Ljava/lang/String;

    iget v3, v4, Lm6/n1;->h:I

    invoke-virtual {v4}, Lm6/n1;->b()I

    move-result v6

    new-instance v10, Ljava/lang/StringBuilder;

    move-object/from16 v26, v5

    const-string v5, "\u25b6 [SERIES] "

    invoke-direct {v10, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " \u2022 S"

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "E"

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    iget-object v2, v1, Lm6/m7;->d:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " \u2022 Tap to open Season "

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v4}, Lm6/n1;->b()I

    move-result v2

    invoke-static {v11, v2}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v20

    new-instance v2, Lm6/y2;

    const/4 v3, 0x2

    invoke-direct {v2, v3, v0, v1, v4}, Lm6/y2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;)V

    const v17, 0x7f0800d0

    const/16 v21, 0x1

    move-object/from16 v22, v2

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    move-object/from16 v1, v16

    move-object/from16 v5, v26

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :cond_8
    move-object/from16 v23, v1

    move-object/from16 v24, v2

    invoke-interface/range {v23 .. v23}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_9

    new-instance v6, Lm6/v0;

    invoke-interface/range {v23 .. v23}, Ljava/util/List;->size()I

    move-result v1

    const-string v2, "Clear All Continue Watching Progress ("

    const-string v3, " Items)"

    invoke-static {v1, v2, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v12, Lm6/x3;

    const/4 v1, 0x2

    invoke-direct {v12, v0, v1}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800d9

    const-string v9, "Remove all in-progress resume points for the active profile"

    const-string v10, "CLEAR"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    invoke-interface/range {v24 .. v24}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_a

    new-instance v6, Lm6/v0;

    invoke-interface/range {v24 .. v24}, Ljava/util/Set;->size()I

    move-result v1

    const-string v2, "Clear Completed Watch History ("

    const-string v3, " Watched Items)"

    invoke-static {v1, v2, v3}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v12, Lm6/x3;

    const/4 v1, 0x3

    invoke-direct {v12, v0, v1}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800d9

    const-string v9, "Reset watched checkmarks for Movies and Series Episodes in this profile"

    const-string v10, "RESET"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    new-instance v6, Lm6/v0;

    new-instance v12, Lm6/a1;

    const/16 v1, 0xc

    invoke-direct {v12, v1}, Lm6/a1;-><init>(I)V

    const/4 v11, 0x0

    const v7, 0x7f0800c7

    const-string v8, "No Continue Watching Items Yet"

    const-string v9, "Movies and Series Episodes you watch for at least 10 seconds appear here automatically (Live TV is excluded)"

    const-string v10, "EMPTY"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    invoke-interface/range {v23 .. v23}, Ljava/util/List;->size()I

    move-result v1

    invoke-interface/range {v24 .. v24}, Ljava/util/Set;->size()I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " In-Progress \u2022 "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Completed (Per-Profile Isolated)"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "PROGRESS"

    const-string v6, "Back"

    const v1, 0x7f0800c3

    const-string v2, "Continue Watching & Watch History"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final N(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 22

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lm6/m6;->B(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->O(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lm6/m6;->q(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v3

    new-instance v5, Ljava/util/ArrayList;

    const/16 v4, 0x10

    invoke-direct {v5, v4}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v6, Lm6/v0;

    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v7

    const-string v8, "\u2605 Live TV Favorite Channels ("

    const-string v13, ")"

    invoke-static {v7, v8, v13}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v7

    const-string v14, " CH"

    invoke-static {v14, v7}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    xor-int/lit8 v11, v4, 0x1

    new-instance v12, Lm6/x3;

    const/4 v4, 0x4

    invoke-direct {v12, v0, v4}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v7, 0x7f0800c5

    const-string v9, "Open Live TV drawer filtered to your starred favorite channels"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v15, Lm6/v0;

    invoke-interface {v1}, Ljava/util/Set;->size()I

    move-result v4

    const-string v6, "\ud83c\udfac Movies Watchlist ("

    invoke-static {v4, v6, v13}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    invoke-interface {v1}, Ljava/util/Set;->size()I

    move-result v1

    const-string v4, " MOVIES"

    invoke-static {v4, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v19

    new-instance v1, Lm6/x3;

    const/4 v4, 0x5

    invoke-direct {v1, v0, v4}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v20, 0x0

    const v16, 0x7f0800c7

    const-string v18, "Open Movies poster grid filtered to your saved Movies Watchlist"

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v6, Lm6/v0;

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v1

    const-string v4, "\ud83d\udcfa Series Watchlist ("

    invoke-static {v1, v4, v13}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v1

    const-string v2, " SERIES"

    invoke-static {v2, v1}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/x3;

    const/4 v1, 0x6

    invoke-direct {v12, v0, v1}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800d0

    const-string v9, "Open Series poster grid filtered to your saved Series Watchlist"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    new-instance v6, Lm6/v0;

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v4

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "\ud83d\udcc2 Collection: "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " ("

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " Channels)"

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const-string v4, "Tap to browse channels in \'"

    const-string v7, "\' or manage collection"

    invoke-static {v4, v3, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v4

    invoke-static {v14, v4}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/y2;

    const/4 v4, 0x3

    invoke-direct {v12, v4, v0, v3, v2}, Lm6/y2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v11, 0x0

    const v7, 0x7f0800c0

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    new-instance v7, Lm6/v0;

    new-instance v13, Lm6/x3;

    const/16 v1, 0x8

    invoke-direct {v13, v0, v1}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800c0

    const-string v9, "+ Add Current Channel to a Custom Collection"

    const-string v10, "Create a new group (e.g. \'Sports VIP\', \'Kids\', \'Morning News\') or add current channel"

    const-string v11, "NEW GROUP"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const-string v4, "COLLECTIONS"

    const-string v6, "Back"

    const v1, 0x7f0800d5

    const-string v2, "Favorites, Watchlists & Custom Collections"

    const-string v3, "Profile-isolated Live TV Favorites, Movie/Series Watchlists & Custom Channel Groups"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final O(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 20

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    iget v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->c3:I

    invoke-static {v2, v1}, Lo6/j;->Y(ILjava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lm6/n;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lm6/m6;->v(Ljava/lang/String;)Ljava/util/Set;

    move-result-object v2

    new-instance v5, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v6, Lm6/v0;

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->p1:Lm6/x0;

    invoke-virtual {v3}, Lm6/x0;->b()Ljava/lang/String;

    move-result-object v3

    const-string v4, "Sort Live TV Channels: "

    invoke-static {v4, v3}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->p1:Lm6/x0;

    invoke-virtual {v3}, Lm6/x0;->a()Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/a3;

    const/16 v3, 0x13

    invoke-direct {v12, v0, v3}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v7, 0x7f0800c1

    const-string v9, "Tap to cycle: Channel Number \u2192 A-Z \u2192 Z-A \u2192 Category \u2192 Recently Watched"

    const/4 v11, 0x1

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz v1, :cond_8

    iget-object v3, v1, Lm6/n;->a:Ljava/lang/String;

    iget-object v4, v1, Lm6/n;->c:Ljava/lang/String;

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->Z2:Ljava/util/Set;

    invoke-interface {v6, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    new-instance v7, Lm6/v0;

    if-eqz v6, :cond_0

    const-string v8, "\u2605 Remove \'"

    const-string v9, "\' from Favorites"

    :goto_0
    invoke-static {v8, v4, v9}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v9, v8

    goto :goto_1

    :cond_0
    const-string v8, "\u2606 Add \'"

    const-string v9, "\' to Favorites"

    goto :goto_0

    :goto_1
    invoke-virtual {v1}, Lm6/n;->c()Ljava/lang/String;

    move-result-object v8

    iget-object v10, v1, Lm6/n;->d:Ljava/lang/String;

    const-string v11, "Channel #"

    const-string v12, " \u2022 "

    invoke-static {v11, v8, v12, v10}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v6, :cond_1

    const-string v6, "FAVORITE \u2605"

    :goto_2
    move-object v11, v6

    goto :goto_3

    :cond_1
    const-string v6, "+ FAV"

    goto :goto_2

    :goto_3
    new-instance v13, Lm6/x3;

    const/4 v6, 0x7

    invoke-direct {v13, v0, v6}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800d5

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    iget-object v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    const-string v8, "channelId"

    invoke-static {v3, v8}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v3}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v9, 0x0

    if-eqz v8, :cond_2

    move v6, v9

    goto :goto_4

    :cond_2
    invoke-virtual {v6, v7}, Lm6/m6;->G(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    :goto_4
    new-instance v10, Lm6/v0;

    if-eqz v6, :cond_3

    const-string v7, "\ud83d\udccc Unpin \'"

    const-string v8, "\' from Quick Bar"

    :goto_5
    invoke-static {v7, v4, v8}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v12, v7

    goto :goto_6

    :cond_3
    const-string v7, "\ud83d\udccc Pin \'"

    const-string v8, "\' to Quick Bar"

    goto :goto_5

    :goto_6
    if-eqz v6, :cond_4

    const-string v6, "PINNED \u2605"

    :goto_7
    move-object v14, v6

    goto :goto_8

    :cond_4
    const-string v6, "PIN"

    goto :goto_7

    :goto_8
    new-instance v6, Lm6/q2;

    const/4 v7, 0x1

    invoke-direct {v6, v0, v1, v7}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/4 v15, 0x0

    const v11, 0x7f0800d5

    const-string v13, "Pinned channels appear first in your Cinematic Home Hub"

    move-object/from16 v16, v6

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v11, Lm6/v0;

    const-string v6, "\ud83d\udcc2 Add \'"

    const-string v7, "\' to Custom Collection"

    invoke-static {v6, v4, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    new-instance v6, Lm6/q2;

    const/4 v7, 0x2

    invoke-direct {v6, v0, v1, v7}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/16 v16, 0x0

    const v12, 0x7f0800c0

    const-string v14, "Organize into your own custom channel group"

    const-string v15, "GROUP"

    move-object/from16 v17, v6

    invoke-direct/range {v11 .. v17}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v12, Lm6/v0;

    const-string v6, "\u270f\ufe0f Rename Channel \'"

    const-string v7, "\'"

    invoke-static {v6, v4, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    new-instance v6, Lm6/q2;

    const/4 v8, 0x3

    invoke-direct {v6, v0, v1, v8}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/16 v17, 0x0

    const v13, 0x7f0800c1

    const-string v15, "Set a custom display alias for this channel in your profile"

    const-string v16, "RENAME"

    move-object/from16 v18, v6

    invoke-direct/range {v12 .. v18}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v13, Lm6/v0;

    const-string v6, "\ud83d\ude48 Hide Channel \'"

    const-string v8, "\' from Drawer"

    invoke-static {v6, v4, v8}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    new-instance v6, Lm6/q2;

    const/4 v8, 0x4

    invoke-direct {v6, v0, v1, v8}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/16 v18, 0x0

    const v14, 0x7f0800d9

    const-string v16, "Hides this channel from Live TV browsing until unhidden"

    const-string v17, "HIDE"

    move-object/from16 v19, v6

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v6

    iget-object v8, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-static {v3}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_5

    goto :goto_9

    :cond_5
    invoke-virtual {v6, v8}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v9

    :goto_9
    new-instance v10, Lm6/v0;

    if-eqz v9, :cond_6

    const-string v3, "\ud83d\udee1\ufe0f Unblock \'"

    const-string v6, "\' from Blacklist"

    :goto_a
    invoke-static {v3, v4, v6}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object v12, v3

    goto :goto_b

    :cond_6
    const-string v3, "\ud83d\udeab Blacklist \'"

    const-string v6, "\' Permanently"

    goto :goto_a

    :goto_b
    if-eqz v9, :cond_7

    const-string v3, "BLOCKED"

    :goto_c
    move-object v14, v3

    goto :goto_d

    :cond_7
    const-string v3, "BLACKLIST"

    goto :goto_c

    :goto_d
    new-instance v3, Lm6/q2;

    const/4 v6, 0x5

    invoke-direct {v3, v0, v1, v6}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/4 v15, 0x0

    const v11, 0x7f0800c6

    const-string v13, "Separate from Hide/Unhide \u2014 blacklisted channels stay blocked until explicitly unblocked"

    move-object/from16 v16, v3

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v3

    iget-object v6, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v3, v6}, Lm6/m6;->g0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v3, v3, Lm6/m6;->b:Landroid/content/SharedPreferences;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "channel_preview_v190_"

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x1

    invoke-interface {v3, v6, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_8

    new-instance v8, Lm6/v0;

    const-string v3, "\ud83d\udc41\ufe0f Channel Preview Card: \'"

    invoke-static {v3, v4, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v14, Lm6/q2;

    const/4 v3, 0x6

    invoke-direct {v14, v0, v1, v3}, Lm6/q2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/n;I)V

    const/4 v13, 0x0

    const v9, 0x7f0800ca

    const-string v11, "Preview channel metadata & EPG without spawning a second player (512MB RAM safe)"

    const-string v12, "PREVIEW"

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v3}, Lm6/m6;->o(Ljava/lang/String;)Ljava/util/HashSet;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/HashSet;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_9

    new-instance v6, Lm6/v0;

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v3

    const-string v4, "\ud83d\udee1\ufe0f Manage Channel Blacklist ("

    const-string v7, " Blocked)"

    invoke-static {v3, v4, v7}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result v1

    const-string v3, "BLACKLIST "

    invoke-static {v3, v1}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/x3;

    const/16 v1, 0x9

    invoke-direct {v12, v0, v1}, Lm6/x3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800c6

    const-string v9, "View, unblock individual channels, or clear your persistent channel blacklist"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_a

    new-instance v6, Lm6/v0;

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v1

    const-string v3, "\ud83d\udc41\ufe0f Unhide All Hidden Channels ("

    const-string v4, " Hidden)"

    invoke-static {v1, v3, v4}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v1

    const-string v3, "UNHIDE "

    invoke-static {v3, v1}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lm6/x2;

    const/4 v1, 0x3

    invoke-direct {v12, v0, v2, v1}, Lm6/x2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;I)V

    const/4 v11, 0x0

    const v7, 0x7f0800d7

    const-string v9, "Restore all hidden channels back into the Live TV channel list"

    invoke-direct/range {v6 .. v12}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    new-instance v7, Lm6/v0;

    new-instance v13, Lm6/a3;

    const/16 v1, 0x1c

    invoke-direct {v13, v0, v1}, Lm6/a3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/4 v12, 0x0

    const v8, 0x7f0800c6

    const-string v9, "\ud83e\ude7a Playlist Health & Smart Duplicate Detector"

    const-string v10, "Inspect channel health, missing logos, backup streams & duplicate channels"

    const-string v11, "HEALTH"

    invoke-direct/range {v7 .. v13}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-interface {v2}, Ljava/util/Set;->size()I

    move-result v2

    iget-object v3, v0, Lcom/harindra/iptvpro/PlayerActivity;->p1:Lm6/x0;

    invoke-virtual {v3}, Lm6/x0;->b()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Total Channels \u2022 "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " Hidden \u2022 Sort: "

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v4, "CHANNELS"

    const-string v6, "Close"

    const v1, 0x7f0800c1

    const-string v2, "Live TV Channel Management & Sorting"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final P(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 39

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "stop_live_tv_in_background_v190"

    const/4 v3, 0x1

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "auto_reconnect_live_on_return_v190"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    iget-object v2, v2, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v4, "auto_next_episode_enabled_v181"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    invoke-virtual {v2}, Lm6/m6;->N()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    div-long v11, v4, v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v2

    invoke-virtual {v2}, Lm6/m6;->S()F

    move-result v2

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    invoke-virtual {v4}, Lm6/m6;->E()J

    move-result-wide v4

    div-long v13, v4, v6

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v4

    iget-object v4, v4, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v5, "external_player_fallback_v190"

    const/4 v6, 0x0

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v21

    new-instance v4, Lm6/v0;

    const-string v17, "ON \u2713"

    const-string v18, "OFF"

    if-eqz v9, :cond_0

    move-object/from16 v8, v17

    goto :goto_0

    :cond_0
    move-object/from16 v8, v18

    :goto_0
    new-instance v10, Lm6/k2;

    invoke-direct {v10, v0, v9, v3}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const v5, 0x7f0800c5

    move v7, v6

    const-string v6, "Stop Live TV When Leaving Live TV Screen"

    move/from16 v16, v7

    const-string v7, "Immediately stop Live TV audio/video & release buffers when opening Movies, Series, Search or Settings"

    move/from16 v3, v16

    move/from16 v23, v21

    invoke-direct/range {v4 .. v10}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v25, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v5

    iget-object v5, v5, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v6, "background_audio_notification_v194"

    invoke-interface {v5, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_1

    move-object/from16 v29, v17

    goto :goto_1

    :cond_1
    move-object/from16 v29, v18

    :goto_1
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v5

    iget-object v5, v5, Lm6/m6;->b:Landroid/content/SharedPreferences;

    invoke-interface {v5, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v30

    new-instance v5, Lm6/j5;

    const/4 v6, 0x3

    invoke-direct {v5, v0, v6}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v26, 0x7f0800ca

    const-string v27, "Keep Playing in Background (Notification Controls)"

    const-string v28, "OFF (Default): pauses when you leave RAM PLAYER \u2022 ON: audio continues with Play/Pause & Previous/Next channel controls"

    move-object/from16 v31, v5

    invoke-direct/range {v25 .. v31}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v26, Lm6/v0;

    if-eqz v1, :cond_2

    const-string v5, "AUTO-PLAY"

    :goto_2
    move-object/from16 v30, v5

    goto :goto_3

    :cond_2
    const-string v5, "WAIT FOR OK \u2713"

    goto :goto_2

    :goto_3
    xor-int/lit8 v31, v1, 0x1

    new-instance v5, Lm6/k2;

    invoke-direct {v5, v0, v1, v6}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const v27, 0x7f0800ca

    const-string v28, "Auto-Reconnect Live TV When Returning"

    const-string v29, "OFF (Default): Remembers channel & waits for OK/Play \u2022 ON: Automatically reconnects stream on return"

    move-object/from16 v32, v5

    invoke-direct/range {v26 .. v32}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v10, Lm6/v0;

    move-wide v7, v13

    if-eqz v15, :cond_3

    move-object/from16 v14, v17

    goto :goto_4

    :cond_3
    move-object/from16 v14, v18

    :goto_4
    new-instance v1, Lm6/k2;

    const/4 v5, 0x4

    invoke-direct {v1, v0, v15, v5}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    move-wide v12, v11

    const v11, 0x7f0800d0

    move-wide/from16 v19, v12

    const-string v12, "Smart Auto Next Episode (Series)"

    const-string v13, "8-second countdown prompt before playing the next episode in the same series"

    move-object/from16 v16, v1

    move v9, v5

    move v1, v6

    move-wide v5, v7

    move-wide/from16 v7, v19

    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v27, Lm6/v0;

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "VOD & Series Remote Seek Step: "

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v12, " Seconds"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v29

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v12, "s"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v31

    new-instance v11, Lm6/k5;

    invoke-direct {v11, v7, v8, v0, v3}, Lm6/k5;-><init>(JLcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v32, 0x0

    const v28, 0x7f0800d4

    const-string v30, "Tap to cycle D-Pad Left/Right seek interval: 5s \u2192 10s \u2192 15s \u2192 30s \u2192 60s"

    move-object/from16 v33, v11

    invoke-direct/range {v27 .. v33}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v28, Lm6/v0;

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "VOD Movie & Episode Playback Speed: "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v8, "x"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v30

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v32

    new-instance v7, Lm6/l5;

    invoke-direct {v7, v2, v0}, Lm6/l5;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    const/16 v33, 0x0

    const v29, 0x7f0800ce

    const-string v31, "Tap to cycle VOD playback speed: 0.75x \u2192 1.0x \u2192 1.25x \u2192 1.5x \u2192 2.0x"

    move-object/from16 v34, v7

    invoke-direct/range {v28 .. v34}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v29, Lm6/v0;

    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->o2:Z

    if-eqz v2, :cond_4

    move-object/from16 v33, v17

    goto :goto_5

    :cond_4
    move-object/from16 v33, v18

    :goto_5
    new-instance v7, Lm6/j5;

    const/4 v8, 0x5

    invoke-direct {v7, v0, v8}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v30, 0x7f0800ce

    const-string v31, "Auto-Start RAM PLAYER on TV Boot"

    const-string v32, "Launch RAM PLAYER automatically when Android TV powers on"

    move/from16 v34, v2

    move-object/from16 v35, v7

    invoke-direct/range {v29 .. v35}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v30, Lm6/v0;

    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->p2:Z

    if-eqz v2, :cond_5

    move-object/from16 v34, v17

    goto :goto_6

    :cond_5
    move-object/from16 v34, v18

    :goto_6
    new-instance v7, Lm6/j5;

    const/4 v11, 0x6

    invoke-direct {v7, v0, v11}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v31, 0x7f0800c5

    const-string v32, "Auto-Resume Last Channel on Cold Boot"

    const-string v33, "Automatically start your last watched Live TV channel on app launch"

    move/from16 v35, v2

    move-object/from16 v36, v7

    invoke-direct/range {v30 .. v36}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v31, Lm6/v0;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v7, "OSD Auto-Hide Timeout: "

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v33

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v35

    new-instance v2, Lm6/k5;

    const/4 v7, 0x1

    invoke-direct {v2, v5, v6, v0, v7}, Lm6/k5;-><init>(JLcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v36, 0x0

    const v32, 0x7f0800d3

    const-string v34, "Tap to cycle player info banner auto-hide delay: 2s \u2192 3s \u2192 5s \u2192 8s \u2192 12s"

    move-object/from16 v37, v2

    invoke-direct/range {v31 .. v37}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v32, Lm6/v0;

    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    if-eqz v2, :cond_6

    const-string v2, "Player Lock: LOCKED"

    :goto_7
    move-object/from16 v34, v2

    goto :goto_8

    :cond_6
    const-string v2, "Player Lock (Accidental Button Protection)"

    goto :goto_7

    :goto_8
    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    if-eqz v2, :cond_7

    const-string v2, "LOCKED \u2713"

    move-object/from16 v36, v2

    goto :goto_9

    :cond_7
    move-object/from16 v36, v18

    :goto_9
    iget-boolean v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->i3:Z

    new-instance v5, Lm6/j5;

    const/4 v6, 0x7

    invoke-direct {v5, v0, v6}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v33, 0x7f0800ca

    const-string v35, "Toggle playback key lock to prevent accidental channel changes or exits"

    move/from16 v37, v2

    move-object/from16 v38, v5

    invoke-direct/range {v32 .. v38}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v16, Lm6/v0;

    move/from16 v2, v23

    if-eqz v2, :cond_8

    const-string v18, "ENABLED \u2713"

    :cond_8
    move-object/from16 v20, v18

    new-instance v5, Lm6/k2;

    const/4 v7, 0x2

    invoke-direct {v5, v0, v2, v7}, Lm6/k2;-><init>(Lcom/harindra/iptvpro/PlayerActivity;ZI)V

    const v17, 0x7f0800ce

    const-string v18, "Optional External Player Fallback"

    const-string v19, "Allow launching streams in external players (VLC / MX Player) from Quick Menu"

    move/from16 v21, v2

    move-object/from16 v22, v5

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v17, Lm6/v0;

    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->B()Lm6/q1;

    move-result-object v2

    iget-object v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v2, v5}, Lm6/q1;->c(Ljava/lang/String;)Lm6/p1;

    move-result-object v2

    iget-object v2, v2, Lm6/p1;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const-string v5, " QUEUED"

    invoke-static {v5, v2}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v21

    new-instance v2, Lm6/j5;

    invoke-direct {v2, v0, v7}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v22, 0x0

    const v18, 0x7f0800cb

    const-string v19, "Playback Queue"

    const-string v20, "Queued movies & episodes play in order; an explicit queue wins over Auto-Next"

    move-object/from16 v23, v2

    invoke-direct/range {v17 .. v23}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/16 v2, 0xc

    new-array v2, v2, [Lm6/v0;

    aput-object v4, v2, v3

    const/16 v24, 0x1

    aput-object v25, v2, v24

    aput-object v26, v2, v7

    aput-object v10, v2, v1

    aput-object v27, v2, v9

    aput-object v28, v2, v8

    aput-object v29, v2, v11

    aput-object v30, v2, v6

    const/16 v1, 0x8

    aput-object v31, v2, v1

    const/16 v1, 0x9

    aput-object v32, v2, v1

    const/16 v1, 0xa

    aput-object v16, v2, v1

    const/16 v1, 0xb

    aput-object v17, v2, v1

    invoke-static {v2}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v4, "PLAYBACK"

    const-string v6, "Back"

    const v1, 0x7f0800ca

    const-string v2, "Playback & Live TV Background Management"

    const-string v3, "Zero background audio leaks \u2022 Configurable seek step & VOD speed"

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final Q(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 35

    move-object/from16 v0, p0

    const-string v1, "<this>"

    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Runtime;->totalMemory()J

    move-result-wide v2

    invoke-virtual {v1}, Ljava/lang/Runtime;->freeMemory()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-wide/32 v4, 0x100000

    div-long/2addr v2, v4

    invoke-virtual {v1}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v6

    div-long/2addr v6, v4

    const-wide/16 v4, 0x1

    cmp-long v1, v6, v4

    if-gez v1, :cond_0

    goto :goto_0

    :cond_0
    move-wide v4, v6

    :goto_0
    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Ld1/k0;->I1()V

    iget-object v7, v1, Ld1/k0;->d0:Lv0/t;

    goto :goto_1

    :cond_1
    move-object v7, v6

    :goto_1
    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ld1/k0;->I1()V

    iget-object v6, v1, Ld1/k0;->e0:Lv0/t;

    :cond_2
    const-wide/16 v8, 0x0

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ld1/k0;->v()J

    move-result-wide v10

    invoke-virtual {v1}, Ld1/k0;->V0()J

    move-result-wide v12

    sub-long/2addr v10, v12

    cmp-long v12, v10, v8

    if-gez v12, :cond_3

    goto :goto_2

    :cond_3
    move-wide v8, v10

    :cond_4
    :goto_2
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz v7, :cond_8

    iget v11, v7, Lv0/t;->w:I

    iget v12, v7, Lv0/t;->x:I

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, "x"

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v11, v7, Lv0/t;->B:F

    const/4 v12, 0x0

    cmpl-float v12, v11, v12

    if-lez v12, :cond_5

    float-to-int v11, v11

    new-instance v12, Ljava/lang/StringBuilder;

    const-string v13, " @ "

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, "fps"

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    iget-object v11, v7, Lv0/t;->p:Ljava/lang/String;

    const-string v12, " \u2022 "

    if-eqz v11, :cond_7

    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_6

    goto :goto_3

    :cond_6
    iget-object v11, v7, Lv0/t;->p:Ljava/lang/String;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7
    :goto_3
    iget v7, v7, Lv0/t;->k:I

    if-lez v7, :cond_9

    div-int/lit16 v7, v7, 0x3e8

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, " kbps"

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4

    :cond_8
    const-string v7, "Video: Idle / Not Playing"

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_9
    :goto_4
    const-string v7, ")"

    const-string v11, " ("

    if-eqz v6, :cond_c

    iget-object v12, v6, Lv0/t;->p:Ljava/lang/String;

    if-nez v12, :cond_a

    const-string v12, "PCM"

    :cond_a
    const-string v13, " | Audio: "

    invoke-virtual {v13, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v12, v6, Lv0/t;->d:Ljava/lang/String;

    if-eqz v12, :cond_c

    invoke-static {v12}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_b

    goto :goto_5

    :cond_b
    iget-object v6, v6, Lv0/t;->d:Ljava/lang/String;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_c
    :goto_5
    new-instance v6, Ljava/lang/StringBuilder;

    const-string v12, " | Buffer: "

    invoke-direct {v6, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v8, "ms"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v0}, Ll3/e;->B(Lcom/harindra/iptvpro/PlayerActivity;)Z

    move-result v6

    if-eqz v6, :cond_d

    const-string v8, "Connected \u2022 DNS Cache Active \u2022 HTTP/2 + Keep-Alive"

    goto :goto_6

    :cond_d
    const-string v8, "Offline (Cached Catalog Mode Active)"

    :goto_6
    new-instance v12, Lm6/v0;

    const/4 v9, 0x1

    if-eqz v1, :cond_e

    invoke-virtual {v1}, Le6/e;->J()Z

    move-result v1

    if-ne v1, v9, :cond_e

    const-string v1, "PLAYING"

    :goto_7
    move-object/from16 v16, v1

    goto :goto_8

    :cond_e
    const-string v1, "IDLE"

    goto :goto_7

    :goto_8
    new-instance v1, Lm6/j5;

    const/16 v10, 0x8

    invoke-direct {v1, v0, v10}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const v13, 0x7f0800db

    const-string v14, "Measured Media3 Playback Diagnostics"

    const/16 v17, 0x1

    move-object/from16 v18, v1

    invoke-direct/range {v12 .. v18}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v16, Lm6/v0;

    if-eqz v6, :cond_f

    const-string v1, "ONLINE \u2713"

    goto :goto_9

    :cond_f
    const-string v1, "OFFLINE \u26a0\ufe0f"

    :goto_9
    const-string v10, "Network Health Status: "

    invoke-virtual {v10, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    sget-object v1, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->v1:Ljava/lang/String;

    invoke-static {v1}, Lm6/f1;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v10, " \u2022 Last Error: "

    invoke-static {v8, v10, v1}, Lq3/e;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    if-eqz v6, :cond_10

    const-string v1, "ONLINE"

    :goto_a
    move-object/from16 v20, v1

    goto :goto_b

    :cond_10
    const-string v1, "OFFLINE"

    goto :goto_a

    :goto_b
    new-instance v1, Lm6/a1;

    const/16 v6, 0xc

    invoke-direct {v1, v6}, Lm6/a1;-><init>(I)V

    const/16 v21, 0x0

    const v17, 0x7f0800c8

    move-object/from16 v22, v1

    invoke-direct/range {v16 .. v22}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v17, Lm6/v0;

    new-instance v1, Lm6/j5;

    const/16 v10, 0x9

    invoke-direct {v1, v0, v10}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v22, 0x0

    const v18, 0x7f0800d7

    const-string v19, "Recovery Action 1: Soft-Reconnect Active Stream"

    const-string v20, "Resets network sockets and reconnects current stream without losing navigation state"

    const-string v21, "RECONNECT"

    move-object/from16 v23, v1

    invoke-direct/range {v17 .. v23}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v18, Lm6/v0;

    new-instance v1, Lm6/j5;

    const/16 v10, 0xa

    invoke-direct {v1, v0, v10}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v23, 0x0

    const v19, 0x7f0800ce

    const-string v20, "Recovery Action 2: Re-Initialize Media3 Decoder Pipeline"

    const-string v21, "Safely recreates ExoPlayer instance if hardware decoder stalled on TV"

    const-string v22, "RESET PLAYER"

    move-object/from16 v24, v1

    invoke-direct/range {v18 .. v24}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v19, Lm6/v0;

    new-instance v1, Lm6/j5;

    const/16 v10, 0xb

    invoke-direct {v1, v0, v10}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v24, 0x0

    const v20, 0x7f0800d4

    const-string v21, "Measure Real Server Connection Latency (HTTP TTFB)"

    const-string v22, "Tests actual TCP/TLS/HTTP response time to your active IPTV server"

    const-string v23, "PING TEST"

    move-object/from16 v25, v1

    invoke-direct/range {v19 .. v25}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v20, Lm6/v0;

    sget-object v1, Lm6/f8;->a:Lm6/f8;

    sget-object v1, Lm6/f8;->b:Lm6/d8;

    invoke-virtual {v1}, Lm6/d8;->a()Ljava/lang/String;

    move-result-object v1

    sget-object v10, Lm6/f8;->c:Lm6/e8;

    sget-object v13, Lm6/e8;->SYSFS_FALLBACK:Lm6/e8;

    const/4 v14, 0x0

    const-string v21, ""

    if-ne v10, v13, :cond_11

    sget v10, Lm6/f8;->d:F

    invoke-static {v10}, Ljava/lang/Float;->isNaN(F)Z

    move-result v10

    if-nez v10, :cond_11

    sget v10, Lm6/f8;->d:F

    invoke-static {v10}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v10

    new-array v13, v9, [Ljava/lang/Object;

    aput-object v10, v13, v14

    invoke-static {v13, v9}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v10

    const-string v13, "%.0f"

    invoke-static {v13, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    sget-object v13, Lm6/f8;->c:Lm6/e8;

    invoke-virtual {v13}, Lm6/e8;->a()Ljava/lang/String;

    move-result-object v13

    move/from16 v27, v9

    const-string v9, "\u00b0C, "

    invoke-static {v11, v10, v9, v13, v7}, La0/h;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_c

    :cond_11
    move/from16 v27, v9

    sget-object v9, Lm6/f8;->c:Lm6/e8;

    sget-object v10, Lm6/e8;->NONE:Lm6/e8;

    if-eq v9, v10, :cond_12

    sget-object v9, Lm6/f8;->c:Lm6/e8;

    invoke-virtual {v9}, Lm6/e8;->a()Ljava/lang/String;

    move-result-object v9

    invoke-static {v11, v9, v7}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_c

    :cond_12
    move-object/from16 v7, v21

    :goto_c
    sget-object v9, Lm6/f8;->b:Lm6/d8;

    sget-object v10, Lm6/d8;->NOT_REPORTED:Lm6/d8;

    if-ne v9, v10, :cond_13

    :goto_d
    move-object/from16 v9, v21

    goto :goto_10

    :cond_13
    invoke-static {}, Lm6/f8;->b()Z

    move-result v9

    const-string v10, "ON"

    if-eqz v9, :cond_14

    move-object v9, v10

    goto :goto_e

    :cond_14
    const-string v9, "PAUSED"

    :goto_e
    invoke-static {}, Lm6/f8;->a()Z

    move-result v11

    if-eqz v11, :cond_15

    goto :goto_f

    :cond_15
    const-string v10, "DEFERRED"

    :goto_f
    const-string v11, " \u2022 prefetch "

    const-string v13, " \u2022 bg refresh "

    invoke-static {v11, v9, v13, v10}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    goto :goto_d

    :goto_10
    const-string v10, "Thermal: "

    invoke-static {v10, v1, v7, v9}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v7, "Decoders (HW/SW), HDR, passthrough, ABI, memory class, PiP, HDMI-CEC, refresh rates \u2022 "

    invoke-static {v7, v1}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    new-instance v1, Lm6/j5;

    invoke-direct {v1, v0, v6}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v25, 0x0

    const v21, 0x7f0800db

    const-string v22, "Detected Hardware Compatibility Matrix"

    const-string v24, "DETECTED"

    move-object/from16 v26, v1

    invoke-direct/range {v20 .. v26}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v28, Lm6/v0;

    new-instance v34, Lm6/m5;

    move-object v1, v0

    move-object v7, v8

    move-object v6, v15

    move-object/from16 v0, v34

    invoke-direct/range {v0 .. v7}, Lm6/m5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;JJLjava/lang/String;Ljava/lang/String;)V

    const/16 v33, 0x0

    const v29, 0x7f0800c6

    const-string v30, "Export Redacted Diagnostic Report"

    const-string v31, "View or copy complete diagnostic report with all passwords/tokens automatically redacted"

    const-string v32, "EXPORT"

    invoke-direct/range {v28 .. v34}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/4 v0, 0x7

    new-array v0, v0, [Lm6/v0;

    aput-object v12, v0, v14

    aput-object v16, v0, v27

    const/4 v1, 0x2

    aput-object v17, v0, v1

    const/4 v1, 0x3

    aput-object v18, v0, v1

    const/4 v1, 0x4

    aput-object v19, v0, v1

    const/4 v1, 0x5

    aput-object v20, v0, v1

    const/4 v1, 0x6

    aput-object v28, v0, v1

    invoke-static {v0}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "MB"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string v6, "Back"

    const v1, 0x7f0800c6

    const-string v2, "Diagnostics, Network Health & Recovery Center"

    const-string v3, "Real measured telemetry \u2022 Zero fabricated stats \u2022 One-click stream recovery"

    move-object v5, v0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final R(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 15

    const-string v1, "<this>"

    invoke-static {p0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v1, v1, Lm6/m6;->b:Landroid/content/SharedPreferences;

    const-string v2, "remote_long_press_ok_v190"

    const-string v3, "QUICK_MENU"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_0

    move-object v1, v3

    :cond_0
    new-instance v2, Ln6/d;

    const-string v4, "Global Quick Menu"

    invoke-direct {v2, v3, v4}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v3, Ln6/d;

    const-string v4, "FAVORITE_TOGGLE"

    const-string v5, "Toggle \u2605 Favorite"

    invoke-direct {v3, v4, v5}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v4, Ln6/d;

    const-string v5, "CHANNEL_INFO"

    const-string v6, "Channel Management"

    invoke-direct {v4, v5, v6}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v5, Ln6/d;

    const-string v6, "EPG_GUIDE"

    const-string v7, "EPG TV Guide"

    invoke-direct {v5, v6, v7}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v6, Ln6/d;

    const-string v7, "AUDIO_QUALITY"

    const-string v8, "Audio / Video / Subtitles"

    invoke-direct {v6, v7, v8}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v7, Ln6/d;

    const-string v8, "SETTINGS"

    const-string v9, "Settings Center"

    invoke-direct {v7, v8, v9}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v8, Ln6/d;

    const-string v9, "PLAYER_LOCK"

    const-string v10, "Toggle Player Lock"

    invoke-direct {v8, v9, v10}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, Ln6/d;

    const-string v10, "SLEEP_TIMER"

    const-string v11, "Cycle Sleep Timer"

    invoke-direct {v9, v10, v11}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v10, 0x8

    new-array v10, v10, [Ln6/d;

    const/4 v11, 0x0

    aput-object v2, v10, v11

    const/4 v2, 0x1

    aput-object v3, v10, v2

    const/4 v2, 0x2

    aput-object v4, v10, v2

    const/4 v2, 0x3

    aput-object v5, v10, v2

    const/4 v2, 0x4

    aput-object v6, v10, v2

    const/4 v3, 0x5

    aput-object v7, v10, v3

    const/4 v3, 0x6

    aput-object v8, v10, v3

    const/4 v3, 0x7

    aput-object v9, v10, v3

    invoke-static {v10}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    new-instance v6, Ljava/util/ArrayList;

    const/16 v4, 0xe

    invoke-direct {v6, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-static {v2, v3}, Lo6/j;->h0(ILjava/util/List;)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ln6/d;

    iget-object v7, v5, Ln6/d;->k:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    iget-object v5, v5, Ln6/d;->l:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v1, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    new-instance v8, Lm6/v0;

    const-string v9, "Long-Press OK / Select: "

    invoke-static {v9, v5}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v13, :cond_1

    const-string v9, "ACTIVE \u2713"

    :goto_1
    move-object v12, v9

    goto :goto_2

    :cond_1
    const-string v9, "SELECT"

    goto :goto_1

    :goto_2
    new-instance v14, Lm6/y2;

    invoke-direct {v14, v2, p0, v7, v5}, Lm6/y2;-><init>(ILcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;)V

    const v9, 0x7f0800c1

    const-string v11, "Triggered when holding OK/Enter on the TV remote"

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    const-string v1, "YELLOW"

    const-string v2, "BLUE"

    const-string v4, "RED"

    const-string v5, "GREEN"

    filled-new-array {v4, v5, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Ljava/lang/String;

    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    move-result-object v1

    iget-object v2, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    invoke-virtual {v1, v12, v2}, Lm6/m6;->I(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v5, v2

    check-cast v5, Ln6/d;

    iget-object v5, v5, Ln6/d;->k:Ljava/lang/Object;

    invoke-static {v5, v4}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_4

    :cond_4
    const/4 v2, 0x0

    :goto_4
    check-cast v2, Ln6/d;

    if-eqz v2, :cond_5

    iget-object v1, v2, Ln6/d;->l:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_6

    :cond_5
    move-object v1, v4

    :cond_6
    new-instance v8, Lm6/v0;

    const-string v2, "Remote "

    const-string v5, " Button: "

    invoke-static {v2, v12, v5, v1}, La0/h;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v1, "Tap to cycle action for "

    const-string v2, " color key on your TV remote"

    invoke-static {v1, v12, v2}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-instance v14, Lm6/d;

    const/4 v5, 0x4

    move-object v2, p0

    move-object v1, v3

    move-object v3, v12

    move-object v0, v14

    invoke-direct/range {v0 .. v5}, Lm6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v13, 0x0

    const v9, 0x7f0800c1

    invoke-direct/range {v8 .. v14}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v3, v1

    goto :goto_3

    :cond_7
    const-string v4, "REMOTE"

    move-object v5, v6

    const-string v6, "Back"

    const v1, 0x7f0800c1

    const-string v2, "TV Remote Shortcuts Configuration"

    const-string v3, "Customize Long-Press OK and Red / Green / Yellow / Blue remote keys"

    move-object v0, p0

    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static final S(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 22

    move-object/from16 v1, p0

    const-wide/16 v2, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const-string v0, "<this>"

    invoke-static {v1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Lcom/harindra/iptvpro/PlayerActivity;->t()Lm6/w;

    move-result-object v0

    invoke-virtual {v0}, Lm6/w;->k()J

    move-result-wide v5

    const-wide/16 v7, 0x400

    div-long/2addr v5, v7

    invoke-virtual {v1}, Lcom/harindra/iptvpro/PlayerActivity;->v()Ll4/c;

    move-result-object v0

    iget-object v0, v0, Ll4/c;->l:Ljava/lang/Object;

    check-cast v0, Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v9

    if-eqz v9, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v9

    goto :goto_0

    :cond_0
    move-wide v9, v2

    :goto_0
    div-long/2addr v9, v7

    const/4 v11, 0x1

    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v12

    const-string v13, "image_manager_disk_cache"

    invoke-direct {v0, v12, v13}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v12

    if-eqz v12, :cond_2

    new-instance v12, Ld7/c;

    invoke-direct {v12, v0}, Ld7/c;-><init>(Ljava/io/File;)V

    new-instance v0, Ld7/n;

    const/16 v13, 0x9

    invoke-direct {v0, v13}, Ld7/n;-><init>(I)V

    new-instance v13, Ld7/c;

    invoke-direct {v13, v12, v0, v11}, Ld7/c;-><init>(Ld7/j;Ljava/lang/Object;I)V

    new-instance v0, Ld7/h;

    invoke-direct {v0, v13}, Ld7/h;-><init>(Ld7/c;)V

    :goto_1
    invoke-virtual {v0}, Ld7/h;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_1

    invoke-virtual {v0}, Ld7/h;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/io/File;

    invoke-virtual {v12}, Ljava/io/File;->length()J

    move-result-wide v12

    add-long/2addr v2, v12

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_1
    div-long/2addr v2, v7

    :cond_2
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_3

    :goto_2
    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    move-result-object v0

    :goto_3
    instance-of v2, v0, Ln6/e;

    if-eqz v2, :cond_3

    move-object v0, v4

    :cond_3
    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    :try_start_1
    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->getUsableSpace()J

    move-result-wide v7

    const-wide/32 v12, 0x100000

    div-long/2addr v7, v12

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v0

    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    move-result-object v0

    :goto_4
    instance-of v7, v0, Ln6/e;

    if-eqz v7, :cond_4

    goto :goto_5

    :cond_4
    move-object v4, v0

    :goto_5
    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v7

    new-instance v12, Lm6/v0;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "Storage Overview: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, " MB Available on Device"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "SXB2 Catalog Cache: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, " KB \u2022 XMLTV EPG Cache: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, " KB \u2022 Poster/Logo Disk Cache: "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, " KB"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    add-long/2addr v5, v9

    add-long v9, v5, v2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v4, " KB USED"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    new-instance v0, Lm6/a1;

    const/16 v4, 0xc

    invoke-direct {v0, v4}, Lm6/a1;-><init>(I)V

    const v13, 0x7f0800cc

    const/16 v17, 0x1

    move-object/from16 v18, v0

    invoke-direct/range {v12 .. v18}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v13, Lm6/v0;

    new-instance v0, Lm6/r4;

    const/16 v4, 0x1d

    invoke-direct {v0, v1, v4}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v18, 0x0

    const v14, 0x7f0800d9

    const-string v15, "Safe Trim RAM & Temporary Artwork Cache"

    const-string v16, "Frees in-memory bitmaps & idle preload segments (Preserves all playlists, profiles, favorites & history)"

    const-string v17, "SAFE TRIM"

    move-object/from16 v19, v0

    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v14, Lm6/v0;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "Clear Poster & Logo Disk Cache ("

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, " KB)"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    new-instance v0, Lm6/j5;

    const/4 v3, 0x0

    invoke-direct {v0, v1, v3}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v19, 0x0

    const v15, 0x7f0800d9

    const-string v17, "Purges cached Glide poster thumbnails on disk without touching playlists or user data"

    const-string v18, "CLEAN ART"

    move-object/from16 v20, v0

    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    new-instance v15, Lm6/v0;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "Confirm: Purge SXB2 Playlist & XMLTV EPG Disk Caches ("

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    new-instance v0, Lm6/j5;

    invoke-direct {v0, v1, v11}, Lm6/j5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    const/16 v20, 0x0

    const v16, 0x7f0800d9

    const-string v18, "Clears cached channel/VOD files (Your saved accounts, favorites, watchlists & history remain 100% intact)"

    const-string v19, "PURGE CACHE"

    move-object/from16 v21, v0

    invoke-direct/range {v15 .. v21}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    const/4 v0, 0x4

    new-array v0, v0, [Lm6/v0;

    aput-object v12, v0, v3

    aput-object v13, v0, v11

    const/4 v2, 0x2

    aput-object v14, v0, v2

    const/4 v2, 0x3

    aput-object v15, v0, v2

    invoke-static {v0}, Lo6/k;->K([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "MB FREE"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v7, "Back"

    const v2, 0x7f0800cc

    const-string v3, "Cache & Storage Manager"

    const-string v4, "Bounded caches with zero risk to profiles, favorites, watchlists or watch history"

    invoke-static/range {v1 .. v7}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    return-void
.end method

.method public static T(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x0

    if-eqz p0, :cond_4

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    instance-of v1, p0, Ljava/util/Set;

    if-eqz v1, :cond_1

    instance-of v1, p1, Ljava/util/Set;

    if-eqz v1, :cond_1

    check-cast p0, Ljava/lang/Iterable;

    invoke-static {p0}, Lo6/j;->n0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p0

    check-cast p1, Ljava/lang/Iterable;

    invoke-static {p1}, Lo6/j;->n0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_1
    instance-of v1, p0, Ljava/lang/Float;

    if-eqz v1, :cond_3

    instance-of v1, p1, Ljava/lang/Float;

    if-eqz v1, :cond_3

    check-cast p0, Ljava/lang/Float;

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    cmpl-float p0, p0, p1

    if-nez p0, :cond_2

    goto :goto_1

    :cond_2
    return v0

    :cond_3
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_4
    :goto_0
    if-nez p0, :cond_5

    if-nez p1, :cond_5

    :goto_1
    const/4 p0, 0x1

    return p0

    :cond_5
    return v0
.end method

.method public static a(III)V
    .locals 4

    const-string v0, "fromIndex: "

    if-ltz p0, :cond_1

    if-gt p1, p2, :cond_1

    if-gt p0, p1, :cond_0

    return-void

    :cond_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    const-string v1, " > toIndex: "

    invoke-static {p0, p1, v0, v1}, La0/h;->n(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_1
    new-instance v1, Ljava/lang/IndexOutOfBoundsException;

    const-string v2, ", toIndex: "

    const-string v3, ", size: "

    invoke-static {p0, p1, v0, v2, v3}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)I
    .locals 6

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    move-result v0

    const/4 v3, -0x1

    if-ne v0, v3, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {p1}, Lu/e;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_1

    goto :goto_3

    :cond_1
    if-nez v2, :cond_4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_3

    array-length v4, v2

    if-gtz v4, :cond_2

    goto :goto_0

    :cond_2
    aget-object v2, v2, v0

    goto :goto_1

    :cond_3
    :goto_0
    return v3

    :cond_4
    :goto_1
    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const-class v5, Landroid/app/AppOpsManager;

    if-ne v3, v1, :cond_7

    invoke-static {v4, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1d

    if-lt v3, v4, :cond_6

    invoke-static {p0}, Lu/f;->c(Landroid/content/Context;)Landroid/app/AppOpsManager;

    move-result-object v3

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v4

    invoke-static {v3, p1, v4, v2}, Lu/f;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_5

    goto :goto_2

    :cond_5
    invoke-static {p0}, Lu/f;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v3, p1, v1, p0}, Lu/f;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result v2

    goto :goto_2

    :cond_6
    invoke-static {p0, v5}, Lu/e;->a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    invoke-static {p0, p1, v2}, Lu/e;->c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    goto :goto_2

    :cond_7
    invoke-static {p0, v5}, Lu/e;->a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    invoke-static {p0, p1, v2}, Lu/e;->c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    :goto_2
    if-nez v2, :cond_8

    :goto_3
    return v0

    :cond_8
    const/4 p0, -0x2

    return p0
.end method

.method public static d(Ljava/io/Closeable;)V
    .locals 0

    if-eqz p0, :cond_0

    :try_start_0
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public static e(Lm6/l6;Ljava/util/Map;)Z
    .locals 4

    const-string v0, "store"

    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1}, Lm6/l6;->a(Ljava/util/Map;)Z

    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move v2, v0

    :goto_0
    if-nez v2, :cond_1

    return v0

    :cond_1
    :try_start_1
    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v3}, Lm6/l6;->b(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, v2}, Lb4/a;->T(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    if-nez v2, :cond_3

    move v1, v0

    :cond_4
    :goto_1
    move v0, v1

    :catch_1
    return v0
.end method

.method public static f(Landroid/os/Parcelable;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;
    .locals 2

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v1, 0x0

    :try_start_0
    invoke-interface {p0, v0, v1}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    invoke-interface {p1, v0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/Parcelable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    return-object p0

    :catchall_0
    move-exception p0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p0
.end method

.method public static g(Ljava/io/File;Landroid/content/res/Resources;I)Z
    .locals 0

    :try_start_0
    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    invoke-static {p0, p1}, Lb4/a;->h(Ljava/io/File;Ljava/io/InputStream;)Z

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {p1}, Lb4/a;->d(Ljava/io/Closeable;)V

    return p0

    :catchall_0
    move-exception p0

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 p1, 0x0

    :goto_0
    invoke-static {p1}, Lb4/a;->d(Ljava/io/Closeable;)V

    throw p0
.end method

.method public static h(Ljava/io/File;Ljava/io/InputStream;)Z
    .locals 5

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskWrites()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    :try_start_0
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, p0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/16 p0, 0x400

    :try_start_1
    new-array p0, p0, [B

    :goto_0
    invoke-virtual {p1, p0}, Ljava/io/InputStream;->read([B)I

    move-result v2

    const/4 v4, -0x1

    if-eq v2, v4, :cond_0

    invoke-virtual {v3, p0, v1, v2}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    move-object v2, v3

    goto :goto_2

    :catch_0
    move-exception p0

    move-object v2, v3

    goto :goto_1

    :cond_0
    invoke-static {v3}, Lb4/a;->d(Ljava/io/Closeable;)V

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 p0, 0x1

    return p0

    :catchall_1
    move-exception p0

    goto :goto_2

    :catch_1
    move-exception p0

    :goto_1
    :try_start_2
    const-string p1, "TypefaceCompatUtil"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Error copying resource contents to temp file: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    invoke-static {v2}, Lb4/a;->d(Ljava/io/Closeable;)V

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    return v1

    :goto_2
    invoke-static {v2}, Lb4/a;->d(Ljava/io/Closeable;)V

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    throw p0
.end method

.method public static i([B)[B
    .locals 6

    array-length v0, p0

    const/16 v1, 0x10

    if-ne v0, v1, :cond_2

    new-array v0, v1, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/16 v4, 0xf

    if-ge v3, v1, :cond_1

    aget-byte v5, p0, v3

    shl-int/lit8 v5, v5, 0x1

    and-int/lit16 v5, v5, 0xfe

    int-to-byte v5, v5

    aput-byte v5, v0, v3

    if-ge v3, v4, :cond_0

    add-int/lit8 v4, v3, 0x1

    aget-byte v4, p0, v4

    shr-int/lit8 v4, v4, 0x7

    and-int/lit8 v4, v4, 0x1

    int-to-byte v4, v4

    or-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, v0, v3

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    aget-byte v1, v0, v4

    aget-byte p0, p0, v2

    shr-int/lit8 p0, p0, 0x7

    and-int/lit16 p0, p0, 0x87

    int-to-byte p0, p0

    xor-int/2addr p0, v1

    int-to-byte p0, p0

    aput-byte p0, v0, v4

    return-object v0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "value must be a block."

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static j([BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 2

    invoke-static {p0, p1, p2}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p1

    iget v0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-ltz v0, :cond_2

    array-length v1, p0

    sub-int/2addr v1, p1

    if-gt v0, v1, :cond_1

    if-nez v0, :cond_0

    sget-object p0, Lcom/google/crypto/tink/shaded/protobuf/j;->l:Lcom/google/crypto/tink/shaded/protobuf/i;

    iput-object p0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    return p1

    :cond_0
    invoke-static {p0, p1, v0}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    move-result-object p0

    iput-object p0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    add-int/2addr p1, v0

    return p1

    :cond_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->g()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0

    :cond_2
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->e()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0
.end method

.method public static k(I[B)I
    .locals 2

    aget-byte v0, p1, p0

    and-int/lit16 v0, v0, 0xff

    add-int/lit8 v1, p0, 0x1

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    add-int/lit8 v1, p0, 0x2

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    add-int/lit8 p0, p0, 0x3

    aget-byte p0, p1, p0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p0, p0, 0x18

    or-int/2addr p0, v0

    return p0
.end method

.method public static l(I[B)J
    .locals 7

    aget-byte v0, p1, p0

    int-to-long v0, v0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    add-int/lit8 v4, p0, 0x1

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x8

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 v4, p0, 0x2

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x10

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 v4, p0, 0x3

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x18

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 v4, p0, 0x4

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x20

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 v4, p0, 0x5

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x28

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 v4, p0, 0x6

    aget-byte v4, p1, v4

    int-to-long v4, v4

    and-long/2addr v4, v2

    const/16 v6, 0x30

    shl-long/2addr v4, v6

    or-long/2addr v0, v4

    add-int/lit8 p0, p0, 0x7

    aget-byte p0, p1, p0

    int-to-long p0, p0

    and-long/2addr p0, v2

    const/16 v2, 0x38

    shl-long/2addr p0, v2

    or-long/2addr p0, v0

    return-wide p0
.end method

.method public static m(Lcom/google/crypto/tink/shaded/protobuf/e1;I[BIILcom/google/crypto/tink/shaded/protobuf/c0;Lcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 7

    invoke-interface {p0}, Lcom/google/crypto/tink/shaded/protobuf/e1;->i()Ljava/lang/Object;

    move-result-object v0

    move-object v1, p0

    move-object v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p6

    invoke-static/range {v0 .. v5}, Lb4/a;->E(Ljava/lang/Object;Lcom/google/crypto/tink/shaded/protobuf/e1;[BIILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p0

    invoke-interface {v1, v0}, Lcom/google/crypto/tink/shaded/protobuf/e1;->d(Ljava/lang/Object;)V

    iput-object v0, v5, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    invoke-interface {p5, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    if-ge p0, v4, :cond_1

    move-object v6, v5

    move v5, v4

    invoke-static {v2, p0, v6}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result v4

    iget p2, v6, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-eq p1, p2, :cond_0

    goto :goto_1

    :cond_0
    move-object v3, v2

    move-object v2, v1

    invoke-interface {v2}, Lcom/google/crypto/tink/shaded/protobuf/e1;->i()Ljava/lang/Object;

    move-result-object v1

    invoke-static/range {v1 .. v6}, Lb4/a;->E(Ljava/lang/Object;Lcom/google/crypto/tink/shaded/protobuf/e1;[BIILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p0

    move-object p2, v1

    move-object v1, v2

    move-object v2, v3

    move v4, v5

    move-object v5, v6

    invoke-interface {v1, p2}, Lcom/google/crypto/tink/shaded/protobuf/e1;->d(Ljava/lang/Object;)V

    iput-object p2, v5, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    invoke-interface {p5, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    :goto_1
    return p0
.end method

.method public static n([BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 3

    invoke-static {p0, p1, p2}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p1

    iget v0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-ltz v0, :cond_1

    if-nez v0, :cond_0

    const-string p0, ""

    iput-object p0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    return p1

    :cond_0
    new-instance v1, Ljava/lang/String;

    sget-object v2, Lcom/google/crypto/tink/shaded/protobuf/d0;->a:Ljava/nio/charset/Charset;

    invoke-direct {v1, p0, p1, v0, v2}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    iput-object v1, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    add-int/2addr p1, v0

    return p1

    :cond_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->e()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0
.end method

.method public static o([BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 2

    invoke-static {p0, p1, p2}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p1

    iget v0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-ltz v0, :cond_1

    if-nez v0, :cond_0

    const-string p0, ""

    iput-object p0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    return p1

    :cond_0
    sget-object v1, Lcom/google/crypto/tink/shaded/protobuf/t1;->a:Ll3/e;

    invoke-virtual {v1, p0, p1, v0}, Ll3/e;->p([BII)Ljava/lang/String;

    move-result-object p0

    iput-object p0, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->c:Ljava/lang/Object;

    add-int/2addr p1, v0

    return p1

    :cond_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->e()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0
.end method

.method public static p(I[BIILcom/google/crypto/tink/shaded/protobuf/h1;Lcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 7

    ushr-int/lit8 v0, p0, 0x3

    if-eqz v0, :cond_b

    and-int/lit8 v0, p0, 0x7

    if-eqz v0, :cond_a

    const/4 v1, 0x1

    if-eq v0, v1, :cond_9

    const/4 v1, 0x2

    if-eq v0, v1, :cond_5

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    const/4 p3, 0x5

    if-ne v0, p3, :cond_0

    invoke-static {p2, p1}, Lb4/a;->k(I[B)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    add-int/lit8 p2, p2, 0x4

    return p2

    :cond_0
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->a()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0

    :cond_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/h1;->c()Lcom/google/crypto/tink/shaded/protobuf/h1;

    move-result-object v4

    and-int/lit8 v0, p0, -0x8

    or-int/lit8 v6, v0, 0x4

    const/4 v0, 0x0

    :goto_0
    if-ge p2, p3, :cond_2

    invoke-static {p1, p2, p5}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result v2

    iget v0, p5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-ne v0, v6, :cond_3

    move p2, v2

    :cond_2
    move v3, p3

    goto :goto_1

    :cond_3
    move-object v1, p1

    move v3, p3

    move-object v5, p5

    invoke-static/range {v0 .. v5}, Lb4/a;->p(I[BIILcom/google/crypto/tink/shaded/protobuf/h1;Lcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p2

    goto :goto_0

    :goto_1
    if-gt p2, v3, :cond_4

    if-ne v0, v6, :cond_4

    invoke-virtual {p4, p0, v4}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    return p2

    :cond_4
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->f()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0

    :cond_5
    move-object v1, p1

    move-object v5, p5

    invoke-static {v1, p2, v5}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p1

    iget p2, v5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-ltz p2, :cond_8

    array-length p3, v1

    sub-int/2addr p3, p1

    if-gt p2, p3, :cond_7

    if-nez p2, :cond_6

    sget-object p3, Lcom/google/crypto/tink/shaded/protobuf/j;->l:Lcom/google/crypto/tink/shaded/protobuf/i;

    invoke-virtual {p4, p0, p3}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    goto :goto_2

    :cond_6
    invoke-static {v1, p1, p2}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    move-result-object p3

    invoke-virtual {p4, p0, p3}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    :goto_2
    add-int/2addr p1, p2

    return p1

    :cond_7
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->g()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0

    :cond_8
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->e()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0

    :cond_9
    move-object v1, p1

    invoke-static {p2, v1}, Lb4/a;->l(I[B)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    add-int/lit8 p2, p2, 0x8

    return p2

    :cond_a
    move-object v1, p1

    move-object v5, p5

    invoke-static {v1, p2, v5}, Lb4/a;->t([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p1

    iget-wide p2, v5, Lcom/google/crypto/tink/shaded/protobuf/d;->b:J

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {p4, p0, p2}, Lcom/google/crypto/tink/shaded/protobuf/h1;->d(ILjava/lang/Object;)V

    return p1

    :cond_b
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/f0;->a()Lcom/google/crypto/tink/shaded/protobuf/f0;

    move-result-object p0

    throw p0
.end method

.method public static q(I[BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 2

    and-int/lit8 p0, p0, 0x7f

    add-int/lit8 v0, p2, 0x1

    aget-byte v1, p1, p2

    if-ltz v1, :cond_0

    shl-int/lit8 p1, v1, 0x7

    or-int/2addr p0, p1

    iput p0, p3, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return v0

    :cond_0
    and-int/lit8 v1, v1, 0x7f

    shl-int/lit8 v1, v1, 0x7

    or-int/2addr p0, v1

    add-int/lit8 v1, p2, 0x2

    aget-byte v0, p1, v0

    if-ltz v0, :cond_1

    shl-int/lit8 p1, v0, 0xe

    or-int/2addr p0, p1

    iput p0, p3, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return v1

    :cond_1
    and-int/lit8 v0, v0, 0x7f

    shl-int/lit8 v0, v0, 0xe

    or-int/2addr p0, v0

    add-int/lit8 v0, p2, 0x3

    aget-byte v1, p1, v1

    if-ltz v1, :cond_2

    shl-int/lit8 p1, v1, 0x15

    or-int/2addr p0, p1

    iput p0, p3, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return v0

    :cond_2
    and-int/lit8 v1, v1, 0x7f

    shl-int/lit8 v1, v1, 0x15

    or-int/2addr p0, v1

    add-int/lit8 p2, p2, 0x4

    aget-byte v0, p1, v0

    if-ltz v0, :cond_3

    shl-int/lit8 p1, v0, 0x1c

    or-int/2addr p0, p1

    iput p0, p3, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return p2

    :cond_3
    and-int/lit8 v0, v0, 0x7f

    shl-int/lit8 v0, v0, 0x1c

    or-int/2addr p0, v0

    :goto_0
    add-int/lit8 v0, p2, 0x1

    aget-byte p2, p1, p2

    if-gez p2, :cond_4

    move p2, v0

    goto :goto_0

    :cond_4
    iput p0, p3, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return v0
.end method

.method public static r([BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 1

    add-int/lit8 v0, p1, 0x1

    aget-byte p1, p0, p1

    if-ltz p1, :cond_0

    iput p1, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    return v0

    :cond_0
    invoke-static {p1, p0, v0, p2}, Lb4/a;->q(I[BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p0

    return p0
.end method

.method public static s(I[BIILcom/google/crypto/tink/shaded/protobuf/c0;Lcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 2

    check-cast p4, Lcom/google/crypto/tink/shaded/protobuf/a0;

    invoke-static {p1, p2, p5}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p2

    iget v0, p5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    invoke-virtual {p4, v0}, Lcom/google/crypto/tink/shaded/protobuf/a0;->g(I)V

    :goto_0
    if-ge p2, p3, :cond_1

    invoke-static {p1, p2, p5}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result v0

    iget v1, p5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    if-eq p0, v1, :cond_0

    goto :goto_1

    :cond_0
    invoke-static {p1, v0, p5}, Lb4/a;->r([BILcom/google/crypto/tink/shaded/protobuf/d;)I

    move-result p2

    iget v0, p5, Lcom/google/crypto/tink/shaded/protobuf/d;->a:I

    invoke-virtual {p4, v0}, Lcom/google/crypto/tink/shaded/protobuf/a0;->g(I)V

    goto :goto_0

    :cond_1
    :goto_1
    return p2
.end method

.method public static t([BILcom/google/crypto/tink/shaded/protobuf/d;)I
    .locals 9

    add-int/lit8 v0, p1, 0x1

    aget-byte v1, p0, p1

    int-to-long v1, v1

    const-wide/16 v3, 0x0

    cmp-long v3, v1, v3

    if-ltz v3, :cond_0

    iput-wide v1, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->b:J

    return v0

    :cond_0
    const-wide/16 v3, 0x7f

    and-long/2addr v1, v3

    add-int/lit8 p1, p1, 0x2

    aget-byte v0, p0, v0

    and-int/lit8 v3, v0, 0x7f

    int-to-long v3, v3

    const/4 v5, 0x7

    shl-long/2addr v3, v5

    or-long/2addr v1, v3

    move v3, v5

    :goto_0
    if-gez v0, :cond_1

    add-int/lit8 v0, p1, 0x1

    aget-byte p1, p0, p1

    add-int/2addr v3, v5

    and-int/lit8 v4, p1, 0x7f

    int-to-long v6, v4

    shl-long/2addr v6, v3

    or-long/2addr v1, v6

    move v8, v0

    move v0, p1

    move p1, v8

    goto :goto_0

    :cond_1
    iput-wide v1, p2, Lcom/google/crypto/tink/shaded/protobuf/d;->b:J

    return p1
.end method

.method public static u()Z
    .locals 3

    :try_start_0
    const-string v0, "RamBench"

    const/4 v1, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    move-result-object v0

    :goto_0
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    instance-of v2, v0, Ln6/e;

    if-eqz v2, :cond_0

    move-object v0, v1

    :cond_0
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    return v0
.end method

.method public static v(Ljava/lang/String;)Lo7/v;
    .locals 2

    const-string v0, "http/1.0"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Lo7/v;->l:Lo7/v;

    return-object p0

    :cond_0
    const-string v0, "http/1.1"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object p0, Lo7/v;->m:Lo7/v;

    return-object p0

    :cond_1
    const-string v0, "h2_prior_knowledge"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lo7/v;->p:Lo7/v;

    return-object p0

    :cond_2
    const-string v0, "h2"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    sget-object p0, Lo7/v;->o:Lo7/v;

    return-object p0

    :cond_3
    const-string v0, "spdy/3.1"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    sget-object p0, Lo7/v;->n:Lo7/v;

    return-object p0

    :cond_4
    const-string v0, "quic"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    sget-object p0, Lo7/v;->q:Lo7/v;

    return-object p0

    :cond_5
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Unexpected protocol: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static w(Ljava/util/List;Ljava/io/InputStream;Lv4/f;)I
    .locals 4

    const/4 v0, -0x1

    if-nez p1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1}, Ljava/io/InputStream;->markSupported()Z

    move-result v1

    if-nez v1, :cond_1

    new-instance v1, Lb5/y;

    invoke-direct {v1, p1, p2}, Lb5/y;-><init>(Ljava/io/InputStream;Lv4/f;)V

    move-object p1, v1

    :cond_1
    const/high16 v1, 0x500000

    invoke-virtual {p1, v1}, Ljava/io/InputStream;->mark(I)V

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_3

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ls4/d;

    :try_start_0
    invoke-interface {v3, p1, p2}, Ls4/d;->c(Ljava/io/InputStream;Lv4/f;)I

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, Ljava/io/InputStream;->reset()V

    if-eq v3, v0, :cond_2

    move v0, v3

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    invoke-virtual {p1}, Ljava/io/InputStream;->reset()V

    throw p0

    :cond_3
    :goto_1
    return v0
.end method

.method public static x(Landroid/content/Context;)Ljava/io/File;
    .locals 5

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, ".font"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "-"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    :goto_0
    const/16 v3, 0x64

    if-ge v2, v3, :cond_2

    new-instance v3, Ljava/io/File;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, p0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {v3}, Ljava/io/File;->createNewFile()Z

    move-result v4
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v4, :cond_1

    return-object v3

    :catch_0
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public static y(Ljava/util/List;Ljava/io/InputStream;Lv4/f;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;
    .locals 3

    if-nez p1, :cond_0

    sget-object p0, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    return-object p0

    :cond_0
    invoke-virtual {p1}, Ljava/io/InputStream;->markSupported()Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Lb5/y;

    invoke-direct {v0, p1, p2}, Lb5/y;-><init>(Ljava/io/InputStream;Lv4/f;)V

    move-object p1, v0

    :cond_1
    const/high16 p2, 0x500000

    invoke-virtual {p1, p2}, Ljava/io/InputStream;->mark(I)V

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p2

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p2, :cond_3

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ls4/d;

    :try_start_0
    invoke-interface {v1, p1}, Ls4/d;->d(Ljava/io/InputStream;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p1}, Ljava/io/InputStream;->reset()V

    sget-object v2, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    if-eq v1, v2, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    invoke-virtual {p1}, Ljava/io/InputStream;->reset()V

    throw p0

    :cond_3
    sget-object v1, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    :goto_1
    return-object v1
.end method

.method public static z(Ljava/util/List;Ljava/nio/ByteBuffer;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;
    .locals 5

    if-nez p1, :cond_0

    sget-object p0, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    return-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_2

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ls4/d;

    :try_start_0
    invoke-interface {v3, p1}, Ls4/d;->a(Ljava/nio/ByteBuffer;)Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object v4, Lo5/b;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object v4

    check-cast v4, Ljava/nio/ByteBuffer;

    sget-object v4, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    if-eq v3, v4, :cond_1

    return-object v3

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    sget-object v0, Lo5/b;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    throw p0

    :cond_2
    sget-object p0, Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;->UNKNOWN:Lcom/bumptech/glide/load/ImageHeaderParser$ImageType;

    return-object p0
.end method


# virtual methods
.method public abstract c(Ljava/lang/String;Ljava/util/List;)Ljava/util/List;
.end method
