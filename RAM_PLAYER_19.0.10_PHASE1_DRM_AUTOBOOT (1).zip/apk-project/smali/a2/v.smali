.class public interface abstract La2/v;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La2/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, La2/h;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, La2/h;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, La2/v;->a:La2/h;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public abstract f()V
.end method

.method public abstract n(La2/h0;)V
.end method

.method public abstract t(II)La2/p0;
.end method
