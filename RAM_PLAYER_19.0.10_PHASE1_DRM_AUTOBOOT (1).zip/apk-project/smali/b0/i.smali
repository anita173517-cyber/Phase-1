.class public Lb0/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld0/c;
.implements Lg5/b;
.implements Li7/e;
.implements Ly0/c;
.implements Lm1/w;
.implements Lr1/a1;
.implements La2/l0;


# instance fields
.field public final synthetic k:I

.field public l:I

.field public m:Ljava/lang/Object;


# direct methods
.method public constructor <init>(IB)V
    .locals 0

    iput p1, p0, Lb0/i;->k:I

    packed-switch p1, :pswitch_data_0

    .line 3
    sget-object p1, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    const/16 p1, 0x64

    .line 6
    iput p1, p0, Lb0/i;->l:I

    return-void

    .line 7
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance p1, Ly0/w;

    const/16 p2, 0x8

    invoke-direct {p1, p2}, Ly0/w;-><init>(I)V

    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    return-void

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(II)V
    .locals 0

    iput p2, p0, Lb0/i;->k:I

    packed-switch p2, :pswitch_data_0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-lez p1, :cond_0

    .line 16
    new-array p1, p1, [Ljava/lang/Object;

    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    return-void

    .line 17
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "The max pool size must be > 0"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 18
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    new-array p1, p1, [J

    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_0
    .end packed-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;I)V
    .locals 0

    .line 1
    iput p3, p0, Lb0/i;->k:I

    iput p1, p0, Lb0/i;->l:I

    iput-object p2, p0, Lb0/i;->m:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;II)V
    .locals 0

    .line 2
    iput p3, p0, Lb0/i;->k:I

    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    iput p2, p0, Lb0/i;->l:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/ArrayList;)V
    .locals 1

    const/16 v0, 0x9

    iput v0, p0, Lb0/i;->k:I

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb0/i;->m:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(ZZZ)V
    .locals 1

    const/4 v0, 0x6

    iput v0, p0, Lb0/i;->k:I

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_1

    if-nez p2, :cond_1

    if-eqz p3, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 22
    :goto_1
    iput p1, p0, Lb0/i;->l:I

    return-void
.end method

.method public constructor <init>([II)V
    .locals 1

    const/16 v0, 0xa

    iput v0, p0, Lb0/i;->k:I

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    iput p2, p0, Lb0/i;->l:I

    .line 11
    sget-object p2, Lv5/a;->m:Lv5/a;

    if-eqz p1, :cond_1

    .line 12
    array-length v0, p1

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p2, Lv5/a;

    array-length v0, p1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    .line 13
    array-length v0, p1

    invoke-direct {p2, p1, v0}, Lv5/a;-><init>([II)V

    .line 14
    :cond_1
    :goto_0
    iput-object p2, p0, Lb0/i;->m:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public I(Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    .locals 0

    .line 1
    invoke-virtual {p3, p1}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureSupported(Ljava/lang/String;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public L()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public a(Lv0/n0;)Lcom/google/common/util/concurrent/r;
    .locals 2

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ly0/c;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Ly0/c;->a(Lv0/n0;)Lcom/google/common/util/concurrent/r;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return-object p1

    .line 13
    :cond_0
    new-instance v0, Ld1/c0;

    .line 14
    .line 15
    const/16 v1, 0x1a

    .line 16
    .line 17
    invoke-direct {v0, v1, p0}, Ld1/c0;-><init>(ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    sget-object v1, Lcom/google/common/util/concurrent/h;->k:Lcom/google/common/util/concurrent/h;

    .line 21
    .line 22
    invoke-static {p1, v0, v1}, Landroid/support/v4/media/session/b;->c0(Lcom/google/common/util/concurrent/r;Lq5/j;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/f;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    return-object p1
.end method

.method public synthetic b()I
    .locals 1

    .line 1
    const/4 v0, 0x0

    return v0
.end method

.method public c()V
    .locals 1

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp1/r;

    .line 4
    .line 5
    iget-object v0, v0, Lp1/r;->v:Lb5/x;

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    throw v0
.end method

.method public d(J)V
    .locals 3

    .line 1
    iget v0, p0, Lb0/i;->l:I

    .line 2
    .line 3
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, [J

    .line 6
    .line 7
    array-length v2, v1

    .line 8
    if-ne v0, v2, :cond_0

    .line 9
    .line 10
    mul-int/lit8 v0, v0, 0x2

    .line 11
    .line 12
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 17
    .line 18
    :cond_0
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, [J

    .line 21
    .line 22
    iget v1, p0, Lb0/i;->l:I

    .line 23
    .line 24
    add-int/lit8 v2, v1, 0x1

    .line 25
    .line 26
    iput v2, p0, Lb0/i;->l:I

    .line 27
    .line 28
    aput-wide p1, v0, v1

    .line 29
    .line 30
    return-void
.end method

.method public e(Ljava/lang/Object;)Z
    .locals 6

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Ljava/lang/Object;

    .line 4
    .line 5
    const-string v1, "instance"

    .line 6
    .line 7
    invoke-static {p1, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iget v1, p0, Lb0/i;->l:I

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    move v3, v2

    .line 14
    :goto_0
    const/4 v4, 0x1

    .line 15
    if-ge v3, v1, :cond_1

    .line 16
    .line 17
    aget-object v5, v0, v3

    .line 18
    .line 19
    if-ne v5, p1, :cond_0

    .line 20
    .line 21
    move v1, v4

    .line 22
    goto :goto_1

    .line 23
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    move v1, v2

    .line 27
    :goto_1
    if-nez v1, :cond_3

    .line 28
    .line 29
    iget v1, p0, Lb0/i;->l:I

    .line 30
    .line 31
    array-length v3, v0

    .line 32
    if-ge v1, v3, :cond_2

    .line 33
    .line 34
    aput-object p1, v0, v1

    .line 35
    .line 36
    add-int/2addr v1, v4

    .line 37
    iput v1, p0, Lb0/i;->l:I

    .line 38
    .line 39
    return v4

    .line 40
    :cond_2
    return v2

    .line 41
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 42
    .line 43
    const-string v0, "Already in the pool!"

    .line 44
    .line 45
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw p1
.end method

.method public f()Z
    .locals 3

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp1/r;

    .line 4
    .line 5
    iget v1, p0, Lb0/i;->l:I

    .line 6
    .line 7
    iget-boolean v2, v0, Lp1/r;->A:Z

    .line 8
    .line 9
    if-nez v2, :cond_0

    .line 10
    .line 11
    iget-object v0, v0, Lp1/r;->o:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lp1/q;

    .line 18
    .line 19
    iget-object v1, v0, Lp1/q;->c:Lr1/z0;

    .line 20
    .line 21
    iget-boolean v0, v0, Lp1/q;->d:Z

    .line 22
    .line 23
    invoke-virtual {v1, v0}, Lr1/z0;->A(Z)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    const/4 v0, 0x1

    .line 30
    return v0

    .line 31
    :cond_0
    const/4 v0, 0x0

    .line 32
    return v0
.end method

.method public g(I)Landroid/media/MediaCodecInfo;
    .locals 2

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Landroid/media/MediaCodecInfo;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Landroid/media/MediaCodecList;

    .line 8
    .line 9
    iget v1, p0, Lb0/i;->l:I

    .line 10
    .line 11
    invoke-direct {v0, v1}, Landroid/media/MediaCodecList;-><init>(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/media/MediaCodecList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 19
    .line 20
    :cond_0
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, [Landroid/media/MediaCodecInfo;

    .line 23
    .line 24
    aget-object p1, v0, p1

    .line 25
    .line 26
    return-object p1
.end method

.method public h([J)V
    .locals 5

    .line 1
    iget v0, p0, Lb0/i;->l:I

    .line 2
    .line 3
    array-length v1, p1

    .line 4
    add-int/2addr v0, v1

    .line 5
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, [J

    .line 8
    .line 9
    array-length v2, v1

    .line 10
    if-le v0, v2, :cond_0

    .line 11
    .line 12
    array-length v2, v1

    .line 13
    mul-int/lit8 v2, v2, 0x2

    .line 14
    .line 15
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iput-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 24
    .line 25
    :cond_0
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v1, [J

    .line 28
    .line 29
    iget v2, p0, Lb0/i;->l:I

    .line 30
    .line 31
    array-length v3, p1

    .line 32
    const/4 v4, 0x0

    .line 33
    invoke-static {p1, v4, v1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 34
    .line 35
    .line 36
    iput v0, p0, Lb0/i;->l:I

    .line 37
    .line 38
    return-void
.end method

.method public i(ILd1/r1;)Lh3/g0;
    .locals 5

    .line 1
    iget-object v0, p2, Ld1/r1;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    const-string v1, "video/mp2t"

    .line 6
    .line 7
    const/4 v2, 0x2

    .line 8
    if-eq p1, v2, :cond_e

    .line 9
    .line 10
    const/4 v3, 0x3

    .line 11
    if-eq p1, v3, :cond_d

    .line 12
    .line 13
    const/4 v3, 0x4

    .line 14
    if-eq p1, v3, :cond_d

    .line 15
    .line 16
    const/16 v4, 0x15

    .line 17
    .line 18
    if-eq p1, v4, :cond_c

    .line 19
    .line 20
    const/16 v4, 0x1b

    .line 21
    .line 22
    if-eq p1, v4, :cond_a

    .line 23
    .line 24
    const/16 v3, 0x24

    .line 25
    .line 26
    if-eq p1, v3, :cond_9

    .line 27
    .line 28
    const/16 v3, 0x2d

    .line 29
    .line 30
    if-eq p1, v3, :cond_8

    .line 31
    .line 32
    const/16 v3, 0x59

    .line 33
    .line 34
    if-eq p1, v3, :cond_7

    .line 35
    .line 36
    const/16 v3, 0xac

    .line 37
    .line 38
    if-eq p1, v3, :cond_6

    .line 39
    .line 40
    const/16 v3, 0x101

    .line 41
    .line 42
    if-eq p1, v3, :cond_5

    .line 43
    .line 44
    const/16 v3, 0x8a

    .line 45
    .line 46
    if-eq p1, v3, :cond_4

    .line 47
    .line 48
    const/16 v3, 0x8b

    .line 49
    .line 50
    if-eq p1, v3, :cond_3

    .line 51
    .line 52
    packed-switch p1, :pswitch_data_0

    .line 53
    .line 54
    .line 55
    packed-switch p1, :pswitch_data_1

    .line 56
    .line 57
    .line 58
    packed-switch p1, :pswitch_data_2

    .line 59
    .line 60
    .line 61
    goto/16 :goto_0

    .line 62
    .line 63
    :pswitch_0
    const/16 p1, 0x10

    .line 64
    .line 65
    invoke-virtual {p0, p1}, Lb0/i;->u(I)Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-eqz p1, :cond_0

    .line 70
    .line 71
    goto/16 :goto_0

    .line 72
    .line 73
    :cond_0
    new-instance p1, Lh3/b0;

    .line 74
    .line 75
    new-instance p2, Ll4/m;

    .line 76
    .line 77
    const-string v0, "application/x-scte35"

    .line 78
    .line 79
    invoke-direct {p2, v0}, Ll4/m;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-direct {p1, p2}, Lh3/b0;-><init>(Lh3/a0;)V

    .line 83
    .line 84
    .line 85
    return-object p1

    .line 86
    :pswitch_1
    const/16 p1, 0x40

    .line 87
    .line 88
    invoke-virtual {p0, p1}, Lb0/i;->u(I)Z

    .line 89
    .line 90
    .line 91
    move-result p1

    .line 92
    if-nez p1, :cond_4

    .line 93
    .line 94
    goto/16 :goto_0

    .line 95
    .line 96
    :pswitch_2
    new-instance p1, Lh3/w;

    .line 97
    .line 98
    new-instance v2, Lh3/b;

    .line 99
    .line 100
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 101
    .line 102
    .line 103
    move-result p2

    .line 104
    const/4 v3, 0x0

    .line 105
    invoke-direct {v2, p2, v3, v0, v1}, Lh3/b;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 106
    .line 107
    .line 108
    invoke-direct {p1, v2}, Lh3/w;-><init>(Lh3/h;)V

    .line 109
    .line 110
    .line 111
    return-object p1

    .line 112
    :pswitch_3
    invoke-virtual {p0, v2}, Lb0/i;->u(I)Z

    .line 113
    .line 114
    .line 115
    move-result p1

    .line 116
    if-eqz p1, :cond_1

    .line 117
    .line 118
    goto/16 :goto_0

    .line 119
    .line 120
    :cond_1
    new-instance p1, Lh3/w;

    .line 121
    .line 122
    new-instance v1, Lh3/s;

    .line 123
    .line 124
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 125
    .line 126
    .line 127
    move-result p2

    .line 128
    invoke-direct {v1, v0, p2}, Lh3/s;-><init>(Ljava/lang/String;I)V

    .line 129
    .line 130
    .line 131
    invoke-direct {p1, v1}, Lh3/w;-><init>(Lh3/h;)V

    .line 132
    .line 133
    .line 134
    return-object p1

    .line 135
    :pswitch_4
    new-instance p1, Lh3/w;

    .line 136
    .line 137
    new-instance v0, Lh3/m;

    .line 138
    .line 139
    new-instance v1, Ll4/m;

    .line 140
    .line 141
    invoke-virtual {p0, p2}, Lb0/i;->m(Ld1/r1;)Ljava/util/List;

    .line 142
    .line 143
    .line 144
    move-result-object p2

    .line 145
    invoke-direct {v1, p2}, Ll4/m;-><init>(Ljava/util/List;)V

    .line 146
    .line 147
    .line 148
    invoke-direct {v0, v1}, Lh3/m;-><init>(Ll4/m;)V

    .line 149
    .line 150
    .line 151
    invoke-direct {p1, v0}, Lh3/w;-><init>(Lh3/h;)V

    .line 152
    .line 153
    .line 154
    return-object p1

    .line 155
    :pswitch_5
    invoke-virtual {p0, v2}, Lb0/i;->u(I)Z

    .line 156
    .line 157
    .line 158
    move-result p1

    .line 159
    if-eqz p1, :cond_2

    .line 160
    .line 161
    goto/16 :goto_0

    .line 162
    .line 163
    :cond_2
    new-instance p1, Lh3/w;

    .line 164
    .line 165
    new-instance v2, Lh3/e;

    .line 166
    .line 167
    const/4 v3, 0x0

    .line 168
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 169
    .line 170
    .line 171
    move-result p2

    .line 172
    invoke-direct {v2, p2, v0, v1, v3}, Lh3/e;-><init>(ILjava/lang/String;Ljava/lang/String;Z)V

    .line 173
    .line 174
    .line 175
    invoke-direct {p1, v2}, Lh3/w;-><init>(Lh3/h;)V

    .line 176
    .line 177
    .line 178
    return-object p1

    .line 179
    :cond_3
    new-instance p1, Lh3/w;

    .line 180
    .line 181
    new-instance v1, Lh3/f;

    .line 182
    .line 183
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 184
    .line 185
    .line 186
    move-result p2

    .line 187
    const/16 v2, 0x1520

    .line 188
    .line 189
    invoke-direct {v1, p2, v2, v0}, Lh3/f;-><init>(IILjava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-direct {p1, v1}, Lh3/w;-><init>(Lh3/h;)V

    .line 193
    .line 194
    .line 195
    return-object p1

    .line 196
    :cond_4
    :pswitch_6
    new-instance p1, Lh3/w;

    .line 197
    .line 198
    new-instance v1, Lh3/f;

    .line 199
    .line 200
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 201
    .line 202
    .line 203
    move-result p2

    .line 204
    const/16 v2, 0x1000

    .line 205
    .line 206
    invoke-direct {v1, p2, v2, v0}, Lh3/f;-><init>(IILjava/lang/String;)V

    .line 207
    .line 208
    .line 209
    invoke-direct {p1, v1}, Lh3/w;-><init>(Lh3/h;)V

    .line 210
    .line 211
    .line 212
    return-object p1

    .line 213
    :cond_5
    new-instance p1, Lh3/b0;

    .line 214
    .line 215
    new-instance p2, Ll4/m;

    .line 216
    .line 217
    const-string v0, "application/vnd.dvb.ait"

    .line 218
    .line 219
    invoke-direct {p2, v0}, Ll4/m;-><init>(Ljava/lang/String;)V

    .line 220
    .line 221
    .line 222
    invoke-direct {p1, p2}, Lh3/b0;-><init>(Lh3/a0;)V

    .line 223
    .line 224
    .line 225
    return-object p1

    .line 226
    :cond_6
    new-instance p1, Lh3/w;

    .line 227
    .line 228
    new-instance v2, Lh3/b;

    .line 229
    .line 230
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 231
    .line 232
    .line 233
    move-result p2

    .line 234
    const/4 v3, 0x1

    .line 235
    invoke-direct {v2, p2, v3, v0, v1}, Lh3/b;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    invoke-direct {p1, v2}, Lh3/w;-><init>(Lh3/h;)V

    .line 239
    .line 240
    .line 241
    return-object p1

    .line 242
    :cond_7
    new-instance p1, Lh3/w;

    .line 243
    .line 244
    new-instance v0, Lh3/g;

    .line 245
    .line 246
    iget-object p2, p2, Ld1/r1;->m:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast p2, Ljava/util/List;

    .line 249
    .line 250
    invoke-direct {v0, p2}, Lh3/g;-><init>(Ljava/util/List;)V

    .line 251
    .line 252
    .line 253
    invoke-direct {p1, v0}, Lh3/w;-><init>(Lh3/h;)V

    .line 254
    .line 255
    .line 256
    return-object p1

    .line 257
    :cond_8
    new-instance p1, Lh3/w;

    .line 258
    .line 259
    new-instance p2, Lh3/u;

    .line 260
    .line 261
    invoke-direct {p2}, Lh3/u;-><init>()V

    .line 262
    .line 263
    .line 264
    invoke-direct {p1, p2}, Lh3/w;-><init>(Lh3/h;)V

    .line 265
    .line 266
    .line 267
    return-object p1

    .line 268
    :cond_9
    new-instance p1, Lh3/w;

    .line 269
    .line 270
    new-instance v0, Lh3/r;

    .line 271
    .line 272
    new-instance v1, Ll4/t;

    .line 273
    .line 274
    invoke-virtual {p0, p2}, Lb0/i;->m(Ld1/r1;)Ljava/util/List;

    .line 275
    .line 276
    .line 277
    move-result-object p2

    .line 278
    invoke-direct {v1, p2}, Ll4/t;-><init>(Ljava/util/List;)V

    .line 279
    .line 280
    .line 281
    invoke-direct {v0, v1}, Lh3/r;-><init>(Ll4/t;)V

    .line 282
    .line 283
    .line 284
    invoke-direct {p1, v0}, Lh3/w;-><init>(Lh3/h;)V

    .line 285
    .line 286
    .line 287
    return-object p1

    .line 288
    :cond_a
    invoke-virtual {p0, v3}, Lb0/i;->u(I)Z

    .line 289
    .line 290
    .line 291
    move-result p1

    .line 292
    if-eqz p1, :cond_b

    .line 293
    .line 294
    :goto_0
    const/4 p1, 0x0

    .line 295
    return-object p1

    .line 296
    :cond_b
    new-instance p1, Lh3/w;

    .line 297
    .line 298
    new-instance v0, Lh3/p;

    .line 299
    .line 300
    new-instance v1, Ll4/t;

    .line 301
    .line 302
    invoke-virtual {p0, p2}, Lb0/i;->m(Ld1/r1;)Ljava/util/List;

    .line 303
    .line 304
    .line 305
    move-result-object p2

    .line 306
    invoke-direct {v1, p2}, Ll4/t;-><init>(Ljava/util/List;)V

    .line 307
    .line 308
    .line 309
    const/4 p2, 0x1

    .line 310
    invoke-virtual {p0, p2}, Lb0/i;->u(I)Z

    .line 311
    .line 312
    .line 313
    move-result p2

    .line 314
    const/16 v2, 0x8

    .line 315
    .line 316
    invoke-virtual {p0, v2}, Lb0/i;->u(I)Z

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    invoke-direct {v0, v1, p2, v2}, Lh3/p;-><init>(Ll4/t;ZZ)V

    .line 321
    .line 322
    .line 323
    invoke-direct {p1, v0}, Lh3/w;-><init>(Lh3/h;)V

    .line 324
    .line 325
    .line 326
    return-object p1

    .line 327
    :cond_c
    new-instance p1, Lh3/w;

    .line 328
    .line 329
    new-instance p2, Lh3/g;

    .line 330
    .line 331
    invoke-direct {p2}, Lh3/g;-><init>()V

    .line 332
    .line 333
    .line 334
    invoke-direct {p1, p2}, Lh3/w;-><init>(Lh3/h;)V

    .line 335
    .line 336
    .line 337
    return-object p1

    .line 338
    :cond_d
    new-instance p1, Lh3/w;

    .line 339
    .line 340
    new-instance v2, Lh3/t;

    .line 341
    .line 342
    invoke-virtual {p2}, Ld1/r1;->b()I

    .line 343
    .line 344
    .line 345
    move-result p2

    .line 346
    invoke-direct {v2, p2, v0, v1}, Lh3/t;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    invoke-direct {p1, v2}, Lh3/w;-><init>(Lh3/h;)V

    .line 350
    .line 351
    .line 352
    return-object p1

    .line 353
    :cond_e
    :pswitch_7
    new-instance p1, Lh3/w;

    .line 354
    .line 355
    new-instance v0, Lh3/j;

    .line 356
    .line 357
    new-instance v2, Ll4/m;

    .line 358
    .line 359
    invoke-virtual {p0, p2}, Lb0/i;->m(Ld1/r1;)Ljava/util/List;

    .line 360
    .line 361
    .line 362
    move-result-object p2

    .line 363
    invoke-direct {v2, p2}, Ll4/m;-><init>(Ljava/util/List;)V

    .line 364
    .line 365
    .line 366
    invoke-direct {v0, v2, v1}, Lh3/j;-><init>(Ll4/m;Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    invoke-direct {p1, v0}, Lh3/w;-><init>(Lh3/h;)V

    .line 370
    .line 371
    .line 372
    return-object p1

    .line 373
    :pswitch_data_0
    .packed-switch 0xf
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    :pswitch_data_1
    .packed-switch 0x80
        :pswitch_7
        :pswitch_2
        :pswitch_1
    .end packed-switch

    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    :pswitch_data_2
    .packed-switch 0x86
        :pswitch_0
        :pswitch_2
        :pswitch_6
    .end packed-switch
.end method

.method public j(Lu4/y;Ls4/h;)Lu4/y;
    .locals 3

    .line 1
    new-instance p2, Ljava/io/ByteArrayOutputStream;

    .line 2
    .line 3
    invoke-direct {p2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lu4/y;->get()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Landroid/graphics/Bitmap;

    .line 11
    .line 12
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Landroid/graphics/Bitmap$CompressFormat;

    .line 15
    .line 16
    iget v2, p0, Lb0/i;->l:I

    .line 17
    .line 18
    invoke-virtual {v0, v1, v2, p2}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 19
    .line 20
    .line 21
    invoke-interface {p1}, Lu4/y;->e()V

    .line 22
    .line 23
    .line 24
    new-instance p1, Lb5/b0;

    .line 25
    .line 26
    invoke-virtual {p2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 27
    .line 28
    .line 29
    move-result-object p2

    .line 30
    invoke-direct {p1, p2}, Lb5/b0;-><init>([B)V

    .line 31
    .line 32
    .line 33
    return-object p1
.end method

.method public k(Ljava/lang/Object;Lt6/c;)Ljava/lang/Object;
    .locals 7

    .line 1
    instance-of v0, p2, Lj7/b;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lj7/b;

    .line 7
    .line 8
    iget v1, v0, Lj7/b;->p:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lj7/b;->p:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lj7/b;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lj7/b;-><init>(Lb0/i;Lt6/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, Lj7/b;->n:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lj7/b;->p:I

    .line 28
    .line 29
    sget-object v2, Ls6/a;->k:Ls6/a;

    .line 30
    .line 31
    sget-object v3, Ln6/j;->a:Ln6/j;

    .line 32
    .line 33
    const/4 v4, 0x2

    .line 34
    const/4 v5, 0x1

    .line 35
    if-eqz v1, :cond_3

    .line 36
    .line 37
    if-eq v1, v5, :cond_2

    .line 38
    .line 39
    if-ne v1, v4, :cond_1

    .line 40
    .line 41
    invoke-static {p2}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    return-object v3

    .line 45
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 46
    .line 47
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 48
    .line 49
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p1

    .line 53
    :cond_2
    invoke-static {p2}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :cond_3
    invoke-static {p2}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iget-object p2, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast p2, Lh7/e;

    .line 63
    .line 64
    new-instance v1, Lo6/u;

    .line 65
    .line 66
    iget v6, p0, Lb0/i;->l:I

    .line 67
    .line 68
    invoke-direct {v1, v6, p1}, Lo6/u;-><init>(ILjava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    iput v5, v0, Lj7/b;->p:I

    .line 72
    .line 73
    invoke-interface {p2, v1, v0}, Lh7/v;->b(Lo6/u;Lj7/b;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-ne p1, v2, :cond_4

    .line 78
    .line 79
    goto :goto_6

    .line 80
    :cond_4
    :goto_1
    iput v4, v0, Lj7/b;->p:I

    .line 81
    .line 82
    iget-object p1, v0, Lt6/c;->l:Lr6/i;

    .line 83
    .line 84
    invoke-static {p1}, La7/h;->b(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    invoke-static {p1}, Lf7/v;->c(Lr6/i;)V

    .line 88
    .line 89
    .line 90
    invoke-static {v0}, Lc4/b0;->t(Lr6/d;)Lr6/d;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    instance-of v0, p2, Lk7/h;

    .line 95
    .line 96
    if-eqz v0, :cond_5

    .line 97
    .line 98
    check-cast p2, Lk7/h;

    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_5
    const/4 p2, 0x0

    .line 102
    :goto_2
    if-nez p2, :cond_6

    .line 103
    .line 104
    move-object p1, v3

    .line 105
    goto :goto_4

    .line 106
    :cond_6
    iget-object v0, p2, Lk7/h;->n:Lf7/q;

    .line 107
    .line 108
    invoke-virtual {v0}, Lf7/q;->D()Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_7

    .line 113
    .line 114
    iput-object v3, p2, Lk7/h;->p:Ljava/lang/Object;

    .line 115
    .line 116
    iput v5, p2, Lf7/a0;->m:I

    .line 117
    .line 118
    invoke-virtual {v0, p1, p2}, Lf7/q;->C(Lr6/i;Ljava/lang/Runnable;)V

    .line 119
    .line 120
    .line 121
    goto :goto_3

    .line 122
    :cond_7
    new-instance v1, Lf7/o1;

    .line 123
    .line 124
    sget-object v4, Lf7/o1;->l:Lf7/r;

    .line 125
    .line 126
    invoke-direct {v1, v4}, Lr6/a;-><init>(Lr6/h;)V

    .line 127
    .line 128
    .line 129
    invoke-interface {p1, v1}, Lr6/i;->n(Lr6/i;)Lr6/i;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    iput-object v3, p2, Lk7/h;->p:Ljava/lang/Object;

    .line 134
    .line 135
    iput v5, p2, Lf7/a0;->m:I

    .line 136
    .line 137
    invoke-virtual {v0, p1, p2}, Lf7/q;->C(Lr6/i;Ljava/lang/Runnable;)V

    .line 138
    .line 139
    .line 140
    :goto_3
    move-object p1, v2

    .line 141
    :goto_4
    if-ne p1, v2, :cond_8

    .line 142
    .line 143
    goto :goto_5

    .line 144
    :cond_8
    move-object p1, v3

    .line 145
    :goto_5
    if-ne p1, v2, :cond_9

    .line 146
    .line 147
    :goto_6
    return-object v2

    .line 148
    :cond_9
    return-object v3
.end method

.method public l(I)J
    .locals 3

    .line 1
    if-ltz p1, :cond_0

    .line 2
    .line 3
    iget v0, p0, Lb0/i;->l:I

    .line 4
    .line 5
    if-ge p1, v0, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, [J

    .line 10
    .line 11
    aget-wide v1, v0, p1

    .line 12
    .line 13
    return-wide v1

    .line 14
    :cond_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 15
    .line 16
    const-string v1, "Invalid index "

    .line 17
    .line 18
    const-string v2, ", size is "

    .line 19
    .line 20
    invoke-static {p1, v1, v2}, Lq3/e;->g(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iget v1, p0, Lb0/i;->l:I

    .line 25
    .line 26
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v0
.end method

.method public m(Ld1/r1;)Ljava/util/List;
    .locals 11

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    const/16 v1, 0x20

    .line 6
    .line 7
    invoke-virtual {p0, v1}, Lb0/i;->u(I)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_0
    new-instance v1, Ly0/w;

    .line 15
    .line 16
    iget-object p1, p1, Ld1/r1;->n:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p1, [B

    .line 19
    .line 20
    invoke-direct {v1, p1}, Ly0/w;-><init>([B)V

    .line 21
    .line 22
    .line 23
    :goto_0
    invoke-virtual {v1}, Ly0/w;->a()I

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-lez p1, :cond_8

    .line 28
    .line 29
    invoke-virtual {v1}, Ly0/w;->A()I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    invoke-virtual {v1}, Ly0/w;->A()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    iget v3, v1, Ly0/w;->b:I

    .line 38
    .line 39
    add-int/2addr v3, v2

    .line 40
    const/16 v2, 0x86

    .line 41
    .line 42
    if-ne p1, v2, :cond_7

    .line 43
    .line 44
    new-instance p1, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1}, Ly0/w;->A()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    and-int/lit8 v0, v0, 0x1f

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    move v4, v2

    .line 57
    :goto_1
    if-ge v4, v0, :cond_6

    .line 58
    .line 59
    const/4 v5, 0x3

    .line 60
    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 61
    .line 62
    invoke-virtual {v1, v5, v6}, Ly0/w;->y(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    invoke-virtual {v1}, Ly0/w;->A()I

    .line 67
    .line 68
    .line 69
    move-result v6

    .line 70
    and-int/lit16 v7, v6, 0x80

    .line 71
    .line 72
    const/4 v8, 0x1

    .line 73
    if-eqz v7, :cond_1

    .line 74
    .line 75
    move v7, v8

    .line 76
    goto :goto_2

    .line 77
    :cond_1
    move v7, v2

    .line 78
    :goto_2
    if-eqz v7, :cond_2

    .line 79
    .line 80
    and-int/lit8 v6, v6, 0x3f

    .line 81
    .line 82
    const-string v9, "application/cea-708"

    .line 83
    .line 84
    goto :goto_3

    .line 85
    :cond_2
    const-string v9, "application/cea-608"

    .line 86
    .line 87
    move v6, v8

    .line 88
    :goto_3
    invoke-virtual {v1}, Ly0/w;->A()I

    .line 89
    .line 90
    .line 91
    move-result v10

    .line 92
    int-to-byte v10, v10

    .line 93
    invoke-virtual {v1, v8}, Ly0/w;->O(I)V

    .line 94
    .line 95
    .line 96
    if-eqz v7, :cond_5

    .line 97
    .line 98
    and-int/lit8 v7, v10, 0x40

    .line 99
    .line 100
    if-eqz v7, :cond_3

    .line 101
    .line 102
    move v7, v8

    .line 103
    goto :goto_4

    .line 104
    :cond_3
    move v7, v2

    .line 105
    :goto_4
    sget-object v10, Ly0/f;->a:[B

    .line 106
    .line 107
    if-eqz v7, :cond_4

    .line 108
    .line 109
    new-array v7, v8, [B

    .line 110
    .line 111
    aput-byte v8, v7, v2

    .line 112
    .line 113
    goto :goto_5

    .line 114
    :cond_4
    new-array v7, v8, [B

    .line 115
    .line 116
    aput-byte v2, v7, v2

    .line 117
    .line 118
    :goto_5
    invoke-static {v7}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    goto :goto_6

    .line 123
    :cond_5
    const/4 v7, 0x0

    .line 124
    :goto_6
    new-instance v8, Lv0/s;

    .line 125
    .line 126
    invoke-direct {v8}, Lv0/s;-><init>()V

    .line 127
    .line 128
    .line 129
    invoke-static {v9}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v9

    .line 133
    iput-object v9, v8, Lv0/s;->o:Ljava/lang/String;

    .line 134
    .line 135
    iput-object v5, v8, Lv0/s;->d:Ljava/lang/String;

    .line 136
    .line 137
    iput v6, v8, Lv0/s;->O:I

    .line 138
    .line 139
    iput-object v7, v8, Lv0/s;->r:Ljava/util/List;

    .line 140
    .line 141
    new-instance v5, Lv0/t;

    .line 142
    .line 143
    invoke-direct {v5, v8}, Lv0/t;-><init>(Lv0/s;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 147
    .line 148
    .line 149
    add-int/lit8 v4, v4, 0x1

    .line 150
    .line 151
    goto :goto_1

    .line 152
    :cond_6
    move-object v0, p1

    .line 153
    :cond_7
    invoke-virtual {v1, v3}, Ly0/w;->N(I)V

    .line 154
    .line 155
    .line 156
    goto/16 :goto_0

    .line 157
    .line 158
    :cond_8
    return-object v0
.end method

.method public n(Ll4/c;Lc1/h;I)I
    .locals 3

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp1/r;

    .line 4
    .line 5
    iget v1, p0, Lb0/i;->l:I

    .line 6
    .line 7
    iget-boolean v2, v0, Lp1/r;->A:Z

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    const/4 p1, -0x3

    .line 12
    return p1

    .line 13
    :cond_0
    iget-object v0, v0, Lp1/r;->o:Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lp1/q;

    .line 20
    .line 21
    iget-object v1, v0, Lp1/q;->c:Lr1/z0;

    .line 22
    .line 23
    iget-boolean v0, v0, Lp1/q;->d:Z

    .line 24
    .line 25
    invoke-virtual {v1, p1, p2, p3, v0}, Lr1/z0;->F(Ll4/c;Lc1/h;IZ)I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    return p1
.end method

.method public o()Z
    .locals 2

    .line 1
    iget v0, p0, Lb0/i;->l:I

    .line 2
    .line 3
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-ge v0, v1, :cond_0

    .line 12
    .line 13
    const/4 v0, 0x1

    .line 14
    return v0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    return v0
.end method

.method public p()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Ljava/lang/Object;

    .line 4
    .line 5
    iget v1, p0, Lb0/i;->l:I

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-lez v1, :cond_0

    .line 9
    .line 10
    add-int/lit8 v1, v1, -0x1

    .line 11
    .line 12
    aget-object v3, v0, v1

    .line 13
    .line 14
    const-string v4, "null cannot be cast to non-null type T of androidx.core.util.Pools.SimplePool"

    .line 15
    .line 16
    invoke-static {v3, v4}, La7/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    aput-object v2, v0, v1

    .line 20
    .line 21
    iget v0, p0, Lb0/i;->l:I

    .line 22
    .line 23
    add-int/lit8 v0, v0, -0x1

    .line 24
    .line 25
    iput v0, p0, Lb0/i;->l:I

    .line 26
    .line 27
    return-object v3

    .line 28
    :cond_0
    return-object v2
.end method

.method public q([B)Lcom/google/common/util/concurrent/r;
    .locals 2

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ly0/c;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Ly0/c;->q([B)Lcom/google/common/util/concurrent/r;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    new-instance v0, Ld1/c0;

    .line 10
    .line 11
    const/16 v1, 0x1a

    .line 12
    .line 13
    invoke-direct {v0, v1, p0}, Ld1/c0;-><init>(ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sget-object v1, Lcom/google/common/util/concurrent/h;->k:Lcom/google/common/util/concurrent/h;

    .line 17
    .line 18
    invoke-static {p1, v0, v1}, Landroid/support/v4/media/session/b;->c0(Lcom/google/common/util/concurrent/r;Lq5/j;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/f;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1
.end method

.method public r(J)I
    .locals 3

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp1/r;

    .line 4
    .line 5
    iget v1, p0, Lb0/i;->l:I

    .line 6
    .line 7
    iget-boolean v2, v0, Lp1/r;->A:Z

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    const/4 p1, -0x3

    .line 12
    return p1

    .line 13
    :cond_0
    iget-object v0, v0, Lp1/r;->o:Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lp1/q;

    .line 20
    .line 21
    iget-object v1, v0, Lp1/q;->c:Lr1/z0;

    .line 22
    .line 23
    iget-boolean v0, v0, Lp1/q;->d:Z

    .line 24
    .line 25
    invoke-virtual {v1, p1, p2, v0}, Lr1/z0;->x(JZ)I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    invoke-virtual {v1, p1}, Lr1/z0;->M(I)V

    .line 30
    .line 31
    .line 32
    return p1
.end method

.method public s(Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    .locals 0

    .line 1
    invoke-virtual {p2, p1}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFeatureRequired(Ljava/lang/String;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    return p1
.end method

.method public t()I
    .locals 2

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Landroid/media/MediaCodecInfo;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    new-instance v0, Landroid/media/MediaCodecList;

    .line 8
    .line 9
    iget v1, p0, Lb0/i;->l:I

    .line 10
    .line 11
    invoke-direct {v0, v1}, Landroid/media/MediaCodecList;-><init>(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/media/MediaCodecList;->getCodecInfos()[Landroid/media/MediaCodecInfo;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iput-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 19
    .line 20
    :cond_0
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, [Landroid/media/MediaCodecInfo;

    .line 23
    .line 24
    array-length v0, v0

    .line 25
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    .line 1
    iget v0, p0, Lb0/i;->k:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    iget-object v1, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lv5/a;

    .line 16
    .line 17
    iget v2, v1, Lv5/a;->l:I

    .line 18
    .line 19
    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 20
    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    :goto_0
    iget v3, v1, Lv5/a;->l:I

    .line 24
    .line 25
    if-ge v2, v3, :cond_0

    .line 26
    .line 27
    invoke-virtual {v1, v2}, Lv5/a;->b(I)I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    invoke-static {v3}, Ly0/k0;->j0(I)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    add-int/lit8 v2, v2, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    const-string v2, "UnsupportedBrands{major="

    .line 44
    .line 45
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget v2, p0, Lb0/i;->l:I

    .line 49
    .line 50
    invoke-static {v2}, Ly0/k0;->j0(I)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v2, ", compatible="

    .line 58
    .line 59
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    const-string v0, "}"

    .line 66
    .line 67
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    return-object v0

    .line 75
    :pswitch_data_0
    .packed-switch 0xa
        :pswitch_0
    .end packed-switch
.end method

.method public u(I)Z
    .locals 1

    .line 1
    iget v0, p0, Lb0/i;->l:I

    .line 2
    .line 3
    and-int/2addr p1, v0

    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    return p1

    .line 8
    :cond_0
    const/4 p1, 0x0

    .line 9
    return p1
.end method

.method public v(La2/o;)J
    .locals 7

    .line 1
    iget-object v0, p0, Lb0/i;->m:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ly0/w;

    .line 4
    .line 5
    iget-object v1, v0, Ly0/w;->a:[B

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    invoke-virtual {p1, v1, v2, v3, v2}, La2/o;->y([BIIZ)Z

    .line 10
    .line 11
    .line 12
    iget-object v1, v0, Ly0/w;->a:[B

    .line 13
    .line 14
    aget-byte v1, v1, v2

    .line 15
    .line 16
    and-int/lit16 v1, v1, 0xff

    .line 17
    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    const-wide/high16 v0, -0x8000000000000000L

    .line 21
    .line 22
    return-wide v0

    .line 23
    :cond_0
    const/16 v4, 0x80

    .line 24
    .line 25
    move v5, v2

    .line 26
    :goto_0
    and-int v6, v1, v4

    .line 27
    .line 28
    if-nez v6, :cond_1

    .line 29
    .line 30
    shr-int/lit8 v4, v4, 0x1

    .line 31
    .line 32
    add-int/lit8 v5, v5, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    not-int v4, v4

    .line 36
    and-int/2addr v1, v4

    .line 37
    iget-object v4, v0, Ly0/w;->a:[B

    .line 38
    .line 39
    invoke-virtual {p1, v4, v3, v5, v2}, La2/o;->y([BIIZ)Z

    .line 40
    .line 41
    .line 42
    :goto_1
    if-ge v2, v5, :cond_2

    .line 43
    .line 44
    shl-int/lit8 p1, v1, 0x8

    .line 45
    .line 46
    iget-object v1, v0, Ly0/w;->a:[B

    .line 47
    .line 48
    add-int/lit8 v2, v2, 0x1

    .line 49
    .line 50
    aget-byte v1, v1, v2

    .line 51
    .line 52
    and-int/lit16 v1, v1, 0xff

    .line 53
    .line 54
    add-int/2addr v1, p1

    .line 55
    goto :goto_1

    .line 56
    :cond_2
    iget p1, p0, Lb0/i;->l:I

    .line 57
    .line 58
    add-int/2addr v5, v3

    .line 59
    add-int/2addr v5, p1

    .line 60
    iput v5, p0, Lb0/i;->l:I

    .line 61
    .line 62
    int-to-long v0, v1

    .line 63
    return-wide v0
.end method
