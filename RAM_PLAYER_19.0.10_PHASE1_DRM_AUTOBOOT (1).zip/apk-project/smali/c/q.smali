.class public final Lc/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/a;


# instance fields
.field public final k:Lr0/k;

.field public final synthetic l:Lc/r;


# direct methods
.method public constructor <init>(Lc/r;Lr0/k;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "onBackPressedCallback"

    .line 5
    .line 6
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lc/q;->l:Lc/r;

    .line 10
    .line 11
    iput-object p2, p0, Lc/q;->k:Lr0/k;

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final cancel()V
    .locals 4

    .line 1
    iget-object v0, p0, Lc/q;->l:Lc/r;

    .line 2
    .line 3
    iget-object v1, v0, Lc/r;->b:Lo6/h;

    .line 4
    .line 5
    iget-object v2, p0, Lc/q;->k:Lr0/k;

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Lo6/h;->remove(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    iget-object v1, v2, Lr0/k;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 11
    .line 12
    invoke-virtual {v1, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 16
    .line 17
    const/16 v3, 0x21

    .line 18
    .line 19
    if-lt v1, v3, :cond_0

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    iput-object v1, v2, Lr0/k;->c:Lz6/a;

    .line 23
    .line 24
    invoke-virtual {v0}, Lc/r;->b()V

    .line 25
    .line 26
    .line 27
    :cond_0
    return-void
.end method
