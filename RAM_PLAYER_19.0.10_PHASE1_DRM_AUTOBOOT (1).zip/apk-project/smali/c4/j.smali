.class public final Lc4/j;
.super La7/i;
.source "SourceFile"

# interfaces
.implements Lz6/l;


# instance fields
.field public final synthetic l:I

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lc4/j;->l:I

    iput-object p2, p0, Lc4/j;->m:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, La7/i;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, Lc4/j;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/Throwable;

    .line 7
    .line 8
    iget-object p1, p0, Lc4/j;->m:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p1, Ln7/h;

    .line 11
    .line 12
    invoke-virtual {p1}, Ln7/h;->b()V

    .line 13
    .line 14
    .line 15
    sget-object p1, Ln6/j;->a:Ln6/j;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_0
    check-cast p1, Ljava/lang/Throwable;

    .line 19
    .line 20
    iget-object p1, p0, Lc4/j;->m:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p1, Lf7/f;

    .line 23
    .line 24
    sget-object v0, Ln6/j;->a:Ln6/j;

    .line 25
    .line 26
    invoke-virtual {p1, v0}, Lf7/f;->h(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_1
    check-cast p1, Ljava/lang/Throwable;

    .line 31
    .line 32
    iget-object v0, p0, Lc4/j;->m:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Lc4/k;

    .line 35
    .line 36
    if-nez p1, :cond_1

    .line 37
    .line 38
    iget-object p1, v0, Lc4/k;->k:Ln4/k;

    .line 39
    .line 40
    invoke-virtual {p1}, Ln4/i;->isDone()Z

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    if-eqz p1, :cond_0

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 48
    .line 49
    const-string v0, "Failed requirement."

    .line 50
    .line 51
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw p1

    .line 55
    :cond_1
    instance-of v1, p1, Ljava/util/concurrent/CancellationException;

    .line 56
    .line 57
    if-eqz v1, :cond_2

    .line 58
    .line 59
    iget-object p1, v0, Lc4/k;->k:Ln4/k;

    .line 60
    .line 61
    const/4 v0, 0x1

    .line 62
    invoke-virtual {p1, v0}, Ln4/i;->cancel(Z)Z

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_2
    iget-object v0, v0, Lc4/k;->k:Ln4/k;

    .line 67
    .line 68
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    if-nez v1, :cond_3

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    move-object p1, v1

    .line 76
    :goto_0
    invoke-virtual {v0, p1}, Ln4/k;->j(Ljava/lang/Throwable;)Z

    .line 77
    .line 78
    .line 79
    :goto_1
    sget-object p1, Ln6/j;->a:Ln6/j;

    .line 80
    .line 81
    return-object p1

    .line 82
    nop

    .line 83
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
