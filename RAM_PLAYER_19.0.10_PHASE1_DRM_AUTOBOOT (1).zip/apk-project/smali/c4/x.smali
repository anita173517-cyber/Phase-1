.class public interface abstract Lc4/x;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Lc4/w;

.field public static final c:Lc4/v;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lc4/w;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lc4/x;->b:Lc4/w;

    .line 7
    .line 8
    new-instance v0, Lc4/v;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, Lc4/x;->c:Lc4/v;

    .line 14
    .line 15
    return-void
.end method
