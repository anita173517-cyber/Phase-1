.class public final Landroid/support/v4/media/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Landroid/support/v4/media/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget v2, v1, Landroid/support/v4/media/a;->a:I

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const-string v4, "android.support.v4.media.description.MEDIA_URI"

    .line 9
    .line 10
    const-string v5, "android.support.v4.media.description.NULL_BUNDLE_FLAG"

    .line 11
    .line 12
    const/4 v6, 0x1

    .line 13
    const/4 v7, 0x0

    .line 14
    const/4 v8, 0x0

    .line 15
    packed-switch v2, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    new-instance v2, Lr0/r;

    .line 19
    .line 20
    invoke-direct {v2, v0}, Lr0/r;-><init>(Landroid/os/Parcel;)V

    .line 21
    .line 22
    .line 23
    return-object v2

    .line 24
    :pswitch_0
    new-instance v2, Lr0/p;

    .line 25
    .line 26
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object v8, v2, Lr0/p;->o:Ljava/lang/String;

    .line 30
    .line 31
    new-instance v3, Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 34
    .line 35
    .line 36
    iput-object v3, v2, Lr0/p;->p:Ljava/util/ArrayList;

    .line 37
    .line 38
    new-instance v3, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object v3, v2, Lr0/p;->q:Ljava/util/ArrayList;

    .line 44
    .line 45
    invoke-virtual {v0}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    iput-object v3, v2, Lr0/p;->k:Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-virtual {v0}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    iput-object v3, v2, Lr0/p;->l:Ljava/util/ArrayList;

    .line 56
    .line 57
    sget-object v3, Lr0/b;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 58
    .line 59
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    check-cast v3, [Lr0/b;

    .line 64
    .line 65
    iput-object v3, v2, Lr0/p;->m:[Lr0/b;

    .line 66
    .line 67
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    iput v3, v2, Lr0/p;->n:I

    .line 72
    .line 73
    invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    iput-object v3, v2, Lr0/p;->o:Ljava/lang/String;

    .line 78
    .line 79
    invoke-virtual {v0}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    iput-object v3, v2, Lr0/p;->p:Ljava/util/ArrayList;

    .line 84
    .line 85
    sget-object v3, Lr0/c;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 86
    .line 87
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    iput-object v3, v2, Lr0/p;->q:Ljava/util/ArrayList;

    .line 92
    .line 93
    sget-object v3, Lr0/n;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 94
    .line 95
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    iput-object v0, v2, Lr0/p;->r:Ljava/util/ArrayList;

    .line 100
    .line 101
    return-object v2

    .line 102
    :pswitch_1
    new-instance v2, Lr0/n;

    .line 103
    .line 104
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    iput-object v3, v2, Lr0/n;->k:Ljava/lang/String;

    .line 112
    .line 113
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 114
    .line 115
    .line 116
    move-result v0

    .line 117
    iput v0, v2, Lr0/n;->l:I

    .line 118
    .line 119
    return-object v2

    .line 120
    :pswitch_2
    new-instance v2, Lr0/c;

    .line 121
    .line 122
    invoke-direct {v2, v0}, Lr0/c;-><init>(Landroid/os/Parcel;)V

    .line 123
    .line 124
    .line 125
    return-object v2

    .line 126
    :pswitch_3
    new-instance v2, Lr0/b;

    .line 127
    .line 128
    invoke-direct {v2, v0}, Lr0/b;-><init>(Landroid/os/Parcel;)V

    .line 129
    .line 130
    .line 131
    return-object v2

    .line 132
    :pswitch_4
    new-instance v2, Lp3/e1;

    .line 133
    .line 134
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    iput v3, v2, Lp3/e1;->k:I

    .line 142
    .line 143
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    iput v3, v2, Lp3/e1;->l:I

    .line 148
    .line 149
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 150
    .line 151
    .line 152
    move-result v3

    .line 153
    iput v3, v2, Lp3/e1;->m:I

    .line 154
    .line 155
    if-lez v3, :cond_0

    .line 156
    .line 157
    new-array v3, v3, [I

    .line 158
    .line 159
    iput-object v3, v2, Lp3/e1;->n:[I

    .line 160
    .line 161
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->readIntArray([I)V

    .line 162
    .line 163
    .line 164
    :cond_0
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 165
    .line 166
    .line 167
    move-result v3

    .line 168
    iput v3, v2, Lp3/e1;->o:I

    .line 169
    .line 170
    if-lez v3, :cond_1

    .line 171
    .line 172
    new-array v3, v3, [I

    .line 173
    .line 174
    iput-object v3, v2, Lp3/e1;->p:[I

    .line 175
    .line 176
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->readIntArray([I)V

    .line 177
    .line 178
    .line 179
    :cond_1
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 180
    .line 181
    .line 182
    move-result v3

    .line 183
    if-ne v3, v6, :cond_2

    .line 184
    .line 185
    move v3, v6

    .line 186
    goto :goto_0

    .line 187
    :cond_2
    move v3, v7

    .line 188
    :goto_0
    iput-boolean v3, v2, Lp3/e1;->r:Z

    .line 189
    .line 190
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 191
    .line 192
    .line 193
    move-result v3

    .line 194
    if-ne v3, v6, :cond_3

    .line 195
    .line 196
    move v3, v6

    .line 197
    goto :goto_1

    .line 198
    :cond_3
    move v3, v7

    .line 199
    :goto_1
    iput-boolean v3, v2, Lp3/e1;->s:Z

    .line 200
    .line 201
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 202
    .line 203
    .line 204
    move-result v3

    .line 205
    if-ne v3, v6, :cond_4

    .line 206
    .line 207
    goto :goto_2

    .line 208
    :cond_4
    move v6, v7

    .line 209
    :goto_2
    iput-boolean v6, v2, Lp3/e1;->t:Z

    .line 210
    .line 211
    const-class v3, Lp3/d1;

    .line 212
    .line 213
    invoke-virtual {v3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 214
    .line 215
    .line 216
    move-result-object v3

    .line 217
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->readArrayList(Ljava/lang/ClassLoader;)Ljava/util/ArrayList;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    iput-object v0, v2, Lp3/e1;->q:Ljava/util/ArrayList;

    .line 222
    .line 223
    return-object v2

    .line 224
    :pswitch_5
    new-instance v2, Lp3/d1;

    .line 225
    .line 226
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 230
    .line 231
    .line 232
    move-result v3

    .line 233
    iput v3, v2, Lp3/d1;->k:I

    .line 234
    .line 235
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 236
    .line 237
    .line 238
    move-result v3

    .line 239
    iput v3, v2, Lp3/d1;->l:I

    .line 240
    .line 241
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 242
    .line 243
    .line 244
    move-result v3

    .line 245
    if-ne v3, v6, :cond_5

    .line 246
    .line 247
    goto :goto_3

    .line 248
    :cond_5
    move v6, v7

    .line 249
    :goto_3
    iput-boolean v6, v2, Lp3/d1;->n:Z

    .line 250
    .line 251
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 252
    .line 253
    .line 254
    move-result v3

    .line 255
    if-lez v3, :cond_6

    .line 256
    .line 257
    new-array v3, v3, [I

    .line 258
    .line 259
    iput-object v3, v2, Lp3/d1;->m:[I

    .line 260
    .line 261
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->readIntArray([I)V

    .line 262
    .line 263
    .line 264
    :cond_6
    return-object v2

    .line 265
    :pswitch_6
    new-instance v2, Lp3/z;

    .line 266
    .line 267
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 271
    .line 272
    .line 273
    move-result v3

    .line 274
    iput v3, v2, Lp3/z;->k:I

    .line 275
    .line 276
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 277
    .line 278
    .line 279
    move-result v3

    .line 280
    iput v3, v2, Lp3/z;->l:I

    .line 281
    .line 282
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 283
    .line 284
    .line 285
    move-result v0

    .line 286
    if-ne v0, v6, :cond_7

    .line 287
    .line 288
    goto :goto_4

    .line 289
    :cond_7
    move v6, v7

    .line 290
    :goto_4
    iput-boolean v6, v2, Lp3/z;->m:Z

    .line 291
    .line 292
    return-object v2

    .line 293
    :pswitch_7
    new-instance v2, Lo/p0;

    .line 294
    .line 295
    invoke-direct {v2, v0}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v0}, Landroid/os/Parcel;->readByte()B

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    if-eqz v0, :cond_8

    .line 303
    .line 304
    goto :goto_5

    .line 305
    :cond_8
    move v6, v7

    .line 306
    :goto_5
    iput-boolean v6, v2, Lo/p0;->k:Z

    .line 307
    .line 308
    return-object v2

    .line 309
    :pswitch_8
    new-instance v2, Ll3/p0;

    .line 310
    .line 311
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 312
    .line 313
    .line 314
    move-result v3

    .line 315
    invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F

    .line 316
    .line 317
    .line 318
    move-result v0

    .line 319
    invoke-direct {v2, v3, v0}, Ll3/p0;-><init>(IF)V

    .line 320
    .line 321
    .line 322
    return-object v2

    .line 323
    :pswitch_9
    new-instance v2, Ll3/n0;

    .line 324
    .line 325
    invoke-direct {v2, v0}, Ll3/n0;-><init>(Landroid/os/Parcel;)V

    .line 326
    .line 327
    .line 328
    return-object v2

    .line 329
    :pswitch_a
    new-instance v2, Ll3/o0;

    .line 330
    .line 331
    invoke-direct {v2, v0}, Ll3/o0;-><init>(Landroid/os/Parcel;)V

    .line 332
    .line 333
    .line 334
    return-object v2

    .line 335
    :pswitch_b
    invoke-virtual {v0, v8}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    check-cast v0, Landroid/media/session/MediaSession$Token;

    .line 340
    .line 341
    new-instance v2, Ll3/h0;

    .line 342
    .line 343
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 344
    .line 345
    .line 346
    invoke-direct {v2, v0, v8}, Ll3/h0;-><init>(Landroid/media/session/MediaSession$Token;Ll3/d;)V

    .line 347
    .line 348
    .line 349
    return-object v2

    .line 350
    :pswitch_c
    new-instance v2, Ll3/g0;

    .line 351
    .line 352
    invoke-direct {v2, v0}, Ll3/g0;-><init>(Landroid/os/Parcel;)V

    .line 353
    .line 354
    .line 355
    return-object v2

    .line 356
    :pswitch_d
    new-instance v2, Ll3/x;

    .line 357
    .line 358
    invoke-direct {v2, v0}, Ll3/x;-><init>(Landroid/os/Parcel;)V

    .line 359
    .line 360
    .line 361
    return-object v2

    .line 362
    :pswitch_e
    sget-object v2, Landroid/media/MediaDescription;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 363
    .line 364
    invoke-interface {v2, v0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v0

    .line 368
    move-object v2, v0

    .line 369
    check-cast v2, Landroid/media/MediaDescription;

    .line 370
    .line 371
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getMediaId()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v10

    .line 375
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getTitle()Ljava/lang/CharSequence;

    .line 376
    .line 377
    .line 378
    move-result-object v11

    .line 379
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getSubtitle()Ljava/lang/CharSequence;

    .line 380
    .line 381
    .line 382
    move-result-object v12

    .line 383
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getDescription()Ljava/lang/CharSequence;

    .line 384
    .line 385
    .line 386
    move-result-object v13

    .line 387
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getIconBitmap()Landroid/graphics/Bitmap;

    .line 388
    .line 389
    .line 390
    move-result-object v14

    .line 391
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getIconUri()Landroid/net/Uri;

    .line 392
    .line 393
    .line 394
    move-result-object v15

    .line 395
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getExtras()Landroid/os/Bundle;

    .line 396
    .line 397
    .line 398
    move-result-object v0

    .line 399
    invoke-static {v0}, Ly0/k0;->n(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 400
    .line 401
    .line 402
    move-result-object v0

    .line 403
    if-eqz v0, :cond_b

    .line 404
    .line 405
    :try_start_0
    new-instance v6, Landroid/os/Bundle;

    .line 406
    .line 407
    invoke-direct {v6, v0}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    .line 408
    .line 409
    .line 410
    invoke-virtual {v6, v4}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 411
    .line 412
    .line 413
    move-result-object v0

    .line 414
    check-cast v0, Landroid/net/Uri;

    .line 415
    .line 416
    if-eqz v0, :cond_a

    .line 417
    .line 418
    invoke-virtual {v6, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 419
    .line 420
    .line 421
    move-result v7

    .line 422
    if-eqz v7, :cond_9

    .line 423
    .line 424
    invoke-virtual {v6}, Landroid/os/BaseBundle;->size()I

    .line 425
    .line 426
    .line 427
    move-result v7

    .line 428
    if-ne v7, v3, :cond_9

    .line 429
    .line 430
    goto :goto_6

    .line 431
    :catch_0
    move-exception v0

    .line 432
    goto :goto_7

    .line 433
    :cond_9
    invoke-virtual {v6, v4}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v6, v5}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 437
    .line 438
    .line 439
    :cond_a
    move-object v8, v6

    .line 440
    :goto_6
    move-object/from16 v16, v8

    .line 441
    .line 442
    move-object v8, v0

    .line 443
    goto :goto_8

    .line 444
    :goto_7
    const-string v3, "MediaDescriptionCompat"

    .line 445
    .line 446
    const-string v4, "Failed to parse extras"

    .line 447
    .line 448
    invoke-static {v3, v4, v0}, Ly0/a;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 449
    .line 450
    .line 451
    move-object/from16 v16, v8

    .line 452
    .line 453
    goto :goto_8

    .line 454
    :cond_b
    move-object/from16 v16, v0

    .line 455
    .line 456
    :goto_8
    if-eqz v8, :cond_c

    .line 457
    .line 458
    :goto_9
    move-object/from16 v17, v8

    .line 459
    .line 460
    goto :goto_a

    .line 461
    :cond_c
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getMediaUri()Landroid/net/Uri;

    .line 462
    .line 463
    .line 464
    move-result-object v8

    .line 465
    goto :goto_9

    .line 466
    :goto_a
    new-instance v9, Ll3/w;

    .line 467
    .line 468
    invoke-direct/range {v9 .. v17}, Ll3/w;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/graphics/Bitmap;Landroid/net/Uri;Landroid/os/Bundle;Landroid/net/Uri;)V

    .line 469
    .line 470
    .line 471
    iput-object v2, v9, Ll3/w;->t:Landroid/media/MediaDescription;

    .line 472
    .line 473
    return-object v9

    .line 474
    :pswitch_f
    new-instance v2, Lj0/k;

    .line 475
    .line 476
    invoke-direct {v2, v0}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 477
    .line 478
    .line 479
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 480
    .line 481
    .line 482
    move-result v0

    .line 483
    iput v0, v2, Lj0/k;->k:I

    .line 484
    .line 485
    return-object v2

    .line 486
    :pswitch_10
    const-string v2, "inParcel"

    .line 487
    .line 488
    invoke-static {v0, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    new-instance v2, Le/h;

    .line 492
    .line 493
    const-class v3, Landroid/content/IntentSender;

    .line 494
    .line 495
    invoke-virtual {v3}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 496
    .line 497
    .line 498
    move-result-object v3

    .line 499
    invoke-virtual {v0, v3}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 500
    .line 501
    .line 502
    move-result-object v3

    .line 503
    invoke-static {v3}, La7/h;->b(Ljava/lang/Object;)V

    .line 504
    .line 505
    .line 506
    check-cast v3, Landroid/content/IntentSender;

    .line 507
    .line 508
    const-class v4, Landroid/content/Intent;

    .line 509
    .line 510
    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 511
    .line 512
    .line 513
    move-result-object v4

    .line 514
    invoke-virtual {v0, v4}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 515
    .line 516
    .line 517
    move-result-object v4

    .line 518
    check-cast v4, Landroid/content/Intent;

    .line 519
    .line 520
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 521
    .line 522
    .line 523
    move-result v5

    .line 524
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 525
    .line 526
    .line 527
    move-result v0

    .line 528
    invoke-direct {v2, v3, v4, v5, v0}, Le/h;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    .line 529
    .line 530
    .line 531
    return-object v2

    .line 532
    :pswitch_11
    new-instance v2, Le/a;

    .line 533
    .line 534
    invoke-direct {v2, v0}, Le/a;-><init>(Landroid/os/Parcel;)V

    .line 535
    .line 536
    .line 537
    return-object v2

    .line 538
    :pswitch_12
    new-instance v2, Landroidx/versionedparcelable/ParcelImpl;

    .line 539
    .line 540
    invoke-direct {v2, v0}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroid/os/Parcel;)V

    .line 541
    .line 542
    .line 543
    return-object v2

    .line 544
    :pswitch_13
    new-instance v2, Lb/d;

    .line 545
    .line 546
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v0}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 550
    .line 551
    .line 552
    move-result-object v0

    .line 553
    sget v3, Lb/c;->c:I

    .line 554
    .line 555
    if-nez v0, :cond_d

    .line 556
    .line 557
    goto :goto_b

    .line 558
    :cond_d
    sget-object v3, Lb/b;->a:Ljava/lang/String;

    .line 559
    .line 560
    invoke-interface {v0, v3}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 561
    .line 562
    .line 563
    move-result-object v3

    .line 564
    if-eqz v3, :cond_e

    .line 565
    .line 566
    instance-of v4, v3, Lb/b;

    .line 567
    .line 568
    if-eqz v4, :cond_e

    .line 569
    .line 570
    move-object v8, v3

    .line 571
    check-cast v8, Lb/b;

    .line 572
    .line 573
    goto :goto_b

    .line 574
    :cond_e
    new-instance v8, Lb/a;

    .line 575
    .line 576
    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    .line 577
    .line 578
    .line 579
    iput-object v0, v8, Lb/a;->b:Landroid/os/IBinder;

    .line 580
    .line 581
    :goto_b
    iput-object v8, v2, Lb/d;->k:Lb/b;

    .line 582
    .line 583
    return-object v2

    .line 584
    :pswitch_14
    new-instance v2, Landroid/support/v4/media/RatingCompat;

    .line 585
    .line 586
    invoke-virtual {v0}, Landroid/os/Parcel;->readInt()I

    .line 587
    .line 588
    .line 589
    move-result v3

    .line 590
    invoke-virtual {v0}, Landroid/os/Parcel;->readFloat()F

    .line 591
    .line 592
    .line 593
    move-result v0

    .line 594
    invoke-direct {v2, v3, v0}, Landroid/support/v4/media/RatingCompat;-><init>(IF)V

    .line 595
    .line 596
    .line 597
    return-object v2

    .line 598
    :pswitch_15
    new-instance v2, Landroid/support/v4/media/MediaMetadataCompat;

    .line 599
    .line 600
    invoke-direct {v2, v0}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Parcel;)V

    .line 601
    .line 602
    .line 603
    return-object v2

    .line 604
    :pswitch_16
    sget-object v2, Landroid/media/MediaDescription;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 605
    .line 606
    invoke-interface {v2, v0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 607
    .line 608
    .line 609
    move-result-object v0

    .line 610
    if-eqz v0, :cond_14

    .line 611
    .line 612
    check-cast v0, Landroid/media/MediaDescription;

    .line 613
    .line 614
    invoke-static {v0}, Landroid/support/v4/media/b;->g(Landroid/media/MediaDescription;)Ljava/lang/String;

    .line 615
    .line 616
    .line 617
    move-result-object v10

    .line 618
    invoke-static {v0}, Landroid/support/v4/media/b;->i(Landroid/media/MediaDescription;)Ljava/lang/CharSequence;

    .line 619
    .line 620
    .line 621
    move-result-object v11

    .line 622
    invoke-static {v0}, Landroid/support/v4/media/b;->h(Landroid/media/MediaDescription;)Ljava/lang/CharSequence;

    .line 623
    .line 624
    .line 625
    move-result-object v12

    .line 626
    invoke-static {v0}, Landroid/support/v4/media/b;->c(Landroid/media/MediaDescription;)Ljava/lang/CharSequence;

    .line 627
    .line 628
    .line 629
    move-result-object v13

    .line 630
    invoke-static {v0}, Landroid/support/v4/media/b;->e(Landroid/media/MediaDescription;)Landroid/graphics/Bitmap;

    .line 631
    .line 632
    .line 633
    move-result-object v14

    .line 634
    invoke-static {v0}, Landroid/support/v4/media/b;->f(Landroid/media/MediaDescription;)Landroid/net/Uri;

    .line 635
    .line 636
    .line 637
    move-result-object v15

    .line 638
    invoke-static {v0}, Landroid/support/v4/media/b;->d(Landroid/media/MediaDescription;)Landroid/os/Bundle;

    .line 639
    .line 640
    .line 641
    move-result-object v2

    .line 642
    if-eqz v2, :cond_f

    .line 643
    .line 644
    invoke-static {v2}, Landroid/support/v4/media/session/b;->d0(Landroid/os/Bundle;)Landroid/os/Bundle;

    .line 645
    .line 646
    .line 647
    move-result-object v2

    .line 648
    :cond_f
    if-eqz v2, :cond_10

    .line 649
    .line 650
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 651
    .line 652
    .line 653
    move-result-object v6

    .line 654
    check-cast v6, Landroid/net/Uri;

    .line 655
    .line 656
    goto :goto_c

    .line 657
    :cond_10
    move-object v6, v8

    .line 658
    :goto_c
    if-eqz v6, :cond_12

    .line 659
    .line 660
    invoke-virtual {v2, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 661
    .line 662
    .line 663
    move-result v7

    .line 664
    if-eqz v7, :cond_11

    .line 665
    .line 666
    invoke-virtual {v2}, Landroid/os/BaseBundle;->size()I

    .line 667
    .line 668
    .line 669
    move-result v7

    .line 670
    if-ne v7, v3, :cond_11

    .line 671
    .line 672
    move-object/from16 v16, v8

    .line 673
    .line 674
    goto :goto_d

    .line 675
    :cond_11
    invoke-virtual {v2, v4}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 676
    .line 677
    .line 678
    invoke-virtual {v2, v5}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 679
    .line 680
    .line 681
    :cond_12
    move-object/from16 v16, v2

    .line 682
    .line 683
    :goto_d
    if-eqz v6, :cond_13

    .line 684
    .line 685
    :goto_e
    move-object/from16 v17, v6

    .line 686
    .line 687
    goto :goto_f

    .line 688
    :cond_13
    invoke-static {v0}, Landroid/support/v4/media/c;->a(Landroid/media/MediaDescription;)Landroid/net/Uri;

    .line 689
    .line 690
    .line 691
    move-result-object v6

    .line 692
    goto :goto_e

    .line 693
    :goto_f
    new-instance v9, Landroid/support/v4/media/MediaDescriptionCompat;

    .line 694
    .line 695
    invoke-direct/range {v9 .. v17}, Landroid/support/v4/media/MediaDescriptionCompat;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/graphics/Bitmap;Landroid/net/Uri;Landroid/os/Bundle;Landroid/net/Uri;)V

    .line 696
    .line 697
    .line 698
    iput-object v0, v9, Landroid/support/v4/media/MediaDescriptionCompat;->s:Landroid/media/MediaDescription;

    .line 699
    .line 700
    move-object v8, v9

    .line 701
    :cond_14
    return-object v8

    .line 702
    :pswitch_17
    new-instance v2, Landroid/support/v4/media/MediaBrowserCompat$MediaItem;

    .line 703
    .line 704
    invoke-direct {v2, v0}, Landroid/support/v4/media/MediaBrowserCompat$MediaItem;-><init>(Landroid/os/Parcel;)V

    .line 705
    .line 706
    .line 707
    return-object v2

    .line 708
    nop

    .line 709
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Landroid/support/v4/media/a;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-array p1, p1, [Lr0/r;

    .line 7
    .line 8
    return-object p1

    .line 9
    :pswitch_0
    new-array p1, p1, [Lr0/p;

    .line 10
    .line 11
    return-object p1

    .line 12
    :pswitch_1
    new-array p1, p1, [Lr0/n;

    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_2
    new-array p1, p1, [Lr0/c;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_3
    new-array p1, p1, [Lr0/b;

    .line 19
    .line 20
    return-object p1

    .line 21
    :pswitch_4
    new-array p1, p1, [Lp3/e1;

    .line 22
    .line 23
    return-object p1

    .line 24
    :pswitch_5
    new-array p1, p1, [Lp3/d1;

    .line 25
    .line 26
    return-object p1

    .line 27
    :pswitch_6
    new-array p1, p1, [Lp3/z;

    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_7
    new-array p1, p1, [Lo/p0;

    .line 31
    .line 32
    return-object p1

    .line 33
    :pswitch_8
    new-array p1, p1, [Ll3/p0;

    .line 34
    .line 35
    return-object p1

    .line 36
    :pswitch_9
    new-array p1, p1, [Ll3/n0;

    .line 37
    .line 38
    return-object p1

    .line 39
    :pswitch_a
    new-array p1, p1, [Ll3/o0;

    .line 40
    .line 41
    return-object p1

    .line 42
    :pswitch_b
    new-array p1, p1, [Ll3/h0;

    .line 43
    .line 44
    return-object p1

    .line 45
    :pswitch_c
    new-array p1, p1, [Ll3/g0;

    .line 46
    .line 47
    return-object p1

    .line 48
    :pswitch_d
    new-array p1, p1, [Ll3/x;

    .line 49
    .line 50
    return-object p1

    .line 51
    :pswitch_e
    new-array p1, p1, [Ll3/w;

    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_f
    new-array p1, p1, [Lj0/k;

    .line 55
    .line 56
    return-object p1

    .line 57
    :pswitch_10
    new-array p1, p1, [Le/h;

    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_11
    new-array p1, p1, [Le/a;

    .line 61
    .line 62
    return-object p1

    .line 63
    :pswitch_12
    new-array p1, p1, [Landroidx/versionedparcelable/ParcelImpl;

    .line 64
    .line 65
    return-object p1

    .line 66
    :pswitch_13
    new-array p1, p1, [Lb/d;

    .line 67
    .line 68
    return-object p1

    .line 69
    :pswitch_14
    new-array p1, p1, [Landroid/support/v4/media/RatingCompat;

    .line 70
    .line 71
    return-object p1

    .line 72
    :pswitch_15
    new-array p1, p1, [Landroid/support/v4/media/MediaMetadataCompat;

    .line 73
    .line 74
    return-object p1

    .line 75
    :pswitch_16
    new-array p1, p1, [Landroid/support/v4/media/MediaDescriptionCompat;

    .line 76
    .line 77
    return-object p1

    .line 78
    :pswitch_17
    new-array p1, p1, [Landroid/support/v4/media/MediaBrowserCompat$MediaItem;

    .line 79
    .line 80
    return-object p1

    .line 81
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
