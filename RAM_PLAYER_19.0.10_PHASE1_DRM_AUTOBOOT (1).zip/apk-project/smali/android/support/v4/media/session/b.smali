.class public abstract Landroid/support/v4/media/session/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static volatile a:Z = true


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public static A([B)Ljava/lang/String;
    .locals 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    array-length v1, p0

    .line 4
    mul-int/lit8 v1, v1, 0x2

    .line 5
    .line 6
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 7
    .line 8
    .line 9
    array-length v1, p0

    .line 10
    const/4 v2, 0x0

    .line 11
    :goto_0
    if-ge v2, v1, :cond_0

    .line 12
    .line 13
    aget-byte v3, p0, v2

    .line 14
    .line 15
    and-int/lit16 v3, v3, 0xff

    .line 16
    .line 17
    div-int/lit8 v4, v3, 0x10

    .line 18
    .line 19
    const-string v5, "0123456789abcdef"

    .line 20
    .line 21
    invoke-virtual {v5, v4}, Ljava/lang/String;->charAt(I)C

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    rem-int/lit8 v3, v3, 0x10

    .line 29
    .line 30
    invoke-virtual {v5, v3}, Ljava/lang/String;->charAt(I)C

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    add-int/lit8 v2, v2, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    return-object p0
.end method

.method public static B(Z)I
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    new-instance v1, Lv0/s;

    .line 3
    .line 4
    invoke-direct {v1}, Lv0/s;-><init>()V

    .line 5
    .line 6
    .line 7
    const-string v2, "video/avc"

    .line 8
    .line 9
    invoke-static {v2}, Lv0/q0;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    iput-object v2, v1, Lv0/s;->o:Ljava/lang/String;

    .line 14
    .line 15
    new-instance v2, Lv0/t;

    .line 16
    .line 17
    invoke-direct {v2, v1}, Lv0/t;-><init>(Lv0/s;)V

    .line 18
    .line 19
    .line 20
    iget-object v1, v2, Lv0/t;->p:Ljava/lang/String;

    .line 21
    .line 22
    if-eqz v1, :cond_4

    .line 23
    .line 24
    invoke-static {v1, p0, v0}, Lm1/y;->e(Ljava/lang/String;ZZ)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-static {v2}, Lm1/y;->c(Lv0/t;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    if-nez v2, :cond_0

    .line 33
    .line 34
    sget-object p0, Lr5/v1;->o:Lr5/v1;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    invoke-static {v2, p0, v0}, Lm1/y;->e(Ljava/lang/String;ZZ)Ljava/util/List;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    :goto_0
    invoke-static {}, Lr5/l0;->n()Lr5/i0;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    invoke-virtual {v2, v1}, Lr5/f0;->d(Ljava/lang/Iterable;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v2, p0}, Lr5/f0;->d(Ljava/lang/Iterable;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v2}, Lr5/i0;->f()Lr5/v1;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    move v1, v0

    .line 56
    :goto_1
    iget v2, p0, Lr5/v1;->n:I

    .line 57
    .line 58
    if-ge v1, v2, :cond_4

    .line 59
    .line 60
    invoke-virtual {p0, v1}, Lr5/v1;->get(I)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    check-cast v2, Lm1/o;

    .line 65
    .line 66
    iget-object v2, v2, Lm1/o;->d:Landroid/media/MediaCodecInfo$CodecCapabilities;

    .line 67
    .line 68
    if-eqz v2, :cond_3

    .line 69
    .line 70
    invoke-virtual {p0, v1}, Lr5/v1;->get(I)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    check-cast v2, Lm1/o;

    .line 75
    .line 76
    iget-object v2, v2, Lm1/o;->d:Landroid/media/MediaCodecInfo$CodecCapabilities;

    .line 77
    .line 78
    invoke-virtual {v2}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getVideoCapabilities()Landroid/media/MediaCodecInfo$VideoCapabilities;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    if-eqz v2, :cond_3

    .line 83
    .line 84
    invoke-static {v2}, Landroidx/lifecycle/f0;->k(Landroid/media/MediaCodecInfo$VideoCapabilities;)Ljava/util/List;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    if-eqz v2, :cond_3

    .line 89
    .line 90
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    if-nez v3, :cond_3

    .line 95
    .line 96
    invoke-static {}, Landroidx/lifecycle/f0;->l()V

    .line 97
    .line 98
    .line 99
    invoke-static {}, Landroidx/lifecycle/f0;->b()Landroid/media/MediaCodecInfo$VideoCapabilities$PerformancePoint;

    .line 100
    .line 101
    .line 102
    move-result-object p0

    .line 103
    move v1, v0

    .line 104
    :goto_2
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 105
    .line 106
    .line 107
    move-result v3

    .line 108
    if-ge v1, v3, :cond_2

    .line 109
    .line 110
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    invoke-static {v3}, Landroidx/lifecycle/f0;->d(Ljava/lang/Object;)Landroid/media/MediaCodecInfo$VideoCapabilities$PerformancePoint;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    invoke-static {v3, p0}, Landroidx/lifecycle/f0;->v(Landroid/media/MediaCodecInfo$VideoCapabilities$PerformancePoint;Landroid/media/MediaCodecInfo$VideoCapabilities$PerformancePoint;)Z

    .line 119
    .line 120
    .line 121
    move-result v3
    :try_end_0
    .catch Lm1/v; {:try_start_0 .. :try_end_0} :catch_0

    .line 122
    if-eqz v3, :cond_1

    .line 123
    .line 124
    const/4 p0, 0x2

    .line 125
    return p0

    .line 126
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_2
    const/4 p0, 0x1

    .line 130
    return p0

    .line 131
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 132
    .line 133
    goto :goto_1

    .line 134
    :catch_0
    :cond_4
    return v0
.end method

.method public static C(La1/i;Ljava/lang/String;[BLjava/util/Map;)Li1/y;
    .locals 25

    .line 1
    new-instance v1, La1/g0;

    .line 2
    .line 3
    move-object/from16 v0, p0

    .line 4
    .line 5
    invoke-direct {v1, v0}, La1/g0;-><init>(La1/i;)V

    .line 6
    .line 7
    .line 8
    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 9
    .line 10
    invoke-static/range {p1 .. p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    const-string v13, "The uri must be set."

    .line 15
    .line 16
    invoke-static {v3, v13}, Landroid/support/v4/media/session/b;->n(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    new-instance v2, La1/q;

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    const-wide/16 v7, 0x0

    .line 23
    .line 24
    const-wide/16 v9, -0x1

    .line 25
    .line 26
    const/4 v11, 0x0

    .line 27
    const/4 v12, 0x1

    .line 28
    move-object/from16 v5, p2

    .line 29
    .line 30
    move-object/from16 v6, p3

    .line 31
    .line 32
    invoke-direct/range {v2 .. v12}, La1/q;-><init>(Landroid/net/Uri;I[BLjava/util/Map;JJLjava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    const/4 v3, 0x0

    .line 36
    move-object v10, v2

    .line 37
    move v11, v3

    .line 38
    :goto_0
    :try_start_0
    new-instance v12, La1/o;

    .line 39
    .line 40
    invoke-direct {v12, v1, v10}, La1/o;-><init>(La1/i;La1/q;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 41
    .line 42
    .line 43
    :try_start_1
    invoke-static {v12}, Ls5/g;->b(Ljava/io/InputStream;)[B

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    new-instance v4, Lr1/s;

    .line 48
    .line 49
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 50
    .line 51
    .line 52
    move-result-wide v8
    :try_end_1
    .catch La1/c0; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 53
    const-wide/16 v5, -0x1

    .line 54
    .line 55
    move-object v7, v2

    .line 56
    :try_start_2
    invoke-direct/range {v4 .. v9}, Lr1/s;-><init>(JLa1/q;J)V
    :try_end_2
    .catch La1/c0; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 57
    .line 58
    .line 59
    :try_start_3
    iget-object v5, v1, La1/g0;->m:Landroid/net/Uri;

    .line 60
    .line 61
    iput-object v5, v4, Lr1/s;->d:Landroid/net/Uri;

    .line 62
    .line 63
    iget-object v5, v1, La1/g0;->n:Ljava/util/Map;

    .line 64
    .line 65
    iput-object v5, v4, Lr1/s;->e:Ljava/util/Map;

    .line 66
    .line 67
    array-length v5, v0

    .line 68
    int-to-long v5, v5

    .line 69
    iput-wide v5, v4, Lr1/s;->g:J

    .line 70
    .line 71
    new-instance v5, Lr1/t;

    .line 72
    .line 73
    invoke-direct {v5, v4}, Lr1/t;-><init>(Lr1/s;)V

    .line 74
    .line 75
    .line 76
    new-instance v4, Ll4/l;

    .line 77
    .line 78
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 79
    .line 80
    .line 81
    iput-object v0, v4, Ll4/l;->k:Ljava/lang/Object;

    .line 82
    .line 83
    iput-object v5, v4, Ll4/l;->l:Ljava/lang/Object;

    .line 84
    .line 85
    new-instance v0, Li1/y;

    .line 86
    .line 87
    invoke-direct {v0, v4}, Li1/y;-><init>(Ll4/l;)V
    :try_end_3
    .catch La1/c0; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 88
    .line 89
    .line 90
    :try_start_4
    invoke-static {v12}, Ly0/k0;->h(Ljava/io/Closeable;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 91
    .line 92
    .line 93
    return-object v0

    .line 94
    :catch_0
    move-exception v0

    .line 95
    move-object v10, v0

    .line 96
    goto/16 :goto_3

    .line 97
    .line 98
    :catchall_0
    move-exception v0

    .line 99
    goto/16 :goto_2

    .line 100
    .line 101
    :catch_1
    move-exception v0

    .line 102
    goto :goto_1

    .line 103
    :catchall_1
    move-exception v0

    .line 104
    move-object v2, v7

    .line 105
    goto/16 :goto_2

    .line 106
    .line 107
    :catch_2
    move-exception v0

    .line 108
    move-object v2, v7

    .line 109
    :goto_1
    :try_start_5
    iget v4, v0, La1/c0;->m:I

    .line 110
    .line 111
    const/16 v5, 0x133

    .line 112
    .line 113
    const/4 v6, 0x0

    .line 114
    if-eq v4, v5, :cond_0

    .line 115
    .line 116
    const/16 v5, 0x134

    .line 117
    .line 118
    if-ne v4, v5, :cond_1

    .line 119
    .line 120
    :cond_0
    const/4 v4, 0x5

    .line 121
    if-ge v11, v4, :cond_1

    .line 122
    .line 123
    iget-object v4, v0, La1/c0;->n:Ljava/util/Map;

    .line 124
    .line 125
    if-eqz v4, :cond_1

    .line 126
    .line 127
    const-string v5, "Location"

    .line 128
    .line 129
    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v4

    .line 133
    check-cast v4, Ljava/util/List;

    .line 134
    .line 135
    if-eqz v4, :cond_1

    .line 136
    .line 137
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 138
    .line 139
    .line 140
    move-result v5

    .line 141
    if-nez v5, :cond_1

    .line 142
    .line 143
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    move-object v6, v4

    .line 148
    check-cast v6, Ljava/lang/String;

    .line 149
    .line 150
    :cond_1
    if-eqz v6, :cond_2

    .line 151
    .line 152
    add-int/lit8 v11, v11, 0x1

    .line 153
    .line 154
    invoke-virtual {v10}, La1/q;->a()La1/p;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    invoke-static {v6}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 159
    .line 160
    .line 161
    move-result-object v4

    .line 162
    iput-object v4, v0, La1/p;->e:Ljava/lang/Object;

    .line 163
    .line 164
    invoke-static {v4, v13}, Landroid/support/v4/media/session/b;->n(Ljava/lang/Object;Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    new-instance v14, La1/q;

    .line 168
    .line 169
    iget-object v4, v0, La1/p;->e:Ljava/lang/Object;

    .line 170
    .line 171
    move-object v15, v4

    .line 172
    check-cast v15, Landroid/net/Uri;

    .line 173
    .line 174
    iget v4, v0, La1/p;->a:I

    .line 175
    .line 176
    iget-object v5, v0, La1/p;->f:Ljava/lang/Object;

    .line 177
    .line 178
    move-object/from16 v17, v5

    .line 179
    .line 180
    check-cast v17, [B

    .line 181
    .line 182
    iget-object v5, v0, La1/p;->g:Ljava/lang/Object;

    .line 183
    .line 184
    move-object/from16 v18, v5

    .line 185
    .line 186
    check-cast v18, Ljava/util/Map;

    .line 187
    .line 188
    iget-wide v5, v0, La1/p;->b:J

    .line 189
    .line 190
    iget-wide v7, v0, La1/p;->d:J

    .line 191
    .line 192
    iget-object v9, v0, La1/p;->h:Ljava/lang/Object;

    .line 193
    .line 194
    move-object/from16 v23, v9

    .line 195
    .line 196
    check-cast v23, Ljava/lang/String;

    .line 197
    .line 198
    iget v0, v0, La1/p;->c:I

    .line 199
    .line 200
    move/from16 v24, v0

    .line 201
    .line 202
    move/from16 v16, v4

    .line 203
    .line 204
    move-wide/from16 v19, v5

    .line 205
    .line 206
    move-wide/from16 v21, v7

    .line 207
    .line 208
    invoke-direct/range {v14 .. v24}, La1/q;-><init>(Landroid/net/Uri;I[BLjava/util/Map;JJLjava/lang/String;I)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 209
    .line 210
    .line 211
    :try_start_6
    invoke-static {v12}, Ly0/k0;->h(Ljava/io/Closeable;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 212
    .line 213
    .line 214
    move-object v10, v14

    .line 215
    goto/16 :goto_0

    .line 216
    .line 217
    :cond_2
    :try_start_7
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 218
    :goto_2
    :try_start_8
    invoke-static {v12}, Ly0/k0;->h(Ljava/io/Closeable;)V

    .line 219
    .line 220
    .line 221
    throw v0
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 222
    :goto_3
    new-instance v4, Li1/z;

    .line 223
    .line 224
    iget-object v6, v1, La1/g0;->m:Landroid/net/Uri;

    .line 225
    .line 226
    iget-object v0, v1, La1/g0;->k:La1/i;

    .line 227
    .line 228
    invoke-interface {v0}, La1/i;->l()Ljava/util/Map;

    .line 229
    .line 230
    .line 231
    move-result-object v7

    .line 232
    iget-wide v8, v1, La1/g0;->l:J

    .line 233
    .line 234
    move-object v5, v2

    .line 235
    invoke-direct/range {v4 .. v10}, Li1/z;-><init>(La1/q;Landroid/net/Uri;Ljava/util/Map;JLjava/lang/Exception;)V

    .line 236
    .line 237
    .line 238
    throw v4
.end method

.method public static E(Ljava/lang/String;)Lo7/s;
    .locals 10

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget-object v0, Lo7/s;->b:Ljava/util/regex/Pattern;

    .line 7
    .line 8
    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->lookingAt()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/16 v2, 0x22

    .line 17
    .line 18
    if-eqz v1, :cond_5

    .line 19
    .line 20
    const/4 v1, 0x1

    .line 21
    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    const-string v4, "typeSubtype.group(1)"

    .line 26
    .line 27
    invoke-static {v3, v4}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 31
    .line 32
    const-string v5, "US"

    .line 33
    .line 34
    invoke-static {v4, v5}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v3, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    const-string v5, "this as java.lang.String).toLowerCase(locale)"

    .line 42
    .line 43
    invoke-static {v3, v5}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    const/4 v3, 0x2

    .line 47
    invoke-virtual {v0, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    const-string v7, "typeSubtype.group(2)"

    .line 52
    .line 53
    invoke-static {v6, v7}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v6, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    invoke-static {v4, v5}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    new-instance v4, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 66
    .line 67
    .line 68
    sget-object v5, Lo7/s;->c:Ljava/util/regex/Pattern;

    .line 69
    .line 70
    invoke-virtual {v5, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->end()I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 79
    .line 80
    .line 81
    move-result v6

    .line 82
    const/4 v7, 0x0

    .line 83
    if-ge v0, v6, :cond_4

    .line 84
    .line 85
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 86
    .line 87
    .line 88
    move-result v6

    .line 89
    invoke-virtual {v5, v0, v6}, Ljava/util/regex/Matcher;->region(II)Ljava/util/regex/Matcher;

    .line 90
    .line 91
    .line 92
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->lookingAt()Z

    .line 93
    .line 94
    .line 95
    move-result v6

    .line 96
    if-eqz v6, :cond_3

    .line 97
    .line 98
    invoke-virtual {v5, v1}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    if-nez v0, :cond_0

    .line 103
    .line 104
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->end()I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    goto :goto_0

    .line 109
    :cond_0
    invoke-virtual {v5, v3}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v6

    .line 113
    if-nez v6, :cond_1

    .line 114
    .line 115
    const/4 v6, 0x3

    .line 116
    invoke-virtual {v5, v6}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v6

    .line 120
    goto :goto_1

    .line 121
    :cond_1
    const-string v8, "\'"

    .line 122
    .line 123
    invoke-static {v6, v8, v7}, Le7/m;->P(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    if-eqz v9, :cond_2

    .line 128
    .line 129
    invoke-static {v6, v8, v7}, Le7/m;->J(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 130
    .line 131
    .line 132
    move-result v7

    .line 133
    if-eqz v7, :cond_2

    .line 134
    .line 135
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 136
    .line 137
    .line 138
    move-result v7

    .line 139
    if-le v7, v3, :cond_2

    .line 140
    .line 141
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 142
    .line 143
    .line 144
    move-result v7

    .line 145
    sub-int/2addr v7, v1

    .line 146
    invoke-virtual {v6, v1, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    const-string v7, "this as java.lang.String\u2026ing(startIndex, endIndex)"

    .line 151
    .line 152
    invoke-static {v6, v7}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    :cond_2
    :goto_1
    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 159
    .line 160
    .line 161
    invoke-virtual {v5}, Ljava/util/regex/Matcher;->end()I

    .line 162
    .line 163
    .line 164
    move-result v0

    .line 165
    goto :goto_0

    .line 166
    :cond_3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 167
    .line 168
    const-string v3, "Parameter is not formatted correctly: \""

    .line 169
    .line 170
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    const-string v3, "this as java.lang.String).substring(startIndex)"

    .line 178
    .line 179
    invoke-static {v0, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    const-string v0, "\" for: \""

    .line 186
    .line 187
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 194
    .line 195
    .line 196
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object p0

    .line 200
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 201
    .line 202
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object p0

    .line 206
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    throw v0

    .line 210
    :cond_4
    new-instance v0, Lo7/s;

    .line 211
    .line 212
    new-array v1, v7, [Ljava/lang/String;

    .line 213
    .line 214
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v1

    .line 218
    check-cast v1, [Ljava/lang/String;

    .line 219
    .line 220
    invoke-direct {v0, p0}, Lo7/s;-><init>(Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    return-object v0

    .line 224
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 225
    .line 226
    const-string v1, "No subtype found for: \""

    .line 227
    .line 228
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 232
    .line 233
    .line 234
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 235
    .line 236
    .line 237
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 238
    .line 239
    .line 240
    move-result-object p0

    .line 241
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 242
    .line 243
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p0

    .line 247
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 248
    .line 249
    .line 250
    throw v0
.end method

.method public static F(Ljava/util/concurrent/Future;)Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-interface {p0}, Ljava/util/concurrent/Future;->isDone()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    :goto_0
    :try_start_0
    invoke-interface {p0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-object p0

    .line 23
    :catchall_0
    move-exception p0

    .line 24
    if-eqz v2, :cond_1

    .line 25
    .line 26
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 31
    .line 32
    .line 33
    :cond_1
    throw p0

    .line 34
    :catch_0
    move v2, v1

    .line 35
    goto :goto_0

    .line 36
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    new-array v1, v1, [Ljava/lang/Object;

    .line 39
    .line 40
    aput-object p0, v1, v2

    .line 41
    .line 42
    const-string p0, "Future was expected to be done: %s"

    .line 43
    .line 44
    invoke-static {p0, v1}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw v0
.end method

.method public static G(Landroid/content/Context;Landroid/content/Context;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    :try_start_0
    sget-boolean v0, Landroid/support/v4/media/session/b;->a:Z

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    invoke-static {p1, p2, p3}, Landroid/support/v4/media/session/b;->M(Landroid/content/Context;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_2

    .line 9
    return-object p0

    .line 10
    :catch_0
    move-exception p3

    .line 11
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    if-nez p0, :cond_0

    .line 24
    .line 25
    invoke-static {p1, p2}, Lv/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :cond_0
    throw p3

    .line 31
    :catch_1
    const/4 p0, 0x0

    .line 32
    sput-boolean p0, Landroid/support/v4/media/session/b;->a:Z

    .line 33
    .line 34
    :catch_2
    :cond_1
    if-eqz p3, :cond_2

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    :goto_0
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    sget-object p1, Lw/o;->a:Ljava/lang/ThreadLocal;

    .line 46
    .line 47
    invoke-static {p0, p2, p3}, Lw/i;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    return-object p0
.end method

.method public static I(Ljava/lang/RuntimeException;)Lcom/google/common/util/concurrent/m;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/common/util/concurrent/m;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p0}, Lcom/google/common/util/concurrent/b;->u(Ljava/lang/Throwable;)Z

    .line 7
    .line 8
    .line 9
    return-object v0
.end method

.method public static J(Ljava/lang/Object;)Lcom/google/common/util/concurrent/n;
    .locals 1

    .line 1
    if-nez p0, :cond_0

    .line 2
    .line 3
    sget-object p0, Lcom/google/common/util/concurrent/n;->l:Lcom/google/common/util/concurrent/n;

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_0
    new-instance v0, Lcom/google/common/util/concurrent/n;

    .line 7
    .line 8
    invoke-direct {v0, p0}, Lcom/google/common/util/concurrent/n;-><init>(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public static K(Ljava/lang/Throwable;)Z
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    instance-of v0, p0, Ljava/lang/NoSuchMethodError;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    const-string v0, "Landroid/media/NotProvisionedException;.<init>("

    .line 22
    .line 23
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-eqz p0, :cond_0

    .line 28
    .line 29
    const/4 p0, 0x1

    .line 30
    return p0

    .line 31
    :cond_0
    const/4 p0, 0x0

    .line 32
    return p0
.end method

.method public static L(Ljava/lang/Throwable;)Z
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    if-ne v0, v1, :cond_0

    .line 6
    .line 7
    instance-of v0, p0, Ljava/lang/NoSuchMethodError;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    const-string v0, "Landroid/media/ResourceBusyException;.<init>("

    .line 22
    .line 23
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    if-eqz p0, :cond_0

    .line 28
    .line 29
    const/4 p0, 0x1

    .line 30
    return p0

    .line 31
    :cond_0
    const/4 p0, 0x0

    .line 32
    return p0
.end method

.method public static M(Landroid/content/Context;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    new-instance v0, Lm/c;

    .line 4
    .line 5
    invoke-direct {v0, p0}, Landroid/content/ContextWrapper;-><init>(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    iput-object p2, v0, Lm/c;->b:Landroid/content/res/Resources$Theme;

    .line 9
    .line 10
    invoke-virtual {p2}, Landroid/content/res/Resources$Theme;->getResources()Landroid/content/res/Resources;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {v0, p0}, Lm/c;->a(Landroid/content/res/Configuration;)V

    .line 19
    .line 20
    .line 21
    move-object p0, v0

    .line 22
    :cond_0
    invoke-static {p0, p1}, Lcom/bumptech/glide/c;->l(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0
.end method

.method public static N(Lm6/z6;ZLjava/lang/String;Ljava/util/Collection;Lf7/w0;Lm6/h6;)Lm6/a7;
    .locals 8

    .line 1
    const-string v0, "scopedPrefixes"

    .line 2
    .line 3
    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lm6/z6;->a:Lm6/y6;

    .line 7
    .line 8
    iget-object v0, v0, Lm6/y6;->a:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {p4, v0}, Lf7/w0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Ljava/lang/String;

    .line 15
    .line 16
    iget-object p0, p0, Lm6/z6;->b:Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    const/4 v3, 0x1

    .line 23
    const/4 v4, 0x0

    .line 24
    if-eqz v2, :cond_1

    .line 25
    .line 26
    :cond_0
    move p5, v4

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    move v5, v4

    .line 33
    :cond_2
    if-ge v5, v2, :cond_0

    .line 34
    .line 35
    invoke-virtual {p0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    add-int/lit8 v5, v5, 0x1

    .line 40
    .line 41
    check-cast v6, Lm6/e7;

    .line 42
    .line 43
    iget-object v6, v6, Lm6/e7;->a:Ljava/lang/String;

    .line 44
    .line 45
    invoke-virtual {p5, v6}, Lm6/h6;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    check-cast v6, Ljava/lang/Boolean;

    .line 50
    .line 51
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_2

    .line 56
    .line 57
    move p5, v3

    .line 58
    :goto_0
    if-nez p1, :cond_4

    .line 59
    .line 60
    if-eqz p5, :cond_3

    .line 61
    .line 62
    goto :goto_1

    .line 63
    :cond_3
    move v3, v4

    .line 64
    :cond_4
    :goto_1
    if-eqz v3, :cond_5

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_5
    move-object p2, v0

    .line 68
    :goto_2
    invoke-virtual {p4, p2}, Lf7/w0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    check-cast p1, Ljava/lang/String;

    .line 73
    .line 74
    new-instance p4, Ljava/util/LinkedHashMap;

    .line 75
    .line 76
    invoke-direct {p4}, Ljava/util/LinkedHashMap;-><init>()V

    .line 77
    .line 78
    .line 79
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 80
    .line 81
    .line 82
    move-result p5

    .line 83
    :goto_3
    if-ge v4, p5, :cond_9

    .line 84
    .line 85
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    add-int/lit8 v4, v4, 0x1

    .line 90
    .line 91
    check-cast v0, Lm6/e7;

    .line 92
    .line 93
    if-eqz v3, :cond_7

    .line 94
    .line 95
    iget-object v2, v0, Lm6/e7;->a:Ljava/lang/String;

    .line 96
    .line 97
    const-string v5, "oldScope"

    .line 98
    .line 99
    invoke-static {v1, v5}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    const-string v5, "newScope"

    .line 103
    .line 104
    invoke-static {p1, v5}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    invoke-interface {p3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    :cond_6
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    .line 113
    .line 114
    move-result v6

    .line 115
    if-eqz v6, :cond_8

    .line 116
    .line 117
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    check-cast v6, Ljava/lang/String;

    .line 122
    .line 123
    new-instance v7, Ljava/lang/StringBuilder;

    .line 124
    .line 125
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v7

    .line 138
    invoke-virtual {v2, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v7

    .line 142
    if-eqz v7, :cond_6

    .line 143
    .line 144
    invoke-static {v6, p1}, Lq3/e;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v2

    .line 148
    goto :goto_4

    .line 149
    :cond_7
    iget-object v2, v0, Lm6/e7;->a:Ljava/lang/String;

    .line 150
    .line 151
    :cond_8
    :goto_4
    iget-object v0, v0, Lm6/e7;->b:Ljava/io/Serializable;

    .line 152
    .line 153
    invoke-interface {p4, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    goto :goto_3

    .line 157
    :cond_9
    new-instance p0, Lm6/a7;

    .line 158
    .line 159
    invoke-direct {p0, p2, v3, p4}, Lm6/a7;-><init>(Ljava/lang/String;ZLjava/util/LinkedHashMap;)V

    .line 160
    .line 161
    .line 162
    return-object p0
.end method

.method public static final O(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;J)V
    .locals 7

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "group"

    .line 7
    .line 8
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "ep"

    .line 12
    .line 13
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {p0}, Landroid/support/v4/media/session/b;->T(Lcom/harindra/iptvpro/PlayerActivity;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->L()Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    const/16 v1, 0x8

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->y()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 33
    .line 34
    .line 35
    sget-object v0, Lm6/x1;->SERIES_EPISODE:Lm6/x1;

    .line 36
    .line 37
    invoke-virtual {p0, v0}, Lcom/harindra/iptvpro/PlayerActivity;->R(Lm6/x1;)V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I1:Lm6/m7;

    .line 41
    .line 42
    iget v0, p2, Lm6/l7;->d:I

    .line 43
    .line 44
    iput v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->J1:I

    .line 45
    .line 46
    iput-object p2, p0, Lcom/harindra/iptvpro/PlayerActivity;->K1:Lm6/l7;

    .line 47
    .line 48
    iget-object v1, p1, Lm6/m7;->a:Ljava/lang/String;

    .line 49
    .line 50
    const-string v2, "<set-?>"

    .line 51
    .line 52
    invoke-static {v1, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    iput-wide p3, p0, Lcom/harindra/iptvpro/PlayerActivity;->r2:J

    .line 56
    .line 57
    const-string v1, ""

    .line 58
    .line 59
    iput-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->M1:Ljava/lang/String;

    .line 60
    .line 61
    const/4 v1, 0x0

    .line 62
    iput v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->e3:I

    .line 63
    .line 64
    iput v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->N2:I

    .line 65
    .line 66
    iput-boolean v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->s2:Z

    .line 67
    .line 68
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    const/4 v2, 0x2

    .line 73
    const/16 v3, 0x30

    .line 74
    .line 75
    invoke-static {v1, v2, v3}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    iget v4, p2, Lm6/l7;->e:I

    .line 80
    .line 81
    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v5

    .line 85
    invoke-static {v5, v2, v3}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->I()Landroid/widget/TextView;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    new-instance v5, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    const-string v6, "S"

    .line 96
    .line 97
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    const-string v1, "E"

    .line 104
    .line 105
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->H()Landroid/widget/TextView;

    .line 119
    .line 120
    .line 121
    move-result-object v1

    .line 122
    iget-object v2, p1, Lm6/m7;->c:Ljava/lang/String;

    .line 123
    .line 124
    iget-object v3, p2, Lm6/l7;->f:Ljava/lang/String;

    .line 125
    .line 126
    new-instance v5, Ljava/lang/StringBuilder;

    .line 127
    .line 128
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    const-string v2, " \u2022 "

    .line 135
    .line 136
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 140
    .line 141
    .line 142
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v2

    .line 146
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->G()Landroid/widget/TextView;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    iget-object p1, p1, Lm6/m7;->d:Ljava/lang/String;

    .line 154
    .line 155
    new-instance v2, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    const-string p1, " \u2022 Season "

    .line 164
    .line 165
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 176
    .line 177
    .line 178
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->J()Landroid/widget/TextView;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    new-instance v0, Ljava/lang/StringBuilder;

    .line 183
    .line 184
    const-string v1, "Episode "

    .line 185
    .line 186
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 190
    .line 191
    .line 192
    const-string v1, " \u2022 Press BACK for Episode List"

    .line 193
    .line 194
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 195
    .line 196
    .line 197
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->A()Landroid/widget/ProgressBar;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    const-wide/16 v0, 0x0

    .line 209
    .line 210
    cmp-long p3, p3, v0

    .line 211
    .line 212
    if-lez p3, :cond_0

    .line 213
    .line 214
    const/16 p3, 0x32

    .line 215
    .line 216
    goto :goto_0

    .line 217
    :cond_0
    const/16 p3, 0x64

    .line 218
    .line 219
    :goto_0
    invoke-virtual {p1, p3}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 220
    .line 221
    .line 222
    iget-object p1, p2, Lm6/l7;->a:Lm6/n;

    .line 223
    .line 224
    iget-object p1, p1, Lm6/n;->e:Ljava/lang/String;

    .line 225
    .line 226
    const/4 p2, 0x1

    .line 227
    invoke-static {p0, p1, p2}, Lcom/bumptech/glide/c;->r(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;Z)V

    .line 228
    .line 229
    .line 230
    invoke-static {p0}, Lcom/bumptech/glide/c;->z(Lcom/harindra/iptvpro/PlayerActivity;)V

    .line 231
    .line 232
    .line 233
    return-void
.end method

.method public static final P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;
    .locals 3

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance v0, Li/g;

    .line 7
    .line 8
    const v1, 0x7f11012f

    .line 9
    .line 10
    .line 11
    invoke-direct {v0, p0, v1}, Li/g;-><init>(Landroid/content/Context;I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p1}, Li/g;->setView(Landroid/view/View;)Li/g;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {p1}, Li/g;->create()Li/h;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const-string v0, "create(...)"

    .line 23
    .line 24
    invoke-static {p1, v0}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    .line 28
    .line 29
    .line 30
    iget v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->E2:I

    .line 31
    .line 32
    const/4 v1, 0x1

    .line 33
    add-int/2addr v0, v1

    .line 34
    if-ge v0, v1, :cond_0

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    move v1, v0

    .line 38
    :goto_0
    iput v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->E2:I

    .line 39
    .line 40
    new-instance v0, Lm6/t3;

    .line 41
    .line 42
    invoke-direct {v0, p0}, Lm6/t3;-><init>(Lcom/harindra/iptvpro/PlayerActivity;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, v0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    if-eqz v0, :cond_2

    .line 53
    .line 54
    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    .line 55
    .line 56
    const/4 v2, 0x0

    .line 57
    invoke-direct {v1, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p0}, Li/k;->getResources()Landroid/content/res/Resources;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 72
    .line 73
    int-to-float v1, v1

    .line 74
    const v2, 0x3f6b851f    # 0.92f

    .line 75
    .line 76
    .line 77
    mul-float/2addr v1, v2

    .line 78
    float-to-int v1, v1

    .line 79
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 80
    .line 81
    .line 82
    move-result p0

    .line 83
    if-le p0, v1, :cond_1

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_1
    move v1, p0

    .line 87
    :goto_1
    const/4 p0, -0x2

    .line 88
    invoke-virtual {v0, v1, p0}, Landroid/view/Window;->setLayout(II)V

    .line 89
    .line 90
    .line 91
    :cond_2
    return-object p1
.end method

.method public static final Q(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;I)V
    .locals 37

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    const-string v0, "<this>"

    .line 6
    .line 7
    invoke-static {v2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v0, "group"

    .line 11
    .line 12
    invoke-static {v5, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, v5, Lm6/m7;->m:Ljava/lang/String;

    .line 16
    .line 17
    iget-object v1, v5, Lm6/m7;->k:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v3, v5, Lm6/m7;->l:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v7, v5, Lm6/m7;->c:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v4, v5, Lm6/m7;->f:Ljava/lang/String;

    .line 24
    .line 25
    new-instance v6, La7/m;

    .line 26
    .line 27
    const/4 v8, 0x0

    .line 28
    invoke-direct {v6, v8}, La7/m;-><init>(Z)V

    .line 29
    .line 30
    .line 31
    iget-object v8, v5, Lm6/m7;->q:Ljava/util/Map;

    .line 32
    .line 33
    invoke-interface {v8}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 34
    .line 35
    .line 36
    move-result-object v9

    .line 37
    invoke-static {v9}, Lo6/j;->f0(Ljava/util/Collection;)Ljava/util/List;

    .line 38
    .line 39
    .line 40
    move-result-object v9

    .line 41
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object v10

    .line 45
    invoke-interface {v8, v10}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v10

    .line 49
    if-eqz v10, :cond_0

    .line 50
    .line 51
    move/from16 v10, p2

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_0
    invoke-static {v9}, Lo6/j;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v10

    .line 58
    check-cast v10, Ljava/lang/Integer;

    .line 59
    .line 60
    if-eqz v10, :cond_1

    .line 61
    .line 62
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 63
    .line 64
    .line 65
    move-result v10

    .line 66
    goto :goto_0

    .line 67
    :cond_1
    const/4 v10, 0x1

    .line 68
    :goto_0
    iput v10, v2, Lcom/harindra/iptvpro/PlayerActivity;->J1:I

    .line 69
    .line 70
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 71
    .line 72
    .line 73
    move-result-object v12

    .line 74
    invoke-interface {v8, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v12

    .line 78
    check-cast v12, Ljava/util/List;

    .line 79
    .line 80
    sget-object v13, Lo6/r;->k:Lo6/r;

    .line 81
    .line 82
    if-nez v12, :cond_2

    .line 83
    .line 84
    move-object v12, v13

    .line 85
    :cond_2
    new-instance v14, Ljava/util/ArrayList;

    .line 86
    .line 87
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 88
    .line 89
    .line 90
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 91
    .line 92
    .line 93
    move-result-object v15

    .line 94
    :goto_1
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 95
    .line 96
    .line 97
    move-result v16

    .line 98
    if-eqz v16, :cond_4

    .line 99
    .line 100
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v16

    .line 104
    check-cast v16, Ljava/lang/Number;

    .line 105
    .line 106
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->intValue()I

    .line 107
    .line 108
    .line 109
    move-result v16

    .line 110
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 111
    .line 112
    .line 113
    move-result-object v11

    .line 114
    invoke-interface {v8, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v11

    .line 118
    check-cast v11, Ljava/util/List;

    .line 119
    .line 120
    if-nez v11, :cond_3

    .line 121
    .line 122
    move-object v11, v13

    .line 123
    :cond_3
    invoke-static {v14, v11}, Lo6/p;->Q(Ljava/util/ArrayList;Ljava/lang/Iterable;)V

    .line 124
    .line 125
    .line 126
    goto :goto_1

    .line 127
    :cond_4
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    .line 128
    .line 129
    .line 130
    move-result v11

    .line 131
    if-eqz v11, :cond_5

    .line 132
    .line 133
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 134
    .line 135
    .line 136
    move-result-object v11

    .line 137
    iget-object v13, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 138
    .line 139
    invoke-virtual {v11, v13}, Lm6/m6;->p(Ljava/lang/String;)Ljava/util/List;

    .line 140
    .line 141
    .line 142
    move-result-object v13

    .line 143
    :cond_5
    const/16 v11, 0xa

    .line 144
    .line 145
    invoke-static {v13, v11}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    .line 146
    .line 147
    .line 148
    move-result v15

    .line 149
    invoke-static {v15}, Lo6/v;->L(I)I

    .line 150
    .line 151
    .line 152
    move-result v15

    .line 153
    const/16 v11, 0x10

    .line 154
    .line 155
    if-ge v15, v11, :cond_6

    .line 156
    .line 157
    move v15, v11

    .line 158
    :cond_6
    new-instance v11, Ljava/util/LinkedHashMap;

    .line 159
    .line 160
    invoke-direct {v11, v15}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 161
    .line 162
    .line 163
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 164
    .line 165
    .line 166
    move-result-object v13

    .line 167
    :goto_2
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 168
    .line 169
    .line 170
    move-result v15

    .line 171
    if-eqz v15, :cond_7

    .line 172
    .line 173
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v15

    .line 177
    move-object/from16 v17, v6

    .line 178
    .line 179
    move-object v6, v15

    .line 180
    check-cast v6, Lm6/n1;

    .line 181
    .line 182
    iget-object v6, v6, Lm6/n1;->a:Ljava/lang/String;

    .line 183
    .line 184
    invoke-interface {v11, v6, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-object/from16 v6, v17

    .line 188
    .line 189
    goto :goto_2

    .line 190
    :cond_7
    move-object/from16 v17, v6

    .line 191
    .line 192
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    .line 193
    .line 194
    .line 195
    move-result v6

    .line 196
    if-eqz v6, :cond_9

    .line 197
    .line 198
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 199
    .line 200
    .line 201
    move-result-object v6

    .line 202
    iget-object v15, v5, Lm6/m7;->a:Ljava/lang/String;

    .line 203
    .line 204
    iget-object v13, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 205
    .line 206
    move-object/from16 v18, v8

    .line 207
    .line 208
    const-string v8, "seriesKeyOrId"

    .line 209
    .line 210
    invoke-static {v15, v8}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    invoke-static {v15}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 214
    .line 215
    .line 216
    move-result v8

    .line 217
    if-eqz v8, :cond_8

    .line 218
    .line 219
    goto :goto_3

    .line 220
    :cond_8
    invoke-virtual {v6, v13}, Lm6/m6;->O(Ljava/lang/String;)Ljava/util/Set;

    .line 221
    .line 222
    .line 223
    move-result-object v6

    .line 224
    invoke-interface {v6, v15}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    move-result v6

    .line 228
    goto :goto_4

    .line 229
    :cond_9
    move-object/from16 v18, v8

    .line 230
    .line 231
    :goto_3
    const/4 v6, 0x0

    .line 232
    :goto_4
    new-instance v8, Ljava/util/ArrayList;

    .line 233
    .line 234
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 238
    .line 239
    .line 240
    move-result v13

    .line 241
    move-object/from16 v19, v12

    .line 242
    .line 243
    const/4 v15, 0x0

    .line 244
    :goto_5
    if-ge v15, v13, :cond_c

    .line 245
    .line 246
    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v20

    .line 250
    add-int/lit8 v15, v15, 0x1

    .line 251
    .line 252
    move-object/from16 v12, v20

    .line 253
    .line 254
    check-cast v12, Lm6/l7;

    .line 255
    .line 256
    move/from16 v20, v6

    .line 257
    .line 258
    iget-object v6, v12, Lm6/l7;->a:Lm6/n;

    .line 259
    .line 260
    iget-object v6, v6, Lm6/n;->a:Ljava/lang/String;

    .line 261
    .line 262
    invoke-virtual {v11, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object v6

    .line 266
    check-cast v6, Lm6/n1;

    .line 267
    .line 268
    move/from16 v22, v13

    .line 269
    .line 270
    if-eqz v6, :cond_a

    .line 271
    .line 272
    new-instance v13, Ln6/d;

    .line 273
    .line 274
    invoke-direct {v13, v12, v6}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 275
    .line 276
    .line 277
    move-object v12, v13

    .line 278
    goto :goto_6

    .line 279
    :cond_a
    const/4 v12, 0x0

    .line 280
    :goto_6
    if-eqz v12, :cond_b

    .line 281
    .line 282
    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    :cond_b
    move/from16 v6, v20

    .line 286
    .line 287
    move/from16 v13, v22

    .line 288
    .line 289
    goto :goto_5

    .line 290
    :cond_c
    move/from16 v20, v6

    .line 291
    .line 292
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 293
    .line 294
    .line 295
    move-result-object v6

    .line 296
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 297
    .line 298
    .line 299
    move-result v8

    .line 300
    if-nez v8, :cond_d

    .line 301
    .line 302
    const/4 v8, 0x0

    .line 303
    goto :goto_9

    .line 304
    :cond_d
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object v8

    .line 308
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 309
    .line 310
    .line 311
    move-result v12

    .line 312
    if-nez v12, :cond_e

    .line 313
    .line 314
    goto :goto_9

    .line 315
    :cond_e
    move-object v12, v8

    .line 316
    check-cast v12, Ln6/d;

    .line 317
    .line 318
    iget-object v12, v12, Ln6/d;->l:Ljava/lang/Object;

    .line 319
    .line 320
    check-cast v12, Lm6/n1;

    .line 321
    .line 322
    iget-wide v12, v12, Lm6/n1;->d:J

    .line 323
    .line 324
    :goto_7
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    move-result-object v14

    .line 328
    move-object v15, v14

    .line 329
    check-cast v15, Ln6/d;

    .line 330
    .line 331
    iget-object v15, v15, Ln6/d;->l:Ljava/lang/Object;

    .line 332
    .line 333
    check-cast v15, Lm6/n1;

    .line 334
    .line 335
    move-wide/from16 v22, v12

    .line 336
    .line 337
    iget-wide v12, v15, Lm6/n1;->d:J

    .line 338
    .line 339
    cmp-long v15, v22, v12

    .line 340
    .line 341
    if-gez v15, :cond_f

    .line 342
    .line 343
    move-object v8, v14

    .line 344
    goto :goto_8

    .line 345
    :cond_f
    move-wide/from16 v12, v22

    .line 346
    .line 347
    :goto_8
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 348
    .line 349
    .line 350
    move-result v14

    .line 351
    if-nez v14, :cond_3e

    .line 352
    .line 353
    :goto_9
    check-cast v8, Ln6/d;

    .line 354
    .line 355
    new-instance v12, Landroid/widget/LinearLayout;

    .line 356
    .line 357
    invoke-direct {v12, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 358
    .line 359
    .line 360
    const/4 v6, 0x1

    .line 361
    invoke-virtual {v12, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 362
    .line 363
    .line 364
    const v6, 0x7f080059

    .line 365
    .line 366
    .line 367
    invoke-virtual {v12, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 368
    .line 369
    .line 370
    const/16 v6, 0x14

    .line 371
    .line 372
    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 373
    .line 374
    .line 375
    move-result v13

    .line 376
    const/16 v14, 0x10

    .line 377
    .line 378
    invoke-virtual {v2, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 379
    .line 380
    .line 381
    move-result v15

    .line 382
    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 383
    .line 384
    .line 385
    move-result v6

    .line 386
    move-object/from16 v22, v11

    .line 387
    .line 388
    invoke-virtual {v2, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 389
    .line 390
    .line 391
    move-result v11

    .line 392
    invoke-virtual {v12, v13, v15, v6, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 393
    .line 394
    .line 395
    new-instance v6, Landroid/widget/LinearLayout;

    .line 396
    .line 397
    invoke-direct {v6, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 398
    .line 399
    .line 400
    const/4 v11, 0x0

    .line 401
    invoke-virtual {v6, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 402
    .line 403
    .line 404
    const/16 v11, 0x30

    .line 405
    .line 406
    invoke-virtual {v6, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 407
    .line 408
    .line 409
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    .line 410
    .line 411
    const/4 v14, -0x1

    .line 412
    const/4 v15, -0x2

    .line 413
    invoke-direct {v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 414
    .line 415
    .line 416
    invoke-virtual {v6, v13}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 417
    .line 418
    .line 419
    new-instance v13, Landroid/widget/ImageView;

    .line 420
    .line 421
    invoke-direct {v13, v2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 422
    .line 423
    .line 424
    sget-object v11, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    .line 425
    .line 426
    invoke-virtual {v13, v11}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 427
    .line 428
    .line 429
    const v11, 0x7f080057

    .line 430
    .line 431
    .line 432
    invoke-virtual {v13, v11}, Landroid/view/View;->setBackgroundResource(I)V

    .line 433
    .line 434
    .line 435
    const/4 v11, 0x4

    .line 436
    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 437
    .line 438
    .line 439
    move-result v14

    .line 440
    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 441
    .line 442
    .line 443
    move-result v15

    .line 444
    move-object/from16 v24, v8

    .line 445
    .line 446
    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 447
    .line 448
    .line 449
    move-result v8

    .line 450
    move/from16 v25, v10

    .line 451
    .line 452
    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 453
    .line 454
    .line 455
    move-result v10

    .line 456
    invoke-virtual {v13, v14, v15, v8, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 457
    .line 458
    .line 459
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 460
    .line 461
    const/16 v10, 0x76

    .line 462
    .line 463
    invoke-virtual {v2, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 464
    .line 465
    .line 466
    move-result v10

    .line 467
    const/16 v14, 0xaa

    .line 468
    .line 469
    invoke-virtual {v2, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 470
    .line 471
    .line 472
    move-result v14

    .line 473
    invoke-direct {v8, v10, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 474
    .line 475
    .line 476
    const/16 v14, 0x10

    .line 477
    .line 478
    invoke-virtual {v2, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 479
    .line 480
    .line 481
    move-result v10

    .line 482
    invoke-virtual {v8, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {v13, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 486
    .line 487
    .line 488
    invoke-static {v4}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 489
    .line 490
    .line 491
    move-result v8

    .line 492
    if-nez v8, :cond_10

    .line 493
    .line 494
    invoke-static {v2}, Lcom/bumptech/glide/b;->c(Landroid/content/Context;)Lh5/l;

    .line 495
    .line 496
    .line 497
    move-result-object v8

    .line 498
    invoke-virtual {v8, v2}, Lh5/l;->c(Li/k;)Lcom/bumptech/glide/m;

    .line 499
    .line 500
    .line 501
    move-result-object v8

    .line 502
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 503
    .line 504
    .line 505
    new-instance v14, Lcom/bumptech/glide/j;

    .line 506
    .line 507
    iget-object v15, v8, Lcom/bumptech/glide/m;->k:Lcom/bumptech/glide/b;

    .line 508
    .line 509
    iget-object v11, v8, Lcom/bumptech/glide/m;->l:Landroid/content/Context;

    .line 510
    .line 511
    const-class v10, Landroid/graphics/drawable/Drawable;

    .line 512
    .line 513
    invoke-direct {v14, v15, v8, v10, v11}, Lcom/bumptech/glide/j;-><init>(Lcom/bumptech/glide/b;Lcom/bumptech/glide/m;Ljava/lang/Class;Landroid/content/Context;)V

    .line 514
    .line 515
    .line 516
    invoke-virtual {v14, v4}, Lcom/bumptech/glide/j;->A(Ljava/lang/Object;)Lcom/bumptech/glide/j;

    .line 517
    .line 518
    .line 519
    move-result-object v4

    .line 520
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->p()Lk5/e;

    .line 521
    .line 522
    .line 523
    move-result-object v8

    .line 524
    const v10, 0x7f0800d0

    .line 525
    .line 526
    .line 527
    invoke-virtual {v8, v10}, Lk5/a;->k(I)Lk5/a;

    .line 528
    .line 529
    .line 530
    move-result-object v8

    .line 531
    check-cast v8, Lk5/e;

    .line 532
    .line 533
    invoke-virtual {v8, v10}, Lk5/a;->f(I)Lk5/a;

    .line 534
    .line 535
    .line 536
    move-result-object v8

    .line 537
    invoke-virtual {v4, v8}, Lcom/bumptech/glide/j;->v(Lk5/a;)Lcom/bumptech/glide/j;

    .line 538
    .line 539
    .line 540
    move-result-object v4

    .line 541
    invoke-virtual {v4, v13}, Lcom/bumptech/glide/j;->y(Landroid/widget/ImageView;)V

    .line 542
    .line 543
    .line 544
    goto :goto_a

    .line 545
    :cond_10
    const v10, 0x7f0800d0

    .line 546
    .line 547
    .line 548
    sget-object v4, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    .line 549
    .line 550
    invoke-virtual {v13, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 551
    .line 552
    .line 553
    invoke-virtual {v13, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 554
    .line 555
    .line 556
    :goto_a
    invoke-virtual {v6, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 557
    .line 558
    .line 559
    new-instance v4, Landroid/widget/LinearLayout;

    .line 560
    .line 561
    invoke-direct {v4, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 562
    .line 563
    .line 564
    const/4 v8, 0x1

    .line 565
    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 566
    .line 567
    .line 568
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 569
    .line 570
    const/high16 v11, 0x3f800000    # 1.0f

    .line 571
    .line 572
    const/4 v13, 0x0

    .line 573
    const/4 v14, -0x2

    .line 574
    invoke-direct {v10, v13, v14, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 575
    .line 576
    .line 577
    invoke-virtual {v4, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 578
    .line 579
    .line 580
    new-instance v10, Landroid/widget/TextView;

    .line 581
    .line 582
    invoke-direct {v10, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 583
    .line 584
    .line 585
    invoke-virtual {v10, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 586
    .line 587
    .line 588
    const/high16 v13, 0x41940000    # 18.5f

    .line 589
    .line 590
    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 591
    .line 592
    .line 593
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 594
    .line 595
    .line 596
    move-result-object v13

    .line 597
    invoke-virtual {v10, v13, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 598
    .line 599
    .line 600
    const/4 v13, -0x1

    .line 601
    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 602
    .line 603
    .line 604
    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 605
    .line 606
    .line 607
    sget-object v8, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 608
    .line 609
    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 610
    .line 611
    .line 612
    invoke-virtual {v4, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 613
    .line 614
    .line 615
    iget-object v8, v5, Lm6/m7;->g:Ljava/lang/String;

    .line 616
    .line 617
    invoke-static {v8}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 618
    .line 619
    .line 620
    move-result v10

    .line 621
    if-nez v10, :cond_11

    .line 622
    .line 623
    goto :goto_b

    .line 624
    :cond_11
    const/4 v8, 0x0

    .line 625
    :goto_b
    if-nez v8, :cond_13

    .line 626
    .line 627
    iget-object v8, v5, Lm6/m7;->h:Ljava/lang/String;

    .line 628
    .line 629
    invoke-static {v8}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 630
    .line 631
    .line 632
    move-result v10

    .line 633
    if-nez v10, :cond_12

    .line 634
    .line 635
    goto :goto_c

    .line 636
    :cond_12
    const/4 v8, 0x0

    .line 637
    :cond_13
    :goto_c
    invoke-interface/range {v18 .. v18}, Ljava/util/Map;->size()I

    .line 638
    .line 639
    .line 640
    move-result v10

    .line 641
    invoke-interface/range {v18 .. v18}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 642
    .line 643
    .line 644
    move-result-object v13

    .line 645
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 646
    .line 647
    .line 648
    move-result-object v13

    .line 649
    const/4 v14, 0x0

    .line 650
    :goto_d
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 651
    .line 652
    .line 653
    move-result v15

    .line 654
    if-eqz v15, :cond_14

    .line 655
    .line 656
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 657
    .line 658
    .line 659
    move-result-object v15

    .line 660
    check-cast v15, Ljava/util/List;

    .line 661
    .line 662
    invoke-interface {v15}, Ljava/util/List;->size()I

    .line 663
    .line 664
    .line 665
    move-result v15

    .line 666
    add-int/2addr v14, v15

    .line 667
    goto :goto_d

    .line 668
    :cond_14
    new-instance v13, Ljava/lang/StringBuilder;

    .line 669
    .line 670
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 671
    .line 672
    .line 673
    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 674
    .line 675
    .line 676
    const-string v10, " Seasons \u2022 "

    .line 677
    .line 678
    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 679
    .line 680
    .line 681
    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 682
    .line 683
    .line 684
    const-string v10, " Episodes"

    .line 685
    .line 686
    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 687
    .line 688
    .line 689
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 690
    .line 691
    .line 692
    move-result-object v10

    .line 693
    iget-object v13, v5, Lm6/m7;->i:Ljava/lang/String;

    .line 694
    .line 695
    invoke-static {v13}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 696
    .line 697
    .line 698
    move-result v14

    .line 699
    if-nez v14, :cond_15

    .line 700
    .line 701
    goto :goto_e

    .line 702
    :cond_15
    const/4 v13, 0x0

    .line 703
    :goto_e
    if-eqz v13, :cond_16

    .line 704
    .line 705
    const-string v14, "\u2605 "

    .line 706
    .line 707
    invoke-virtual {v14, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 708
    .line 709
    .line 710
    move-result-object v13

    .line 711
    goto :goto_f

    .line 712
    :cond_16
    const/4 v13, 0x0

    .line 713
    :goto_f
    filled-new-array {v8, v10, v13}, [Ljava/lang/String;

    .line 714
    .line 715
    .line 716
    move-result-object v8

    .line 717
    invoke-static {v8}, Lo6/i;->Z([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 718
    .line 719
    .line 720
    move-result-object v8

    .line 721
    const-string v10, "  \u2022  "

    .line 722
    .line 723
    const/16 v13, 0x3e

    .line 724
    .line 725
    const/4 v14, 0x0

    .line 726
    invoke-static {v8, v10, v14, v13}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    .line 727
    .line 728
    .line 729
    move-result-object v8

    .line 730
    new-instance v10, Landroid/widget/TextView;

    .line 731
    .line 732
    invoke-direct {v10, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 733
    .line 734
    .line 735
    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 736
    .line 737
    .line 738
    const/high16 v8, 0x41380000    # 11.5f

    .line 739
    .line 740
    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 741
    .line 742
    .line 743
    const-string v13, "#38BDF8"

    .line 744
    .line 745
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 746
    .line 747
    .line 748
    move-result v14

    .line 749
    invoke-virtual {v10, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 750
    .line 751
    .line 752
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    .line 753
    .line 754
    const/4 v15, -0x2

    .line 755
    invoke-direct {v14, v15, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 756
    .line 757
    .line 758
    const/4 v15, 0x3

    .line 759
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 760
    .line 761
    .line 762
    move-result v11

    .line 763
    iput v11, v14, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 764
    .line 765
    invoke-virtual {v10, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 766
    .line 767
    .line 768
    invoke-virtual {v4, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 769
    .line 770
    .line 771
    new-instance v10, Landroid/widget/TextView;

    .line 772
    .line 773
    invoke-direct {v10, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 774
    .line 775
    .line 776
    iget-object v11, v5, Lm6/m7;->j:Ljava/lang/String;

    .line 777
    .line 778
    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 779
    .line 780
    .line 781
    move-result v14

    .line 782
    if-eqz v14, :cond_17

    .line 783
    .line 784
    iget-object v11, v5, Lm6/m7;->d:Ljava/lang/String;

    .line 785
    .line 786
    :cond_17
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 787
    .line 788
    .line 789
    const/high16 v11, 0x41480000    # 12.5f

    .line 790
    .line 791
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 792
    .line 793
    .line 794
    invoke-virtual {v10}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 795
    .line 796
    .line 797
    move-result-object v11

    .line 798
    const/4 v14, 0x1

    .line 799
    invoke-virtual {v10, v11, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 800
    .line 801
    .line 802
    const-string v11, "#86EFAC"

    .line 803
    .line 804
    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 805
    .line 806
    .line 807
    move-result v11

    .line 808
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 809
    .line 810
    .line 811
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    .line 812
    .line 813
    const/4 v14, -0x2

    .line 814
    invoke-direct {v11, v14, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 815
    .line 816
    .line 817
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 818
    .line 819
    .line 820
    move-result v14

    .line 821
    iput v14, v11, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 822
    .line 823
    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 824
    .line 825
    .line 826
    invoke-virtual {v4, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 827
    .line 828
    .line 829
    invoke-static {v3}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 830
    .line 831
    .line 832
    move-result v10

    .line 833
    if-nez v10, :cond_18

    .line 834
    .line 835
    new-instance v10, Landroid/widget/TextView;

    .line 836
    .line 837
    invoke-direct {v10, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 838
    .line 839
    .line 840
    invoke-virtual {v10, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 841
    .line 842
    .line 843
    invoke-virtual {v10, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 844
    .line 845
    .line 846
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 847
    .line 848
    .line 849
    move-result v3

    .line 850
    invoke-virtual {v10, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 851
    .line 852
    .line 853
    const/4 v14, 0x1

    .line 854
    invoke-virtual {v10, v14}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 855
    .line 856
    .line 857
    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 858
    .line 859
    invoke-virtual {v10, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 860
    .line 861
    .line 862
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 863
    .line 864
    const/4 v13, -0x1

    .line 865
    const/4 v14, -0x2

    .line 866
    invoke-direct {v3, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 867
    .line 868
    .line 869
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 870
    .line 871
    .line 872
    move-result v11

    .line 873
    iput v11, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 874
    .line 875
    invoke-virtual {v10, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 876
    .line 877
    .line 878
    invoke-virtual {v4, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 879
    .line 880
    .line 881
    :cond_18
    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 882
    .line 883
    .line 884
    move-result v3

    .line 885
    const/4 v10, 0x2

    .line 886
    if-nez v3, :cond_19

    .line 887
    .line 888
    new-instance v3, Landroid/widget/TextView;

    .line 889
    .line 890
    invoke-direct {v3, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 891
    .line 892
    .line 893
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 894
    .line 895
    .line 896
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 897
    .line 898
    .line 899
    const-string v1, "#E2E8F0"

    .line 900
    .line 901
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 902
    .line 903
    .line 904
    move-result v1

    .line 905
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 906
    .line 907
    .line 908
    invoke-virtual {v3, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 909
    .line 910
    .line 911
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 912
    .line 913
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 914
    .line 915
    .line 916
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 917
    .line 918
    const/4 v13, -0x1

    .line 919
    const/4 v14, -0x2

    .line 920
    invoke-direct {v1, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 921
    .line 922
    .line 923
    const/4 v11, 0x4

    .line 924
    invoke-virtual {v2, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 925
    .line 926
    .line 927
    move-result v13

    .line 928
    iput v13, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 929
    .line 930
    invoke-virtual {v3, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 931
    .line 932
    .line 933
    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 934
    .line 935
    .line 936
    :cond_19
    invoke-static {v0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 937
    .line 938
    .line 939
    move-result v1

    .line 940
    if-nez v1, :cond_1a

    .line 941
    .line 942
    new-instance v1, Landroid/widget/TextView;

    .line 943
    .line 944
    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 945
    .line 946
    .line 947
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 948
    .line 949
    .line 950
    const/high16 v0, 0x41300000    # 11.0f

    .line 951
    .line 952
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 953
    .line 954
    .line 955
    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 956
    .line 957
    .line 958
    move-result-object v0

    .line 959
    const/4 v14, 0x1

    .line 960
    invoke-virtual {v1, v0, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 961
    .line 962
    .line 963
    const-string v0, "#93C5FD"

    .line 964
    .line 965
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 966
    .line 967
    .line 968
    move-result v0

    .line 969
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 970
    .line 971
    .line 972
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 973
    .line 974
    const/4 v14, -0x2

    .line 975
    invoke-direct {v0, v14, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 976
    .line 977
    .line 978
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 979
    .line 980
    .line 981
    move-result v3

    .line 982
    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 983
    .line 984
    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 985
    .line 986
    .line 987
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 988
    .line 989
    .line 990
    :cond_1a
    invoke-virtual {v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 991
    .line 992
    .line 993
    invoke-virtual {v12, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 994
    .line 995
    .line 996
    new-instance v11, Landroid/widget/LinearLayout;

    .line 997
    .line 998
    invoke-direct {v11, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 999
    .line 1000
    .line 1001
    const/4 v13, 0x0

    .line 1002
    invoke-virtual {v11, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1003
    .line 1004
    .line 1005
    const/16 v14, 0x10

    .line 1006
    .line 1007
    invoke-virtual {v11, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1008
    .line 1009
    .line 1010
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 1011
    .line 1012
    const/4 v13, -0x1

    .line 1013
    const/4 v14, -0x2

    .line 1014
    invoke-direct {v0, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1015
    .line 1016
    .line 1017
    const/16 v1, 0xa

    .line 1018
    .line 1019
    invoke-virtual {v2, v1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1020
    .line 1021
    .line 1022
    move-result v3

    .line 1023
    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1024
    .line 1025
    const/16 v1, 0x8

    .line 1026
    .line 1027
    invoke-virtual {v2, v1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1028
    .line 1029
    .line 1030
    move-result v1

    .line 1031
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 1032
    .line 1033
    invoke-virtual {v11, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1034
    .line 1035
    .line 1036
    const/4 v13, 0x6

    .line 1037
    invoke-static {v13, v9}, Lo6/j;->h0(ILjava/util/List;)Ljava/util/List;

    .line 1038
    .line 1039
    .line 1040
    move-result-object v0

    .line 1041
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v6

    .line 1045
    :goto_10
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 1046
    .line 1047
    .line 1048
    move-result v0

    .line 1049
    const/16 v15, 0xe

    .line 1050
    .line 1051
    if-eqz v0, :cond_1d

    .line 1052
    .line 1053
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v0

    .line 1057
    check-cast v0, Ljava/lang/Number;

    .line 1058
    .line 1059
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 1060
    .line 1061
    .line 1062
    move-result v1

    .line 1063
    move/from16 v4, v25

    .line 1064
    .line 1065
    if-ne v1, v4, :cond_1b

    .line 1066
    .line 1067
    const/4 v0, 0x1

    .line 1068
    goto :goto_11

    .line 1069
    :cond_1b
    const/4 v0, 0x0

    .line 1070
    :goto_11
    new-instance v3, Landroid/widget/Button;

    .line 1071
    .line 1072
    invoke-direct {v3, v2}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 1073
    .line 1074
    .line 1075
    new-instance v14, Ljava/lang/StringBuilder;

    .line 1076
    .line 1077
    const-string v9, "SEASON "

    .line 1078
    .line 1079
    invoke-direct {v14, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1080
    .line 1081
    .line 1082
    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1083
    .line 1084
    .line 1085
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v9

    .line 1089
    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1090
    .line 1091
    .line 1092
    const/4 v9, 0x0

    .line 1093
    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1094
    .line 1095
    .line 1096
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1097
    .line 1098
    .line 1099
    invoke-virtual {v3}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 1100
    .line 1101
    .line 1102
    move-result-object v9

    .line 1103
    const/4 v14, 0x1

    .line 1104
    invoke-virtual {v3, v9, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1105
    .line 1106
    .line 1107
    const/4 v9, -0x1

    .line 1108
    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1109
    .line 1110
    .line 1111
    if-eqz v0, :cond_1c

    .line 1112
    .line 1113
    const v9, 0x7f080051

    .line 1114
    .line 1115
    .line 1116
    goto :goto_12

    .line 1117
    :cond_1c
    const v9, 0x7f080055

    .line 1118
    .line 1119
    .line 1120
    :goto_12
    invoke-virtual {v3, v9}, Landroid/view/View;->setBackgroundResource(I)V

    .line 1121
    .line 1122
    .line 1123
    const/4 v0, 0x0

    .line 1124
    invoke-virtual {v3, v0}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 1125
    .line 1126
    .line 1127
    invoke-virtual {v3, v14}, Landroid/view/View;->setFocusable(Z)V

    .line 1128
    .line 1129
    .line 1130
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1131
    .line 1132
    .line 1133
    move-result v0

    .line 1134
    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1135
    .line 1136
    .line 1137
    move-result v9

    .line 1138
    invoke-virtual {v2, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1139
    .line 1140
    .line 1141
    move-result v14

    .line 1142
    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1143
    .line 1144
    .line 1145
    move-result v15

    .line 1146
    invoke-virtual {v3, v0, v9, v14, v15}, Landroid/view/View;->setPadding(IIII)V

    .line 1147
    .line 1148
    .line 1149
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 1150
    .line 1151
    const/16 v9, 0x24

    .line 1152
    .line 1153
    invoke-virtual {v2, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1154
    .line 1155
    .line 1156
    move-result v9

    .line 1157
    const/4 v14, -0x2

    .line 1158
    invoke-direct {v0, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1159
    .line 1160
    .line 1161
    invoke-virtual {v2, v13}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1162
    .line 1163
    .line 1164
    move-result v9

    .line 1165
    invoke-virtual {v0, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 1166
    .line 1167
    .line 1168
    invoke-virtual {v3, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1169
    .line 1170
    .line 1171
    new-instance v0, Lm6/w1;

    .line 1172
    .line 1173
    const v9, 0x3f847ae1    # 1.035f

    .line 1174
    .line 1175
    .line 1176
    invoke-direct {v0, v9, v2}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    .line 1177
    .line 1178
    .line 1179
    invoke-virtual {v3, v0}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 1180
    .line 1181
    .line 1182
    new-instance v0, Lm6/c5;

    .line 1183
    .line 1184
    move v9, v4

    .line 1185
    move-object v4, v2

    .line 1186
    move v2, v9

    .line 1187
    move-object v9, v3

    .line 1188
    move-object/from16 v3, v17

    .line 1189
    .line 1190
    invoke-direct/range {v0 .. v5}, Lm6/c5;-><init>(IILa7/m;Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;)V

    .line 1191
    .line 1192
    .line 1193
    move v14, v2

    .line 1194
    move-object v1, v3

    .line 1195
    invoke-virtual {v9, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1196
    .line 1197
    .line 1198
    invoke-virtual {v11, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1199
    .line 1200
    .line 1201
    move-object/from16 v2, p0

    .line 1202
    .line 1203
    move-object/from16 v5, p1

    .line 1204
    .line 1205
    move-object/from16 v17, v1

    .line 1206
    .line 1207
    move/from16 v25, v14

    .line 1208
    .line 1209
    goto/16 :goto_10

    .line 1210
    .line 1211
    :cond_1d
    move-object/from16 v1, v17

    .line 1212
    .line 1213
    move/from16 v14, v25

    .line 1214
    .line 1215
    const v6, 0x7f080052

    .line 1216
    .line 1217
    .line 1218
    const-string v9, "E"

    .line 1219
    .line 1220
    if-eqz v24, :cond_1e

    .line 1221
    .line 1222
    move-object/from16 v0, v24

    .line 1223
    .line 1224
    iget-object v2, v0, Ln6/d;->k:Ljava/lang/Object;

    .line 1225
    .line 1226
    move-object v4, v2

    .line 1227
    check-cast v4, Lm6/l7;

    .line 1228
    .line 1229
    iget-object v0, v0, Ln6/d;->l:Ljava/lang/Object;

    .line 1230
    .line 1231
    move-object v3, v0

    .line 1232
    check-cast v3, Lm6/n1;

    .line 1233
    .line 1234
    iget v0, v4, Lm6/l7;->d:I

    .line 1235
    .line 1236
    iget v2, v4, Lm6/l7;->e:I

    .line 1237
    .line 1238
    invoke-virtual {v3}, Lm6/n1;->b()I

    .line 1239
    .line 1240
    .line 1241
    move-result v5

    .line 1242
    const-string v8, "\u25b6 Resume S"

    .line 1243
    .line 1244
    const-string v10, " ("

    .line 1245
    .line 1246
    invoke-static {v0, v2, v8, v9, v10}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v0

    .line 1250
    const-string v2, "%)"

    .line 1251
    .line 1252
    invoke-static {v0, v5, v2}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    .line 1253
    .line 1254
    .line 1255
    move-result-object v8

    .line 1256
    new-instance v0, Lm6/d5;

    .line 1257
    .line 1258
    move-object/from16 v2, p0

    .line 1259
    .line 1260
    move-object/from16 v5, p1

    .line 1261
    .line 1262
    invoke-direct/range {v0 .. v5}, Lm6/d5;-><init>(La7/m;Lcom/harindra/iptvpro/PlayerActivity;Lm6/n1;Lm6/l7;Lm6/m7;)V

    .line 1263
    .line 1264
    .line 1265
    const/4 v3, 0x0

    .line 1266
    invoke-static {v2, v8, v6, v3, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 1267
    .line 1268
    .line 1269
    move-result-object v0

    .line 1270
    invoke-virtual {v11, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1271
    .line 1272
    .line 1273
    goto :goto_13

    .line 1274
    :cond_1e
    move-object/from16 v2, p0

    .line 1275
    .line 1276
    :goto_13
    if-eqz v20, :cond_1f

    .line 1277
    .line 1278
    const-string v0, "\u2605 Watchlisted"

    .line 1279
    .line 1280
    :goto_14
    move-object v8, v0

    .line 1281
    goto :goto_15

    .line 1282
    :cond_1f
    const-string v0, "\u2606 + Watchlist"

    .line 1283
    .line 1284
    goto :goto_14

    .line 1285
    :goto_15
    if-eqz v20, :cond_20

    .line 1286
    .line 1287
    const v0, 0x7f080053

    .line 1288
    .line 1289
    .line 1290
    :goto_16
    move v10, v0

    .line 1291
    goto :goto_17

    .line 1292
    :cond_20
    const v0, 0x7f080054

    .line 1293
    .line 1294
    .line 1295
    goto :goto_16

    .line 1296
    :goto_17
    new-instance v0, Lm6/e5;

    .line 1297
    .line 1298
    const/4 v5, 0x0

    .line 1299
    move-object v3, v1

    .line 1300
    move-object v1, v2

    .line 1301
    move v4, v14

    .line 1302
    move-object/from16 v2, p1

    .line 1303
    .line 1304
    invoke-direct/range {v0 .. v5}, Lm6/e5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;II)V

    .line 1305
    .line 1306
    .line 1307
    move-object v2, v1

    .line 1308
    move-object v1, v3

    .line 1309
    const/4 v3, 0x0

    .line 1310
    invoke-static {v2, v8, v10, v3, v0}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 1311
    .line 1312
    .line 1313
    move-result-object v0

    .line 1314
    invoke-virtual {v11, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1315
    .line 1316
    .line 1317
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    .line 1318
    .line 1319
    .line 1320
    move-result v0

    .line 1321
    if-eqz v0, :cond_21

    .line 1322
    .line 1323
    invoke-virtual {v2}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 1324
    .line 1325
    .line 1326
    move-result-object v0

    .line 1327
    iget-object v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 1328
    .line 1329
    invoke-virtual {v0, v3}, Lm6/m6;->T(Ljava/lang/String;)Ljava/util/Set;

    .line 1330
    .line 1331
    .line 1332
    move-result-object v0

    .line 1333
    :goto_18
    move-object v8, v0

    .line 1334
    goto :goto_19

    .line 1335
    :cond_21
    sget-object v0, Lo6/t;->k:Lo6/t;

    .line 1336
    .line 1337
    goto :goto_18

    .line 1338
    :goto_19
    invoke-interface/range {v19 .. v19}, Ljava/util/Collection;->isEmpty()Z

    .line 1339
    .line 1340
    .line 1341
    move-result v0

    .line 1342
    if-eqz v0, :cond_23

    .line 1343
    .line 1344
    const/4 v3, 0x0

    .line 1345
    :cond_22
    const/16 v21, 0x0

    .line 1346
    .line 1347
    goto :goto_1b

    .line 1348
    :cond_23
    invoke-interface/range {v19 .. v19}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1349
    .line 1350
    .line 1351
    move-result-object v0

    .line 1352
    const/4 v3, 0x0

    .line 1353
    :goto_1a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1354
    .line 1355
    .line 1356
    move-result v5

    .line 1357
    if-eqz v5, :cond_22

    .line 1358
    .line 1359
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1360
    .line 1361
    .line 1362
    move-result-object v5

    .line 1363
    check-cast v5, Lm6/l7;

    .line 1364
    .line 1365
    iget-object v5, v5, Lm6/l7;->a:Lm6/n;

    .line 1366
    .line 1367
    iget-object v5, v5, Lm6/n;->a:Ljava/lang/String;

    .line 1368
    .line 1369
    invoke-interface {v8, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1370
    .line 1371
    .line 1372
    move-result v5

    .line 1373
    if-eqz v5, :cond_25

    .line 1374
    .line 1375
    add-int/lit8 v3, v3, 0x1

    .line 1376
    .line 1377
    if-ltz v3, :cond_24

    .line 1378
    .line 1379
    goto :goto_1a

    .line 1380
    :cond_24
    invoke-static {}, Lo6/k;->M()V

    .line 1381
    .line 1382
    .line 1383
    const/16 v21, 0x0

    .line 1384
    .line 1385
    throw v21

    .line 1386
    :cond_25
    const/16 v21, 0x0

    .line 1387
    .line 1388
    goto :goto_1a

    .line 1389
    :goto_1b
    invoke-interface/range {v19 .. v19}, Ljava/util/Collection;->isEmpty()Z

    .line 1390
    .line 1391
    .line 1392
    move-result v0

    .line 1393
    if-nez v0, :cond_26

    .line 1394
    .line 1395
    invoke-interface/range {v19 .. v19}, Ljava/util/List;->size()I

    .line 1396
    .line 1397
    .line 1398
    move-result v0

    .line 1399
    if-ne v3, v0, :cond_26

    .line 1400
    .line 1401
    const/4 v2, 0x1

    .line 1402
    goto :goto_1c

    .line 1403
    :cond_26
    const/4 v2, 0x0

    .line 1404
    :goto_1c
    const-string v0, ")"

    .line 1405
    .line 1406
    const-string v5, "/"

    .line 1407
    .line 1408
    invoke-interface/range {v19 .. v19}, Ljava/util/List;->size()I

    .line 1409
    .line 1410
    .line 1411
    move-result v10

    .line 1412
    if-eqz v2, :cond_27

    .line 1413
    .line 1414
    const-string v14, "\u2713 Season Watched ("

    .line 1415
    .line 1416
    invoke-static {v3, v10, v14, v5, v0}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1417
    .line 1418
    .line 1419
    move-result-object v0

    .line 1420
    :goto_1d
    move-object v10, v0

    .line 1421
    goto :goto_1e

    .line 1422
    :cond_27
    const-string v14, "\u2713 Mark S"

    .line 1423
    .line 1424
    const-string v6, " Watched ("

    .line 1425
    .line 1426
    invoke-static {v4, v3, v14, v6, v5}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1427
    .line 1428
    .line 1429
    move-result-object v3

    .line 1430
    invoke-static {v3, v10, v0}, La0/h;->v(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    .line 1431
    .line 1432
    .line 1433
    move-result-object v0

    .line 1434
    goto :goto_1d

    .line 1435
    :goto_1e
    if-eqz v2, :cond_28

    .line 1436
    .line 1437
    const v14, 0x7f080052

    .line 1438
    .line 1439
    .line 1440
    goto :goto_1f

    .line 1441
    :cond_28
    const v14, 0x7f080055

    .line 1442
    .line 1443
    .line 1444
    :goto_1f
    new-instance v0, Lm6/s5;

    .line 1445
    .line 1446
    move-object/from16 v3, p0

    .line 1447
    .line 1448
    move-object/from16 v6, p1

    .line 1449
    .line 1450
    move-object v5, v1

    .line 1451
    move-object/from16 v1, v19

    .line 1452
    .line 1453
    invoke-direct/range {v0 .. v6}, Lm6/s5;-><init>(Ljava/util/List;ZLcom/harindra/iptvpro/PlayerActivity;ILa7/m;Lm6/m7;)V

    .line 1454
    .line 1455
    .line 1456
    move-object v2, v3

    .line 1457
    move-object v1, v5

    .line 1458
    move-object v5, v6

    .line 1459
    move-object v3, v0

    .line 1460
    move v0, v4

    .line 1461
    const/4 v4, 0x0

    .line 1462
    invoke-static {v2, v10, v14, v4, v3}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 1463
    .line 1464
    .line 1465
    move-result-object v3

    .line 1466
    invoke-virtual {v11, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1467
    .line 1468
    .line 1469
    iget-boolean v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->q1:Z

    .line 1470
    .line 1471
    if-eqz v3, :cond_29

    .line 1472
    .line 1473
    const-string v4, "Filter: Unwatched Only \u2713"

    .line 1474
    .line 1475
    goto :goto_20

    .line 1476
    :cond_29
    const-string v4, "Filter: All Episodes"

    .line 1477
    .line 1478
    :goto_20
    if-eqz v3, :cond_2a

    .line 1479
    .line 1480
    const v3, 0x7f080051

    .line 1481
    .line 1482
    .line 1483
    goto :goto_21

    .line 1484
    :cond_2a
    const v3, 0x7f080055

    .line 1485
    .line 1486
    .line 1487
    :goto_21
    new-instance v6, Lm6/e5;

    .line 1488
    .line 1489
    invoke-direct {v6, v2, v1, v5, v0}, Lm6/e5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;La7/m;Lm6/m7;I)V

    .line 1490
    .line 1491
    .line 1492
    const/4 v0, 0x0

    .line 1493
    invoke-static {v2, v4, v3, v0, v6}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 1494
    .line 1495
    .line 1496
    move-result-object v3

    .line 1497
    invoke-virtual {v11, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1498
    .line 1499
    .line 1500
    invoke-virtual {v12, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1501
    .line 1502
    .line 1503
    invoke-virtual {v2}, Li/k;->getResources()Landroid/content/res/Resources;

    .line 1504
    .line 1505
    .line 1506
    move-result-object v0

    .line 1507
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 1508
    .line 1509
    .line 1510
    move-result-object v0

    .line 1511
    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 1512
    .line 1513
    int-to-float v0, v0

    .line 1514
    const v3, 0x3ee147ae    # 0.44f

    .line 1515
    .line 1516
    .line 1517
    mul-float/2addr v0, v3

    .line 1518
    float-to-int v0, v0

    .line 1519
    const/16 v3, 0x96

    .line 1520
    .line 1521
    invoke-virtual {v2, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1522
    .line 1523
    .line 1524
    move-result v3

    .line 1525
    if-ge v0, v3, :cond_2b

    .line 1526
    .line 1527
    move v6, v3

    .line 1528
    goto :goto_22

    .line 1529
    :cond_2b
    move v6, v0

    .line 1530
    :goto_22
    new-instance v10, Landroid/widget/ScrollView;

    .line 1531
    .line 1532
    invoke-direct {v10, v2}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 1533
    .line 1534
    .line 1535
    const/4 v3, 0x0

    .line 1536
    invoke-virtual {v10, v3}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 1537
    .line 1538
    .line 1539
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 1540
    .line 1541
    const/4 v3, -0x1

    .line 1542
    const/4 v14, -0x2

    .line 1543
    invoke-direct {v0, v3, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1544
    .line 1545
    .line 1546
    invoke-virtual {v10, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1547
    .line 1548
    .line 1549
    new-instance v11, Landroid/widget/LinearLayout;

    .line 1550
    .line 1551
    invoke-direct {v11, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1552
    .line 1553
    .line 1554
    const/4 v14, 0x1

    .line 1555
    invoke-virtual {v11, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1556
    .line 1557
    .line 1558
    new-instance v14, La7/m;

    .line 1559
    .line 1560
    const/4 v0, 0x0

    .line 1561
    invoke-direct {v14, v0}, La7/m;-><init>(Z)V

    .line 1562
    .line 1563
    .line 1564
    iget-object v0, v2, Lcom/harindra/iptvpro/PlayerActivity;->K1:Lm6/l7;

    .line 1565
    .line 1566
    if-eqz v0, :cond_2c

    .line 1567
    .line 1568
    iget-object v0, v0, Lm6/l7;->a:Lm6/n;

    .line 1569
    .line 1570
    iget-object v0, v0, Lm6/n;->a:Ljava/lang/String;

    .line 1571
    .line 1572
    goto :goto_23

    .line 1573
    :cond_2c
    move-object/from16 v0, v21

    .line 1574
    .line 1575
    :goto_23
    iget-boolean v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->q1:Z

    .line 1576
    .line 1577
    if-eqz v3, :cond_2f

    .line 1578
    .line 1579
    new-instance v3, Ljava/util/ArrayList;

    .line 1580
    .line 1581
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1582
    .line 1583
    .line 1584
    invoke-interface/range {v19 .. v19}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1585
    .line 1586
    .line 1587
    move-result-object v4

    .line 1588
    :goto_24
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1589
    .line 1590
    .line 1591
    move-result v20

    .line 1592
    if-eqz v20, :cond_2e

    .line 1593
    .line 1594
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1595
    .line 1596
    .line 1597
    move-result-object v13

    .line 1598
    move-object v15, v13

    .line 1599
    check-cast v15, Lm6/l7;

    .line 1600
    .line 1601
    iget-object v15, v15, Lm6/l7;->a:Lm6/n;

    .line 1602
    .line 1603
    iget-object v15, v15, Lm6/n;->a:Ljava/lang/String;

    .line 1604
    .line 1605
    invoke-interface {v8, v15}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1606
    .line 1607
    .line 1608
    move-result v15

    .line 1609
    if-nez v15, :cond_2d

    .line 1610
    .line 1611
    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1612
    .line 1613
    .line 1614
    :cond_2d
    const/4 v13, 0x6

    .line 1615
    const/16 v15, 0xe

    .line 1616
    .line 1617
    goto :goto_24

    .line 1618
    :cond_2e
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1619
    .line 1620
    .line 1621
    move-result v4

    .line 1622
    if-eqz v4, :cond_30

    .line 1623
    .line 1624
    :cond_2f
    move-object/from16 v3, v19

    .line 1625
    .line 1626
    :cond_30
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1627
    .line 1628
    .line 1629
    move-result-object v13

    .line 1630
    :goto_25
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 1631
    .line 1632
    .line 1633
    move-result v3

    .line 1634
    if-eqz v3, :cond_3c

    .line 1635
    .line 1636
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1637
    .line 1638
    .line 1639
    move-result-object v3

    .line 1640
    move-object v4, v3

    .line 1641
    check-cast v4, Lm6/l7;

    .line 1642
    .line 1643
    iget-object v3, v4, Lm6/l7;->a:Lm6/n;

    .line 1644
    .line 1645
    iget-object v15, v4, Lm6/l7;->g:Ljava/lang/String;

    .line 1646
    .line 1647
    move-object/from16 v19, v13

    .line 1648
    .line 1649
    iget v13, v4, Lm6/l7;->e:I

    .line 1650
    .line 1651
    move/from16 v20, v6

    .line 1652
    .line 1653
    iget v6, v4, Lm6/l7;->d:I

    .line 1654
    .line 1655
    move-object/from16 v29, v12

    .line 1656
    .line 1657
    iget-object v12, v4, Lm6/l7;->f:Ljava/lang/String;

    .line 1658
    .line 1659
    move-object/from16 v30, v10

    .line 1660
    .line 1661
    iget-object v10, v3, Lm6/n;->a:Ljava/lang/String;

    .line 1662
    .line 1663
    iget-object v3, v3, Lm6/n;->a:Ljava/lang/String;

    .line 1664
    .line 1665
    move-object/from16 v31, v11

    .line 1666
    .line 1667
    move-object/from16 v11, v22

    .line 1668
    .line 1669
    invoke-virtual {v11, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1670
    .line 1671
    .line 1672
    move-result-object v3

    .line 1673
    check-cast v3, Lm6/n1;

    .line 1674
    .line 1675
    invoke-interface {v8, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1676
    .line 1677
    .line 1678
    move-result v21

    .line 1679
    if-eqz v0, :cond_31

    .line 1680
    .line 1681
    invoke-static {v10, v0}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1682
    .line 1683
    .line 1684
    move-result v22

    .line 1685
    if-nez v22, :cond_32

    .line 1686
    .line 1687
    :cond_31
    if-eqz v3, :cond_33

    .line 1688
    .line 1689
    :cond_32
    move-object/from16 v22, v0

    .line 1690
    .line 1691
    const/4 v0, 0x1

    .line 1692
    :goto_26
    move-object/from16 v32, v8

    .line 1693
    .line 1694
    goto :goto_27

    .line 1695
    :cond_33
    move-object/from16 v22, v0

    .line 1696
    .line 1697
    const/4 v0, 0x0

    .line 1698
    goto :goto_26

    .line 1699
    :goto_27
    new-instance v8, Landroid/widget/LinearLayout;

    .line 1700
    .line 1701
    invoke-direct {v8, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1702
    .line 1703
    .line 1704
    move-object/from16 v33, v1

    .line 1705
    .line 1706
    const/4 v1, 0x0

    .line 1707
    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1708
    .line 1709
    .line 1710
    const/16 v1, 0x10

    .line 1711
    .line 1712
    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1713
    .line 1714
    .line 1715
    const/4 v1, 0x1

    .line 1716
    invoke-virtual {v8, v1}, Landroid/view/View;->setFocusable(Z)V

    .line 1717
    .line 1718
    .line 1719
    invoke-virtual {v8, v1}, Landroid/view/View;->setClickable(Z)V

    .line 1720
    .line 1721
    .line 1722
    invoke-virtual {v8, v0}, Landroid/view/View;->setSelected(Z)V

    .line 1723
    .line 1724
    .line 1725
    if-eqz v0, :cond_34

    .line 1726
    .line 1727
    const v0, 0x7f080051

    .line 1728
    .line 1729
    .line 1730
    goto :goto_28

    .line 1731
    :cond_34
    const v0, 0x7f08005b

    .line 1732
    .line 1733
    .line 1734
    :goto_28
    invoke-virtual {v8, v0}, Landroid/view/View;->setBackgroundResource(I)V

    .line 1735
    .line 1736
    .line 1737
    const/16 v0, 0xe

    .line 1738
    .line 1739
    invoke-virtual {v2, v0}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1740
    .line 1741
    .line 1742
    move-result v1

    .line 1743
    move-object/from16 v28, v3

    .line 1744
    .line 1745
    move-object/from16 v34, v4

    .line 1746
    .line 1747
    const/16 v3, 0xa

    .line 1748
    .line 1749
    invoke-virtual {v2, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1750
    .line 1751
    .line 1752
    move-result v4

    .line 1753
    invoke-virtual {v2, v0}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1754
    .line 1755
    .line 1756
    move-result v5

    .line 1757
    invoke-virtual {v2, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1758
    .line 1759
    .line 1760
    move-result v0

    .line 1761
    invoke-virtual {v8, v1, v4, v5, v0}, Landroid/view/View;->setPadding(IIII)V

    .line 1762
    .line 1763
    .line 1764
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    .line 1765
    .line 1766
    const/4 v1, -0x2

    .line 1767
    const/4 v3, -0x1

    .line 1768
    invoke-direct {v0, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1769
    .line 1770
    .line 1771
    const/4 v1, 0x6

    .line 1772
    invoke-virtual {v2, v1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 1773
    .line 1774
    .line 1775
    move-result v3

    .line 1776
    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 1777
    .line 1778
    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1779
    .line 1780
    .line 1781
    new-instance v0, Lm6/w1;

    .line 1782
    .line 1783
    const v3, 0x3f81eb85    # 1.015f

    .line 1784
    .line 1785
    .line 1786
    invoke-direct {v0, v3, v2}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    .line 1787
    .line 1788
    .line 1789
    invoke-virtual {v8, v0}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 1790
    .line 1791
    .line 1792
    new-instance v0, Lm6/f5;

    .line 1793
    .line 1794
    move-object/from16 v5, p1

    .line 1795
    .line 1796
    move/from16 v16, v1

    .line 1797
    .line 1798
    move-object/from16 v27, v11

    .line 1799
    .line 1800
    move-object/from16 v11, v22

    .line 1801
    .line 1802
    move-object/from16 v3, v28

    .line 1803
    .line 1804
    move-object/from16 v1, v33

    .line 1805
    .line 1806
    move-object/from16 v4, v34

    .line 1807
    .line 1808
    const/16 v22, 0x10

    .line 1809
    .line 1810
    const/16 v28, 0xe

    .line 1811
    .line 1812
    invoke-direct/range {v0 .. v5}, Lm6/f5;-><init>(La7/m;Lcom/harindra/iptvpro/PlayerActivity;Lm6/n1;Lm6/l7;Lm6/m7;)V

    .line 1813
    .line 1814
    .line 1815
    invoke-virtual {v8, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1816
    .line 1817
    .line 1818
    new-instance v0, Lm6/g5;

    .line 1819
    .line 1820
    move-object/from16 v2, p0

    .line 1821
    .line 1822
    invoke-direct/range {v0 .. v5}, Lm6/g5;-><init>(La7/m;Lcom/harindra/iptvpro/PlayerActivity;Lm6/n1;Lm6/l7;Lm6/m7;)V

    .line 1823
    .line 1824
    .line 1825
    move-object v5, v1

    .line 1826
    invoke-virtual {v8, v0}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 1827
    .line 1828
    .line 1829
    new-instance v0, Landroid/widget/LinearLayout;

    .line 1830
    .line 1831
    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1832
    .line 1833
    .line 1834
    const/4 v1, 0x1

    .line 1835
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1836
    .line 1837
    .line 1838
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 1839
    .line 1840
    move-object/from16 v26, v3

    .line 1841
    .line 1842
    move-object/from16 v33, v5

    .line 1843
    .line 1844
    const/4 v3, 0x0

    .line 1845
    const/high16 v4, 0x3f800000    # 1.0f

    .line 1846
    .line 1847
    const/4 v5, -0x2

    .line 1848
    invoke-direct {v1, v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1849
    .line 1850
    .line 1851
    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1852
    .line 1853
    .line 1854
    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 1855
    .line 1856
    .line 1857
    move-result-object v1

    .line 1858
    const/16 v3, 0x30

    .line 1859
    .line 1860
    const/4 v5, 0x2

    .line 1861
    invoke-static {v1, v5, v3}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 1862
    .line 1863
    .line 1864
    move-result-object v1

    .line 1865
    invoke-static {v13}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 1866
    .line 1867
    .line 1868
    move-result-object v4

    .line 1869
    invoke-static {v4, v5, v3}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 1870
    .line 1871
    .line 1872
    move-result-object v4

    .line 1873
    new-instance v5, Ljava/lang/StringBuilder;

    .line 1874
    .line 1875
    const-string v3, "S"

    .line 1876
    .line 1877
    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1878
    .line 1879
    .line 1880
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1881
    .line 1882
    .line 1883
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1884
    .line 1885
    .line 1886
    move-result-object v3

    .line 1887
    const/4 v5, 0x1

    .line 1888
    invoke-static {v12, v3, v5}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 1889
    .line 1890
    .line 1891
    move-result v3

    .line 1892
    if-eqz v3, :cond_35

    .line 1893
    .line 1894
    goto :goto_29

    .line 1895
    :cond_35
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1896
    .line 1897
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 1898
    .line 1899
    .line 1900
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1901
    .line 1902
    .line 1903
    const-string v5, " - S"

    .line 1904
    .line 1905
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1906
    .line 1907
    .line 1908
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1909
    .line 1910
    .line 1911
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1912
    .line 1913
    .line 1914
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1915
    .line 1916
    .line 1917
    const-string v1, " \u2022 "

    .line 1918
    .line 1919
    invoke-static {v3, v1, v12}, La0/h;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1920
    .line 1921
    .line 1922
    move-result-object v12

    .line 1923
    :goto_29
    new-instance v1, Landroid/widget/TextView;

    .line 1924
    .line 1925
    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1926
    .line 1927
    .line 1928
    invoke-virtual {v1, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1929
    .line 1930
    .line 1931
    const/high16 v3, 0x41580000    # 13.5f

    .line 1932
    .line 1933
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1934
    .line 1935
    .line 1936
    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 1937
    .line 1938
    .line 1939
    move-result-object v3

    .line 1940
    const/4 v5, 0x1

    .line 1941
    invoke-virtual {v1, v3, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1942
    .line 1943
    .line 1944
    const/4 v3, -0x1

    .line 1945
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1946
    .line 1947
    .line 1948
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1949
    .line 1950
    .line 1951
    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 1952
    .line 1953
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1954
    .line 1955
    .line 1956
    invoke-static {v15}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 1957
    .line 1958
    .line 1959
    move-result v4

    .line 1960
    const-string v5, ""

    .line 1961
    .line 1962
    if-nez v4, :cond_36

    .line 1963
    .line 1964
    const-string v4, "   DURATION: "

    .line 1965
    .line 1966
    invoke-static {v4, v15}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1967
    .line 1968
    .line 1969
    move-result-object v4

    .line 1970
    goto :goto_2a

    .line 1971
    :cond_36
    move-object v4, v5

    .line 1972
    :goto_2a
    const-string v12, "%"

    .line 1973
    .line 1974
    if-eqz v26, :cond_37

    .line 1975
    .line 1976
    invoke-virtual/range {v26 .. v26}, Lm6/n1;->b()I

    .line 1977
    .line 1978
    .line 1979
    move-result v5

    .line 1980
    const-string v15, "   \u2022   RESUME "

    .line 1981
    .line 1982
    invoke-static {v5, v15, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1983
    .line 1984
    .line 1985
    move-result-object v5

    .line 1986
    :cond_37
    new-instance v15, Landroid/widget/TextView;

    .line 1987
    .line 1988
    invoke-direct {v15, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1989
    .line 1990
    .line 1991
    move-object/from16 v35, v7

    .line 1992
    .line 1993
    const-string v7, "EPISODE NO: "

    .line 1994
    .line 1995
    move-object/from16 v36, v9

    .line 1996
    .line 1997
    const-string v9, "     SEASON: "

    .line 1998
    .line 1999
    invoke-static {v13, v6, v7, v9, v4}, La0/h;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2000
    .line 2001
    .line 2002
    move-result-object v4

    .line 2003
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2004
    .line 2005
    .line 2006
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2007
    .line 2008
    .line 2009
    move-result-object v4

    .line 2010
    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2011
    .line 2012
    .line 2013
    const/high16 v4, 0x41380000    # 11.5f

    .line 2014
    .line 2015
    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2016
    .line 2017
    .line 2018
    invoke-virtual {v15}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 2019
    .line 2020
    .line 2021
    move-result-object v5

    .line 2022
    const/4 v6, 0x1

    .line 2023
    invoke-virtual {v15, v5, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2024
    .line 2025
    .line 2026
    const-string v5, "#FBBF24"

    .line 2027
    .line 2028
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 2029
    .line 2030
    .line 2031
    move-result v5

    .line 2032
    invoke-virtual {v15, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2033
    .line 2034
    .line 2035
    invoke-virtual {v15, v6}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 2036
    .line 2037
    .line 2038
    invoke-virtual {v15, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 2039
    .line 2040
    .line 2041
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 2042
    .line 2043
    const/4 v5, -0x2

    .line 2044
    invoke-direct {v3, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2045
    .line 2046
    .line 2047
    const/4 v5, 0x2

    .line 2048
    invoke-virtual {v2, v5}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2049
    .line 2050
    .line 2051
    move-result v6

    .line 2052
    iput v6, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 2053
    .line 2054
    invoke-virtual {v15, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2055
    .line 2056
    .line 2057
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2058
    .line 2059
    .line 2060
    invoke-virtual {v0, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2061
    .line 2062
    .line 2063
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2064
    .line 2065
    .line 2066
    new-instance v0, Landroid/widget/TextView;

    .line 2067
    .line 2068
    invoke-direct {v0, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2069
    .line 2070
    .line 2071
    if-eqz v26, :cond_38

    .line 2072
    .line 2073
    invoke-virtual/range {v26 .. v26}, Lm6/n1;->b()I

    .line 2074
    .line 2075
    .line 2076
    move-result v1

    .line 2077
    const-string v3, "\u25b6 "

    .line 2078
    .line 2079
    invoke-static {v1, v3, v12}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 2080
    .line 2081
    .line 2082
    move-result-object v1

    .line 2083
    goto :goto_2b

    .line 2084
    :cond_38
    if-eqz v21, :cond_39

    .line 2085
    .line 2086
    const-string v1, "\u2713 WATCHED"

    .line 2087
    .line 2088
    goto :goto_2b

    .line 2089
    :cond_39
    const-string v1, "\u25b6 PLAY"

    .line 2090
    .line 2091
    :goto_2b
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2092
    .line 2093
    .line 2094
    const/high16 v1, 0x41280000    # 10.5f

    .line 2095
    .line 2096
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2097
    .line 2098
    .line 2099
    invoke-virtual {v0}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 2100
    .line 2101
    .line 2102
    move-result-object v1

    .line 2103
    const/4 v7, 0x1

    .line 2104
    invoke-virtual {v0, v1, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2105
    .line 2106
    .line 2107
    const-string v1, "#6EE7B7"

    .line 2108
    .line 2109
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 2110
    .line 2111
    .line 2112
    move-result v1

    .line 2113
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2114
    .line 2115
    .line 2116
    const v1, 0x7f080060

    .line 2117
    .line 2118
    .line 2119
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 2120
    .line 2121
    .line 2122
    const/16 v1, 0xa

    .line 2123
    .line 2124
    invoke-virtual {v2, v1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2125
    .line 2126
    .line 2127
    move-result v3

    .line 2128
    const/4 v6, 0x4

    .line 2129
    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2130
    .line 2131
    .line 2132
    move-result v9

    .line 2133
    invoke-virtual {v2, v1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2134
    .line 2135
    .line 2136
    move-result v12

    .line 2137
    invoke-virtual {v2, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2138
    .line 2139
    .line 2140
    move-result v1

    .line 2141
    invoke-virtual {v0, v3, v9, v12, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2142
    .line 2143
    .line 2144
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2145
    .line 2146
    .line 2147
    iget-object v0, v14, La7/m;->l:Ljava/lang/Object;

    .line 2148
    .line 2149
    if-eqz v0, :cond_3b

    .line 2150
    .line 2151
    if-eqz v11, :cond_3a

    .line 2152
    .line 2153
    invoke-static {v10, v11}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2154
    .line 2155
    .line 2156
    move-result v0

    .line 2157
    if-eqz v0, :cond_3a

    .line 2158
    .line 2159
    goto :goto_2d

    .line 2160
    :cond_3a
    :goto_2c
    move-object/from16 v0, v31

    .line 2161
    .line 2162
    goto :goto_2e

    .line 2163
    :cond_3b
    :goto_2d
    iput-object v8, v14, La7/m;->l:Ljava/lang/Object;

    .line 2164
    .line 2165
    goto :goto_2c

    .line 2166
    :goto_2e
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2167
    .line 2168
    .line 2169
    move-object v1, v11

    .line 2170
    move-object v11, v0

    .line 2171
    move-object v0, v1

    .line 2172
    move-object/from16 v5, p1

    .line 2173
    .line 2174
    move-object/from16 v13, v19

    .line 2175
    .line 2176
    move/from16 v6, v20

    .line 2177
    .line 2178
    move-object/from16 v22, v27

    .line 2179
    .line 2180
    move-object/from16 v12, v29

    .line 2181
    .line 2182
    move-object/from16 v10, v30

    .line 2183
    .line 2184
    move-object/from16 v8, v32

    .line 2185
    .line 2186
    move-object/from16 v1, v33

    .line 2187
    .line 2188
    move-object/from16 v7, v35

    .line 2189
    .line 2190
    move-object/from16 v9, v36

    .line 2191
    .line 2192
    goto/16 :goto_25

    .line 2193
    .line 2194
    :cond_3c
    move-object/from16 v33, v1

    .line 2195
    .line 2196
    move/from16 v20, v6

    .line 2197
    .line 2198
    move-object v1, v10

    .line 2199
    move-object v0, v11

    .line 2200
    move-object/from16 v29, v12

    .line 2201
    .line 2202
    invoke-virtual {v1, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2203
    .line 2204
    .line 2205
    move-object/from16 v0, v29

    .line 2206
    .line 2207
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2208
    .line 2209
    .line 2210
    new-instance v3, Lm6/v3;

    .line 2211
    .line 2212
    const/4 v4, 0x1

    .line 2213
    move/from16 v5, v20

    .line 2214
    .line 2215
    invoke-direct {v3, v1, v5, v4}, Lm6/v3;-><init>(Landroid/widget/ScrollView;II)V

    .line 2216
    .line 2217
    .line 2218
    invoke-virtual {v1, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 2219
    .line 2220
    .line 2221
    new-instance v1, Landroid/widget/LinearLayout;

    .line 2222
    .line 2223
    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2224
    .line 2225
    .line 2226
    const/4 v3, 0x0

    .line 2227
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2228
    .line 2229
    .line 2230
    const v3, 0x800015

    .line 2231
    .line 2232
    .line 2233
    invoke-virtual {v1, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2234
    .line 2235
    .line 2236
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 2237
    .line 2238
    const/4 v5, -0x2

    .line 2239
    const/4 v13, -0x1

    .line 2240
    invoke-direct {v3, v13, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2241
    .line 2242
    .line 2243
    const/16 v5, 0xa

    .line 2244
    .line 2245
    invoke-virtual {v2, v5}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 2246
    .line 2247
    .line 2248
    move-result v4

    .line 2249
    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 2250
    .line 2251
    invoke-virtual {v1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2252
    .line 2253
    .line 2254
    new-instance v3, Lm6/u3;

    .line 2255
    .line 2256
    const/4 v4, 0x3

    .line 2257
    move-object/from16 v10, v33

    .line 2258
    .line 2259
    invoke-direct {v3, v10, v4}, Lm6/u3;-><init>(La7/m;I)V

    .line 2260
    .line 2261
    .line 2262
    const-string v4, "Back to Series Library"

    .line 2263
    .line 2264
    const v5, 0x7f080055

    .line 2265
    .line 2266
    .line 2267
    const/4 v11, 0x0

    .line 2268
    invoke-static {v2, v4, v5, v11, v3}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 2269
    .line 2270
    .line 2271
    move-result-object v3

    .line 2272
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2273
    .line 2274
    .line 2275
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2276
    .line 2277
    .line 2278
    const/16 v1, 0x2bc

    .line 2279
    .line 2280
    invoke-static {v2, v0, v1}, Landroid/support/v4/media/session/b;->P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;

    .line 2281
    .line 2282
    .line 2283
    move-result-object v0

    .line 2284
    iput-object v0, v10, La7/m;->l:Ljava/lang/Object;

    .line 2285
    .line 2286
    iget-object v0, v14, La7/m;->l:Ljava/lang/Object;

    .line 2287
    .line 2288
    check-cast v0, Landroid/view/View;

    .line 2289
    .line 2290
    if-eqz v0, :cond_3d

    .line 2291
    .line 2292
    new-instance v1, Lm6/w3;

    .line 2293
    .line 2294
    const/4 v2, 0x1

    .line 2295
    invoke-direct {v1, v14, v2}, Lm6/w3;-><init>(La7/m;I)V

    .line 2296
    .line 2297
    .line 2298
    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 2299
    .line 2300
    .line 2301
    :cond_3d
    return-void

    .line 2302
    :cond_3e
    const/16 v21, 0x0

    .line 2303
    .line 2304
    move-object/from16 v5, p1

    .line 2305
    .line 2306
    goto/16 :goto_7
.end method

.method public static final R(Landroid/database/Cursor;)Ljava/util/List;
    .locals 11

    .line 1
    const-string v0, "id"

    .line 2
    .line 3
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const-string v1, "seq"

    .line 8
    .line 9
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const-string v2, "from"

    .line 14
    .line 15
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const-string v3, "to"

    .line 20
    .line 21
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    new-instance v4, Lp6/c;

    .line 26
    .line 27
    const/16 v5, 0xa

    .line 28
    .line 29
    invoke-direct {v4, v5}, Lp6/c;-><init>(I)V

    .line 30
    .line 31
    .line 32
    :goto_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-eqz v5, :cond_0

    .line 37
    .line 38
    new-instance v5, Ls3/c;

    .line 39
    .line 40
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v8

    .line 52
    const-string v9, "cursor.getString(fromColumnIndex)"

    .line 53
    .line 54
    invoke-static {v8, v9}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    const-string v10, "cursor.getString(toColumnIndex)"

    .line 62
    .line 63
    invoke-static {v9, v10}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    invoke-direct {v5, v6, v7, v8, v9}, Ls3/c;-><init>(IILjava/lang/String;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v4, v5}, Lp6/c;->add(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_0
    invoke-virtual {v4}, Lp6/c;->k()V

    .line 74
    .line 75
    .line 76
    const/4 p0, 0x1

    .line 77
    iput-boolean p0, v4, Lp6/c;->m:Z

    .line 78
    .line 79
    iget p0, v4, Lp6/c;->l:I

    .line 80
    .line 81
    if-lez p0, :cond_1

    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_1
    sget-object v4, Lp6/c;->n:Lp6/c;

    .line 85
    .line 86
    :goto_1
    invoke-static {v4}, Lo6/j;->f0(Ljava/util/Collection;)Ljava/util/List;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0
.end method

.method public static final S(Lw3/c;Ljava/lang/String;Z)Ls3/d;
    .locals 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "PRAGMA index_xinfo(`"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, "`)"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {p0, v0}, Lw3/c;->C(Ljava/lang/String;)Landroid/database/Cursor;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    :try_start_0
    const-string v0, "seqno"

    .line 25
    .line 26
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    const-string v1, "cid"

    .line 31
    .line 32
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    const-string v2, "name"

    .line 37
    .line 38
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    const-string v3, "desc"

    .line 43
    .line 44
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    const/4 v4, -0x1

    .line 49
    if-eq v0, v4, :cond_4

    .line 50
    .line 51
    if-eq v1, v4, :cond_4

    .line 52
    .line 53
    if-eq v2, v4, :cond_4

    .line 54
    .line 55
    if-ne v3, v4, :cond_0

    .line 56
    .line 57
    goto :goto_2

    .line 58
    :cond_0
    new-instance v4, Ljava/util/TreeMap;

    .line 59
    .line 60
    invoke-direct {v4}, Ljava/util/TreeMap;-><init>()V

    .line 61
    .line 62
    .line 63
    new-instance v5, Ljava/util/TreeMap;

    .line 64
    .line 65
    invoke-direct {v5}, Ljava/util/TreeMap;-><init>()V

    .line 66
    .line 67
    .line 68
    :goto_0
    invoke-interface {p0}, Landroid/database/Cursor;->moveToNext()Z

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    if-eqz v6, :cond_3

    .line 73
    .line 74
    invoke-interface {p0, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 75
    .line 76
    .line 77
    move-result v6

    .line 78
    if-gez v6, :cond_1

    .line 79
    .line 80
    goto :goto_0

    .line 81
    :cond_1
    invoke-interface {p0, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 82
    .line 83
    .line 84
    move-result v6

    .line 85
    invoke-interface {p0, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    invoke-interface {p0, v3}, Landroid/database/Cursor;->getInt(I)I

    .line 90
    .line 91
    .line 92
    move-result v8

    .line 93
    if-lez v8, :cond_2

    .line 94
    .line 95
    const-string v8, "DESC"

    .line 96
    .line 97
    goto :goto_1

    .line 98
    :catchall_0
    move-exception p1

    .line 99
    goto :goto_3

    .line 100
    :cond_2
    const-string v8, "ASC"

    .line 101
    .line 102
    :goto_1
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 103
    .line 104
    .line 105
    move-result-object v9

    .line 106
    const-string v10, "columnName"

    .line 107
    .line 108
    invoke-static {v7, v10}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v4, v9, v7}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    invoke-virtual {v5, v6, v8}, Ljava/util/TreeMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    goto :goto_0

    .line 122
    :cond_3
    invoke-virtual {v4}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 123
    .line 124
    .line 125
    move-result-object v0

    .line 126
    const-string v1, "columnsMap.values"

    .line 127
    .line 128
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    invoke-static {v0}, Lo6/j;->k0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    invoke-virtual {v5}, Ljava/util/TreeMap;->values()Ljava/util/Collection;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    const-string v2, "ordersMap.values"

    .line 140
    .line 141
    invoke-static {v1, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-static {v1}, Lo6/j;->k0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    new-instance v2, Ls3/d;

    .line 149
    .line 150
    invoke-direct {v2, p1, p2, v0, v1}, Ls3/d;-><init>(Ljava/lang/String;ZLjava/util/List;Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 151
    .line 152
    .line 153
    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    .line 154
    .line 155
    .line 156
    return-object v2

    .line 157
    :cond_4
    :goto_2
    invoke-interface {p0}, Ljava/io/Closeable;->close()V

    .line 158
    .line 159
    .line 160
    const/4 p0, 0x0

    .line 161
    return-object p0

    .line 162
    :goto_3
    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 163
    :catchall_1
    move-exception p2

    .line 164
    invoke-static {p0, p1}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 165
    .line 166
    .line 167
    throw p2
.end method

.method public static final T(Lcom/harindra/iptvpro/PlayerActivity;)V
    .locals 13

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->x()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    goto/16 :goto_1

    .line 13
    .line 14
    :cond_0
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->I:Ld1/k0;

    .line 15
    .line 16
    if-nez v0, :cond_1

    .line 17
    .line 18
    goto/16 :goto_1

    .line 19
    .line 20
    :cond_1
    invoke-virtual {v0}, Ld1/k0;->V0()J

    .line 21
    .line 22
    .line 23
    move-result-wide v3

    .line 24
    invoke-virtual {v0}, Ld1/k0;->getDuration()J

    .line 25
    .line 26
    .line 27
    move-result-wide v0

    .line 28
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    const-wide/16 v5, 0x0

    .line 33
    .line 34
    cmp-long v7, v0, v5

    .line 35
    .line 36
    if-lez v7, :cond_2

    .line 37
    .line 38
    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    cmp-long v0, v0, v7

    .line 44
    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/4 v2, 0x0

    .line 49
    :goto_0
    if-eqz v2, :cond_3

    .line 50
    .line 51
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 52
    .line 53
    .line 54
    move-result-wide v5

    .line 55
    :cond_3
    const-wide/16 v0, 0x2710

    .line 56
    .line 57
    cmp-long v0, v3, v0

    .line 58
    .line 59
    if-gez v0, :cond_4

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_4
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->E1:Lm6/x1;

    .line 63
    .line 64
    sget-object v1, Lm6/h5;->a:[I

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    aget v0, v1, v0

    .line 71
    .line 72
    const/4 v1, 0x1

    .line 73
    if-eq v0, v1, :cond_9

    .line 74
    .line 75
    const/4 v1, 0x2

    .line 76
    if-eq v0, v1, :cond_6

    .line 77
    .line 78
    const/4 p0, 0x3

    .line 79
    if-eq v0, p0, :cond_b

    .line 80
    .line 81
    const/4 p0, 0x4

    .line 82
    if-eq v0, p0, :cond_b

    .line 83
    .line 84
    const/4 p0, 0x5

    .line 85
    if-ne v0, p0, :cond_5

    .line 86
    .line 87
    goto :goto_1

    .line 88
    :cond_5
    new-instance p0, Lb5/f0;

    .line 89
    .line 90
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 91
    .line 92
    .line 93
    throw p0

    .line 94
    :cond_6
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->K1:Lm6/l7;

    .line 95
    .line 96
    if-nez v0, :cond_7

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :cond_7
    iget-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->I1:Lm6/m7;

    .line 100
    .line 101
    if-nez v1, :cond_8

    .line 102
    .line 103
    goto :goto_1

    .line 104
    :cond_8
    move-object v2, v1

    .line 105
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    iget-object v7, v0, Lm6/l7;->a:Lm6/n;

    .line 110
    .line 111
    iget-object v7, v7, Lm6/n;->a:Ljava/lang/String;

    .line 112
    .line 113
    iget-object v2, v2, Lm6/m7;->a:Ljava/lang/String;

    .line 114
    .line 115
    iget v8, v0, Lm6/l7;->d:I

    .line 116
    .line 117
    iget v9, v0, Lm6/l7;->e:I

    .line 118
    .line 119
    sget-object v10, Lm6/c0;->XTREAM_SERIES_EPISODE:Lm6/c0;

    .line 120
    .line 121
    iget-object v11, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 122
    .line 123
    move-object v12, v7

    .line 124
    move-object v7, v2

    .line 125
    move-object v2, v12

    .line 126
    invoke-virtual/range {v1 .. v11}, Lm6/m6;->s0(Ljava/lang/String;JJLjava/lang/String;IILm6/c0;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :cond_9
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->F1:Lm6/n;

    .line 131
    .line 132
    if-nez v0, :cond_a

    .line 133
    .line 134
    goto :goto_1

    .line 135
    :cond_a
    iget-object v1, v0, Lm6/n;->i:Lm6/c0;

    .line 136
    .line 137
    sget-object v10, Lm6/c0;->XTREAM_VOD_MOVIE:Lm6/c0;

    .line 138
    .line 139
    if-ne v1, v10, :cond_b

    .line 140
    .line 141
    invoke-virtual {p0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 142
    .line 143
    .line 144
    move-result-object v1

    .line 145
    iget-object v2, v0, Lm6/n;->a:Ljava/lang/String;

    .line 146
    .line 147
    const/4 v9, 0x0

    .line 148
    iget-object v11, p0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 149
    .line 150
    const-string v7, ""

    .line 151
    .line 152
    const/4 v8, 0x0

    .line 153
    invoke-virtual/range {v1 .. v11}, Lm6/m6;->s0(Ljava/lang/String;JJLjava/lang/String;IILm6/c0;Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    :cond_b
    :goto_1
    return-void
.end method

.method public static final W(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;IILz6/a;Ljava/lang/String;IILz6/l;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p6

    .line 4
    .line 5
    move-object/from16 v2, p9

    .line 6
    .line 7
    const-string v3, "<this>"

    .line 8
    .line 9
    invoke-static {v0, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v3, "title"

    .line 13
    .line 14
    move-object/from16 v4, p2

    .line 15
    .line 16
    invoke-static {v4, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-string v3, "subtitle"

    .line 20
    .line 21
    move-object/from16 v5, p3

    .line 22
    .line 23
    invoke-static {v5, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v3, "badgeText"

    .line 27
    .line 28
    move-object/from16 v6, p4

    .line 29
    .line 30
    invoke-static {v6, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    new-instance v3, La7/m;

    .line 34
    .line 35
    const/4 v7, 0x0

    .line 36
    invoke-direct {v3, v7}, La7/m;-><init>(Z)V

    .line 37
    .line 38
    .line 39
    new-instance v7, Landroid/widget/LinearLayout;

    .line 40
    .line 41
    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 42
    .line 43
    .line 44
    const/4 v8, 0x1

    .line 45
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 46
    .line 47
    .line 48
    const v9, 0x7f080059

    .line 49
    .line 50
    .line 51
    invoke-virtual {v7, v9}, Landroid/view/View;->setBackgroundResource(I)V

    .line 52
    .line 53
    .line 54
    const/16 v9, 0x12

    .line 55
    .line 56
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 57
    .line 58
    .line 59
    move-result v10

    .line 60
    const/16 v11, 0x10

    .line 61
    .line 62
    invoke-virtual {v0, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 63
    .line 64
    .line 65
    move-result v12

    .line 66
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 67
    .line 68
    .line 69
    move-result v9

    .line 70
    invoke-virtual {v0, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 71
    .line 72
    .line 73
    move-result v13

    .line 74
    invoke-virtual {v7, v10, v12, v9, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 75
    .line 76
    .line 77
    invoke-static/range {p0 .. p4}, Landroid/support/v4/media/session/b;->b(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 78
    .line 79
    .line 80
    move-result-object v4

    .line 81
    invoke-virtual {v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 82
    .line 83
    .line 84
    new-instance v4, Landroid/widget/LinearLayout;

    .line 85
    .line 86
    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 90
    .line 91
    .line 92
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 93
    .line 94
    const/4 v6, -0x1

    .line 95
    const/4 v9, -0x2

    .line 96
    invoke-direct {v5, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 97
    .line 98
    .line 99
    const/16 v10, 0xc

    .line 100
    .line 101
    invoke-virtual {v0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 102
    .line 103
    .line 104
    move-result v12

    .line 105
    iput v12, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 106
    .line 107
    const/16 v12, 0xe

    .line 108
    .line 109
    invoke-virtual {v0, v12}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 110
    .line 111
    .line 112
    move-result v12

    .line 113
    iput v12, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 114
    .line 115
    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 116
    .line 117
    .line 118
    new-instance v5, Ljava/util/ArrayList;

    .line 119
    .line 120
    invoke-interface/range {p5 .. p5}, Ljava/util/List;->size()I

    .line 121
    .line 122
    .line 123
    move-result v12

    .line 124
    invoke-direct {v5, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 125
    .line 126
    .line 127
    invoke-interface/range {p5 .. p5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 128
    .line 129
    .line 130
    move-result-object v12

    .line 131
    const/4 v14, 0x0

    .line 132
    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 133
    .line 134
    .line 135
    move-result v15

    .line 136
    if-eqz v15, :cond_2

    .line 137
    .line 138
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v15

    .line 142
    add-int/lit8 v16, v14, 0x1

    .line 143
    .line 144
    if-ltz v14, :cond_1

    .line 145
    .line 146
    check-cast v15, Lm6/u0;

    .line 147
    .line 148
    new-instance v11, Landroid/widget/TextView;

    .line 149
    .line 150
    invoke-direct {v11, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 151
    .line 152
    .line 153
    iget-object v13, v15, Lm6/u0;->a:Ljava/lang/String;

    .line 154
    .line 155
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 156
    .line 157
    .line 158
    const/high16 v13, 0x41280000    # 10.5f

    .line 159
    .line 160
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {v11}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 164
    .line 165
    .line 166
    move-result-object v13

    .line 167
    invoke-virtual {v11, v13, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 168
    .line 169
    .line 170
    const-string v13, "#7DD3FC"

    .line 171
    .line 172
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 173
    .line 174
    .line 175
    move-result v13

    .line 176
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 177
    .line 178
    .line 179
    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    .line 180
    .line 181
    invoke-direct {v13, v9, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 182
    .line 183
    .line 184
    if-lez v14, :cond_0

    .line 185
    .line 186
    const/16 v14, 0x8

    .line 187
    .line 188
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 189
    .line 190
    .line 191
    move-result v14

    .line 192
    iput v14, v13, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 193
    .line 194
    :cond_0
    const/4 v14, 0x4

    .line 195
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 196
    .line 197
    .line 198
    move-result v14

    .line 199
    iput v14, v13, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 200
    .line 201
    invoke-virtual {v11, v13}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v4, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 205
    .line 206
    .line 207
    new-instance v11, Landroid/widget/EditText;

    .line 208
    .line 209
    invoke-direct {v11, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 210
    .line 211
    .line 212
    iget-object v13, v15, Lm6/u0;->b:Ljava/lang/String;

    .line 213
    .line 214
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 215
    .line 216
    .line 217
    iget-object v13, v15, Lm6/u0;->d:Ljava/lang/String;

    .line 218
    .line 219
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v11, v8}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 223
    .line 224
    .line 225
    iget v13, v15, Lm6/u0;->e:I

    .line 226
    .line 227
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setInputType(I)V

    .line 228
    .line 229
    .line 230
    const/high16 v13, 0x41500000    # 13.0f

    .line 231
    .line 232
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setTextSize(F)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 236
    .line 237
    .line 238
    const-string v13, "#94A3B8"

    .line 239
    .line 240
    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 241
    .line 242
    .line 243
    move-result v13

    .line 244
    invoke-virtual {v11, v13}, Landroid/widget/TextView;->setHintTextColor(I)V

    .line 245
    .line 246
    .line 247
    const v13, 0x7f08005e

    .line 248
    .line 249
    .line 250
    invoke-virtual {v11, v13}, Landroid/view/View;->setBackgroundResource(I)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 254
    .line 255
    .line 256
    move-result v13

    .line 257
    const/16 v14, 0xa

    .line 258
    .line 259
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 260
    .line 261
    .line 262
    move-result v8

    .line 263
    invoke-virtual {v0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 264
    .line 265
    .line 266
    move-result v9

    .line 267
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 268
    .line 269
    .line 270
    move-result v10

    .line 271
    invoke-virtual {v11, v13, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 272
    .line 273
    .line 274
    iget v8, v15, Lm6/u0;->c:I

    .line 275
    .line 276
    const/4 v9, 0x0

    .line 277
    invoke-virtual {v11, v8, v9, v9, v9}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 281
    .line 282
    .line 283
    move-result v8

    .line 284
    invoke-virtual {v11, v8}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 285
    .line 286
    .line 287
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 288
    .line 289
    const/16 v9, 0x2c

    .line 290
    .line 291
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 292
    .line 293
    .line 294
    move-result v9

    .line 295
    invoke-direct {v8, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 296
    .line 297
    .line 298
    invoke-virtual {v11, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    invoke-virtual {v4, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 305
    .line 306
    .line 307
    move/from16 v14, v16

    .line 308
    .line 309
    const/4 v8, 0x1

    .line 310
    const/4 v9, -0x2

    .line 311
    const/16 v10, 0xc

    .line 312
    .line 313
    const/16 v11, 0x10

    .line 314
    .line 315
    goto/16 :goto_0

    .line 316
    .line 317
    :cond_1
    invoke-static {}, Lo6/k;->N()V

    .line 318
    .line 319
    .line 320
    const/4 v0, 0x0

    .line 321
    throw v0

    .line 322
    :cond_2
    invoke-virtual {v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 323
    .line 324
    .line 325
    new-instance v4, Landroid/widget/LinearLayout;

    .line 326
    .line 327
    invoke-direct {v4, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 328
    .line 329
    .line 330
    const/4 v9, 0x0

    .line 331
    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 332
    .line 333
    .line 334
    const/16 v8, 0x10

    .line 335
    .line 336
    invoke-virtual {v4, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 337
    .line 338
    .line 339
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 340
    .line 341
    const/4 v9, -0x2

    .line 342
    invoke-direct {v8, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 343
    .line 344
    .line 345
    invoke-virtual {v4, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 346
    .line 347
    .line 348
    if-eqz v1, :cond_4

    .line 349
    .line 350
    invoke-static {v1}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 351
    .line 352
    .line 353
    move-result v6

    .line 354
    if-eqz v6, :cond_3

    .line 355
    .line 356
    goto :goto_1

    .line 357
    :cond_3
    if-eqz v2, :cond_4

    .line 358
    .line 359
    new-instance v6, Lm6/x2;

    .line 360
    .line 361
    const/4 v8, 0x2

    .line 362
    invoke-direct {v6, v3, v8, v2}, Lm6/x2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 363
    .line 364
    .line 365
    move/from16 v2, p7

    .line 366
    .line 367
    move/from16 v8, p8

    .line 368
    .line 369
    invoke-static {v0, v1, v2, v8, v6}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 370
    .line 371
    .line 372
    move-result-object v1

    .line 373
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 374
    .line 375
    .line 376
    move-result-object v2

    .line 377
    const-string v6, "null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams"

    .line 378
    .line 379
    invoke-static {v2, v6}, La7/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 383
    .line 384
    const/4 v9, 0x0

    .line 385
    invoke-virtual {v2, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 386
    .line 387
    .line 388
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 389
    .line 390
    .line 391
    goto :goto_2

    .line 392
    :cond_4
    :goto_1
    const/4 v9, 0x0

    .line 393
    :goto_2
    new-instance v1, Landroid/view/View;

    .line 394
    .line 395
    invoke-direct {v1, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 396
    .line 397
    .line 398
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 399
    .line 400
    const/high16 v6, 0x3f800000    # 1.0f

    .line 401
    .line 402
    const/4 v8, 0x1

    .line 403
    invoke-direct {v2, v9, v8, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 404
    .line 405
    .line 406
    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 407
    .line 408
    .line 409
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 410
    .line 411
    .line 412
    new-instance v1, Lm6/u3;

    .line 413
    .line 414
    const/4 v2, 0x0

    .line 415
    invoke-direct {v1, v3, v2}, Lm6/u3;-><init>(La7/m;I)V

    .line 416
    .line 417
    .line 418
    const-string v2, "Cancel"

    .line 419
    .line 420
    const v6, 0x7f080055

    .line 421
    .line 422
    .line 423
    invoke-static {v0, v2, v6, v9, v1}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 424
    .line 425
    .line 426
    move-result-object v1

    .line 427
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 428
    .line 429
    .line 430
    new-instance v1, Lm6/y2;

    .line 431
    .line 432
    const/4 v2, 0x1

    .line 433
    move-object/from16 v6, p13

    .line 434
    .line 435
    invoke-direct {v1, v5, v3, v6, v2}, Lm6/y2;-><init>(Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Object;I)V

    .line 436
    .line 437
    .line 438
    move-object/from16 v2, p10

    .line 439
    .line 440
    move/from16 v6, p11

    .line 441
    .line 442
    move/from16 v8, p12

    .line 443
    .line 444
    invoke-static {v0, v2, v6, v8, v1}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 445
    .line 446
    .line 447
    move-result-object v1

    .line 448
    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 449
    .line 450
    .line 451
    invoke-virtual {v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 452
    .line 453
    .line 454
    const/16 v1, 0x21c

    .line 455
    .line 456
    invoke-static {v0, v7, v1}, Landroid/support/v4/media/session/b;->P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;

    .line 457
    .line 458
    .line 459
    move-result-object v0

    .line 460
    iput-object v0, v3, La7/m;->l:Ljava/lang/Object;

    .line 461
    .line 462
    invoke-static {v5}, Lo6/j;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 463
    .line 464
    .line 465
    move-result-object v0

    .line 466
    check-cast v0, Landroid/widget/EditText;

    .line 467
    .line 468
    if-eqz v0, :cond_5

    .line 469
    .line 470
    new-instance v1, Landroidx/lifecycle/z;

    .line 471
    .line 472
    const/16 v2, 0x18

    .line 473
    .line 474
    invoke-direct {v1, v2, v5}, Landroidx/lifecycle/z;-><init>(ILjava/lang/Object;)V

    .line 475
    .line 476
    .line 477
    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 478
    .line 479
    .line 480
    :cond_5
    return-void
.end method

.method public static synthetic X(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Lz6/a;Ljava/lang/String;IILz6/l;I)V
    .locals 17

    .line 1
    move/from16 v0, p12

    .line 2
    .line 3
    and-int/lit8 v1, v0, 0x20

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    move-object v9, v2

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    move-object/from16 v9, p6

    .line 11
    .line 12
    :goto_0
    and-int/lit16 v1, v0, 0x100

    .line 13
    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    move-object v12, v2

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    move-object/from16 v12, p7

    .line 19
    .line 20
    :goto_1
    and-int/lit16 v0, v0, 0x800

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    move v15, v0

    .line 26
    goto :goto_2

    .line 27
    :cond_2
    move/from16 v15, p10

    .line 28
    .line 29
    :goto_2
    const v10, 0x7f080052

    .line 30
    .line 31
    .line 32
    const/4 v11, 0x0

    .line 33
    move-object/from16 v3, p0

    .line 34
    .line 35
    move/from16 v4, p1

    .line 36
    .line 37
    move-object/from16 v5, p2

    .line 38
    .line 39
    move-object/from16 v6, p3

    .line 40
    .line 41
    move-object/from16 v7, p4

    .line 42
    .line 43
    move-object/from16 v8, p5

    .line 44
    .line 45
    move-object/from16 v13, p8

    .line 46
    .line 47
    move/from16 v14, p9

    .line 48
    .line 49
    move-object/from16 v16, p11

    .line 50
    .line 51
    invoke-static/range {v3 .. v16}, Landroid/support/v4/media/session/b;->W(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;IILz6/a;Ljava/lang/String;IILz6/l;)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public static final Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    const-string v2, "<this>"

    .line 6
    .line 7
    invoke-static {v0, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const-string v2, "title"

    .line 11
    .line 12
    invoke-static {v1, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    const-string v3, "subtitle"

    .line 16
    .line 17
    move-object/from16 v4, p3

    .line 18
    .line 19
    invoke-static {v4, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    const-string v5, "badgeText"

    .line 23
    .line 24
    move-object/from16 v6, p4

    .line 25
    .line 26
    invoke-static {v6, v5}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    new-instance v5, La7/m;

    .line 30
    .line 31
    const/4 v7, 0x0

    .line 32
    invoke-direct {v5, v7}, La7/m;-><init>(Z)V

    .line 33
    .line 34
    .line 35
    new-instance v7, Landroid/widget/LinearLayout;

    .line 36
    .line 37
    invoke-direct {v7, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 38
    .line 39
    .line 40
    const/4 v8, 0x1

    .line 41
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 42
    .line 43
    .line 44
    const v9, 0x7f080059

    .line 45
    .line 46
    .line 47
    invoke-virtual {v7, v9}, Landroid/view/View;->setBackgroundResource(I)V

    .line 48
    .line 49
    .line 50
    const/16 v9, 0x12

    .line 51
    .line 52
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 53
    .line 54
    .line 55
    move-result v10

    .line 56
    const/16 v11, 0x10

    .line 57
    .line 58
    invoke-virtual {v0, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 59
    .line 60
    .line 61
    move-result v12

    .line 62
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 63
    .line 64
    .line 65
    move-result v9

    .line 66
    invoke-virtual {v0, v11}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 67
    .line 68
    .line 69
    move-result v13

    .line 70
    invoke-virtual {v7, v10, v12, v9, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 71
    .line 72
    .line 73
    invoke-static/range {p0 .. p4}, Landroid/support/v4/media/session/b;->b(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    invoke-virtual {v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0}, Li/k;->getResources()Landroid/content/res/Resources;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    iget v4, v4, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 89
    .line 90
    int-to-float v4, v4

    .line 91
    const v6, 0x3f0f5c29    # 0.56f

    .line 92
    .line 93
    .line 94
    mul-float/2addr v4, v6

    .line 95
    float-to-int v4, v4

    .line 96
    const/16 v6, 0xb4

    .line 97
    .line 98
    invoke-virtual {v0, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 99
    .line 100
    .line 101
    move-result v6

    .line 102
    if-ge v4, v6, :cond_0

    .line 103
    .line 104
    move v4, v6

    .line 105
    :cond_0
    new-instance v6, Landroid/widget/ScrollView;

    .line 106
    .line 107
    invoke-direct {v6, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 108
    .line 109
    .line 110
    const/4 v9, 0x0

    .line 111
    invoke-virtual {v6, v9}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 112
    .line 113
    .line 114
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 115
    .line 116
    const/4 v12, -0x1

    .line 117
    const/4 v13, -0x2

    .line 118
    invoke-direct {v10, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 119
    .line 120
    .line 121
    const/16 v14, 0xc

    .line 122
    .line 123
    invoke-virtual {v0, v14}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 124
    .line 125
    .line 126
    move-result v15

    .line 127
    iput v15, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 128
    .line 129
    const/16 v15, 0xa

    .line 130
    .line 131
    invoke-virtual {v0, v15}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 132
    .line 133
    .line 134
    move-result v12

    .line 135
    iput v12, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 136
    .line 137
    invoke-virtual {v6, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 138
    .line 139
    .line 140
    new-instance v10, Landroid/widget/LinearLayout;

    .line 141
    .line 142
    invoke-direct {v10, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v10, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 146
    .line 147
    .line 148
    new-instance v12, La7/m;

    .line 149
    .line 150
    const/4 v13, 0x0

    .line 151
    invoke-direct {v12, v13}, La7/m;-><init>(Z)V

    .line 152
    .line 153
    .line 154
    invoke-interface/range {p5 .. p5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v13

    .line 158
    move v15, v9

    .line 159
    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    .line 160
    .line 161
    .line 162
    move-result v16

    .line 163
    if-eqz v16, :cond_12

    .line 164
    .line 165
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v16

    .line 169
    add-int/lit8 v14, v15, 0x1

    .line 170
    .line 171
    if-ltz v15, :cond_11

    .line 172
    .line 173
    move-object/from16 v8, v16

    .line 174
    .line 175
    check-cast v8, Lm6/v0;

    .line 176
    .line 177
    new-instance v11, Landroid/widget/LinearLayout;

    .line 178
    .line 179
    invoke-direct {v11, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 183
    .line 184
    .line 185
    const/16 v9, 0x10

    .line 186
    .line 187
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 188
    .line 189
    .line 190
    const/4 v9, 0x1

    .line 191
    invoke-virtual {v11, v9}, Landroid/view/View;->setFocusable(Z)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v11, v9}, Landroid/view/View;->setClickable(Z)V

    .line 195
    .line 196
    .line 197
    iget-boolean v9, v8, Lm6/v0;->e:Z

    .line 198
    .line 199
    move-object/from16 v19, v13

    .line 200
    .line 201
    iget-object v13, v8, Lm6/v0;->c:Ljava/lang/String;

    .line 202
    .line 203
    iget-object v1, v8, Lm6/v0;->b:Ljava/lang/String;

    .line 204
    .line 205
    move/from16 v20, v4

    .line 206
    .line 207
    iget-object v4, v8, Lm6/v0;->d:Ljava/lang/String;

    .line 208
    .line 209
    invoke-virtual {v11, v9}, Landroid/view/View;->setSelected(Z)V

    .line 210
    .line 211
    .line 212
    if-eqz v9, :cond_1

    .line 213
    .line 214
    move/from16 v21, v9

    .line 215
    .line 216
    iget-object v9, v0, Lcom/harindra/iptvpro/PlayerActivity;->v2:Ljava/util/List;

    .line 217
    .line 218
    move-object/from16 v22, v7

    .line 219
    .line 220
    iget v7, v0, Lcom/harindra/iptvpro/PlayerActivity;->w2:I

    .line 221
    .line 222
    invoke-interface {v9, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object v7

    .line 226
    check-cast v7, Lm6/j8;

    .line 227
    .line 228
    iget v7, v7, Lm6/j8;->f:I

    .line 229
    .line 230
    goto :goto_1

    .line 231
    :cond_1
    move-object/from16 v22, v7

    .line 232
    .line 233
    move/from16 v21, v9

    .line 234
    .line 235
    const v7, 0x7f08005b

    .line 236
    .line 237
    .line 238
    :goto_1
    invoke-virtual {v11, v7}, Landroid/view/View;->setBackgroundResource(I)V

    .line 239
    .line 240
    .line 241
    const/16 v7, 0xc

    .line 242
    .line 243
    invoke-virtual {v0, v7}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 244
    .line 245
    .line 246
    move-result v9

    .line 247
    move-object/from16 v17, v6

    .line 248
    .line 249
    move-object/from16 p4, v10

    .line 250
    .line 251
    const/16 v6, 0xa

    .line 252
    .line 253
    invoke-virtual {v0, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 254
    .line 255
    .line 256
    move-result v10

    .line 257
    move-object/from16 v23, v12

    .line 258
    .line 259
    invoke-virtual {v0, v7}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 260
    .line 261
    .line 262
    move-result v12

    .line 263
    invoke-virtual {v0, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 264
    .line 265
    .line 266
    move-result v7

    .line 267
    invoke-virtual {v11, v9, v10, v12, v7}, Landroid/view/View;->setPadding(IIII)V

    .line 268
    .line 269
    .line 270
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    .line 271
    .line 272
    const/4 v9, -0x2

    .line 273
    const/4 v10, -0x1

    .line 274
    invoke-direct {v7, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 275
    .line 276
    .line 277
    invoke-static/range {p5 .. p5}, Lo6/k;->J(Ljava/util/List;)I

    .line 278
    .line 279
    .line 280
    move-result v9

    .line 281
    if-ge v15, v9, :cond_2

    .line 282
    .line 283
    const/4 v9, 0x7

    .line 284
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 285
    .line 286
    .line 287
    move-result v9

    .line 288
    iput v9, v7, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 289
    .line 290
    :cond_2
    invoke-virtual {v11, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 291
    .line 292
    .line 293
    new-instance v7, Lm6/w1;

    .line 294
    .line 295
    const v9, 0x3f828f5c    # 1.02f

    .line 296
    .line 297
    .line 298
    invoke-direct {v7, v9, v0}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v11, v7}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 302
    .line 303
    .line 304
    new-instance v7, Lm6/x;

    .line 305
    .line 306
    const/4 v9, 0x1

    .line 307
    invoke-direct {v7, v5, v9, v8}, Lm6/x;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v11, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 311
    .line 312
    .line 313
    new-instance v7, Landroid/widget/ImageView;

    .line 314
    .line 315
    invoke-direct {v7, v0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 316
    .line 317
    .line 318
    iget v8, v8, Lm6/v0;->a:I

    .line 319
    .line 320
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 321
    .line 322
    .line 323
    const v8, 0x7f080057

    .line 324
    .line 325
    .line 326
    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundResource(I)V

    .line 327
    .line 328
    .line 329
    const/4 v8, 0x6

    .line 330
    invoke-virtual {v0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 331
    .line 332
    .line 333
    move-result v9

    .line 334
    invoke-virtual {v0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 335
    .line 336
    .line 337
    move-result v10

    .line 338
    invoke-virtual {v0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 339
    .line 340
    .line 341
    move-result v12

    .line 342
    invoke-virtual {v0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 343
    .line 344
    .line 345
    move-result v8

    .line 346
    invoke-virtual {v7, v9, v10, v12, v8}, Landroid/view/View;->setPadding(IIII)V

    .line 347
    .line 348
    .line 349
    sget-object v8, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    .line 350
    .line 351
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 352
    .line 353
    .line 354
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 355
    .line 356
    const/16 v9, 0x24

    .line 357
    .line 358
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 359
    .line 360
    .line 361
    move-result v10

    .line 362
    invoke-virtual {v0, v9}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 363
    .line 364
    .line 365
    move-result v9

    .line 366
    invoke-direct {v8, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v7, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {v11, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 373
    .line 374
    .line 375
    new-instance v8, Landroid/widget/LinearLayout;

    .line 376
    .line 377
    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 378
    .line 379
    .line 380
    const/4 v9, 0x1

    .line 381
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 382
    .line 383
    .line 384
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    .line 385
    .line 386
    const/high16 v10, 0x3f800000    # 1.0f

    .line 387
    .line 388
    const/4 v12, -0x2

    .line 389
    const/4 v15, 0x0

    .line 390
    invoke-direct {v9, v15, v12, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 391
    .line 392
    .line 393
    const/16 v10, 0xb

    .line 394
    .line 395
    invoke-virtual {v0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 396
    .line 397
    .line 398
    move-result v10

    .line 399
    invoke-virtual {v9, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 400
    .line 401
    .line 402
    const/16 v10, 0x8

    .line 403
    .line 404
    invoke-virtual {v0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 405
    .line 406
    .line 407
    move-result v10

    .line 408
    invoke-virtual {v9, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 412
    .line 413
    .line 414
    new-instance v9, Landroid/widget/TextView;

    .line 415
    .line 416
    invoke-direct {v9, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v9, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 420
    .line 421
    .line 422
    const/high16 v10, 0x41580000    # 13.5f

    .line 423
    .line 424
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v9}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 428
    .line 429
    .line 430
    move-result-object v10

    .line 431
    const/4 v12, 0x1

    .line 432
    invoke-virtual {v9, v10, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 433
    .line 434
    .line 435
    const/4 v10, -0x1

    .line 436
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 437
    .line 438
    .line 439
    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 440
    .line 441
    .line 442
    sget-object v10, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 443
    .line 444
    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 445
    .line 446
    .line 447
    new-instance v12, Landroid/widget/TextView;

    .line 448
    .line 449
    invoke-direct {v12, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 450
    .line 451
    .line 452
    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 453
    .line 454
    .line 455
    const/high16 v15, 0x41300000    # 11.0f

    .line 456
    .line 457
    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 458
    .line 459
    .line 460
    if-eqz v21, :cond_3

    .line 461
    .line 462
    const-string v15, "#FEF08A"

    .line 463
    .line 464
    :goto_2
    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 465
    .line 466
    .line 467
    move-result v15

    .line 468
    goto :goto_3

    .line 469
    :cond_3
    const-string v15, "#CBD5E1"

    .line 470
    .line 471
    goto :goto_2

    .line 472
    :goto_3
    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setTextColor(I)V

    .line 473
    .line 474
    .line 475
    const/4 v15, 0x2

    .line 476
    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 477
    .line 478
    .line 479
    invoke-virtual {v12, v10}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 480
    .line 481
    .line 482
    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {v8, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 486
    .line 487
    .line 488
    invoke-virtual {v11, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 489
    .line 490
    .line 491
    invoke-virtual {v7, v15}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 492
    .line 493
    .line 494
    const/4 v7, 0x4

    .line 495
    invoke-virtual {v8, v7}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 496
    .line 497
    .line 498
    invoke-interface/range {p5 .. p5}, Ljava/util/List;->size()I

    .line 499
    .line 500
    .line 501
    move-result v8

    .line 502
    invoke-static {v1, v2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 503
    .line 504
    .line 505
    invoke-static {v13, v3}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 506
    .line 507
    .line 508
    const-string v9, "badge"

    .line 509
    .line 510
    invoke-static {v4, v9}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 511
    .line 512
    .line 513
    new-instance v9, Ljava/util/ArrayList;

    .line 514
    .line 515
    const/4 v10, 0x5

    .line 516
    invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 517
    .line 518
    .line 519
    invoke-static {v1}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 520
    .line 521
    .line 522
    move-result-object v1

    .line 523
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 524
    .line 525
    .line 526
    move-result v10

    .line 527
    if-lez v10, :cond_4

    .line 528
    .line 529
    goto :goto_4

    .line 530
    :cond_4
    const/4 v1, 0x0

    .line 531
    :goto_4
    if-eqz v1, :cond_5

    .line 532
    .line 533
    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 534
    .line 535
    .line 536
    :cond_5
    invoke-static {v13}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object v1

    .line 540
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 541
    .line 542
    .line 543
    move-result v10

    .line 544
    if-lez v10, :cond_6

    .line 545
    .line 546
    goto :goto_5

    .line 547
    :cond_6
    const/4 v1, 0x0

    .line 548
    :goto_5
    if-eqz v1, :cond_7

    .line 549
    .line 550
    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 551
    .line 552
    .line 553
    :cond_7
    invoke-static {v4}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 554
    .line 555
    .line 556
    move-result-object v1

    .line 557
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 558
    .line 559
    .line 560
    move-result v10

    .line 561
    if-lez v10, :cond_8

    .line 562
    .line 563
    goto :goto_6

    .line 564
    :cond_8
    const/4 v1, 0x0

    .line 565
    :goto_6
    if-eqz v1, :cond_9

    .line 566
    .line 567
    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 568
    .line 569
    .line 570
    :cond_9
    if-eqz v21, :cond_a

    .line 571
    .line 572
    const-string v1, "selected"

    .line 573
    .line 574
    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 575
    .line 576
    .line 577
    :cond_a
    const/4 v12, 0x1

    .line 578
    if-le v8, v12, :cond_b

    .line 579
    .line 580
    new-instance v1, Ljava/lang/StringBuilder;

    .line 581
    .line 582
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 583
    .line 584
    .line 585
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 586
    .line 587
    .line 588
    const-string v10, " of "

    .line 589
    .line 590
    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 591
    .line 592
    .line 593
    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 594
    .line 595
    .line 596
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 597
    .line 598
    .line 599
    move-result-object v1

    .line 600
    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 601
    .line 602
    .line 603
    :cond_b
    const-string v1, ", "

    .line 604
    .line 605
    const/16 v8, 0x3e

    .line 606
    .line 607
    const/4 v10, 0x0

    .line 608
    invoke-static {v9, v1, v10, v8}, Lo6/j;->b0(Ljava/lang/Iterable;Ljava/lang/String;Lz6/l;I)Ljava/lang/String;

    .line 609
    .line 610
    .line 611
    move-result-object v1

    .line 612
    const-string v8, "description"

    .line 613
    .line 614
    invoke-static {v1, v8}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 615
    .line 616
    .line 617
    invoke-virtual {v11, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 618
    .line 619
    .line 620
    sget-object v1, Lm6/h8;->a:Lm6/h8;

    .line 621
    .line 622
    invoke-virtual {v11, v1}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    .line 623
    .line 624
    .line 625
    invoke-static {v4}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 626
    .line 627
    .line 628
    move-result v1

    .line 629
    if-nez v1, :cond_e

    .line 630
    .line 631
    new-instance v1, Landroid/widget/TextView;

    .line 632
    .line 633
    invoke-direct {v1, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 634
    .line 635
    .line 636
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 637
    .line 638
    .line 639
    const/high16 v4, 0x41280000    # 10.5f

    .line 640
    .line 641
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 642
    .line 643
    .line 644
    invoke-virtual {v1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 645
    .line 646
    .line 647
    move-result-object v4

    .line 648
    const/4 v9, 0x1

    .line 649
    invoke-virtual {v1, v4, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 650
    .line 651
    .line 652
    if-eqz v21, :cond_c

    .line 653
    .line 654
    const-string v4, "#6EE7B7"

    .line 655
    .line 656
    :goto_7
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 657
    .line 658
    .line 659
    move-result v4

    .line 660
    goto :goto_8

    .line 661
    :cond_c
    const-string v4, "#38BDF8"

    .line 662
    .line 663
    goto :goto_7

    .line 664
    :goto_8
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextColor(I)V

    .line 665
    .line 666
    .line 667
    if-eqz v21, :cond_d

    .line 668
    .line 669
    const v4, 0x7f080060

    .line 670
    .line 671
    .line 672
    goto :goto_9

    .line 673
    :cond_d
    const v4, 0x7f08004f

    .line 674
    .line 675
    .line 676
    :goto_9
    invoke-virtual {v1, v4}, Landroid/view/View;->setBackgroundResource(I)V

    .line 677
    .line 678
    .line 679
    const/16 v4, 0x9

    .line 680
    .line 681
    invoke-virtual {v0, v4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 682
    .line 683
    .line 684
    move-result v8

    .line 685
    invoke-virtual {v0, v7}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 686
    .line 687
    .line 688
    move-result v10

    .line 689
    invoke-virtual {v0, v4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 690
    .line 691
    .line 692
    move-result v4

    .line 693
    invoke-virtual {v0, v7}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 694
    .line 695
    .line 696
    move-result v7

    .line 697
    invoke-virtual {v1, v8, v10, v4, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 698
    .line 699
    .line 700
    invoke-virtual {v1, v15}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 701
    .line 702
    .line 703
    invoke-virtual {v11, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 704
    .line 705
    .line 706
    :goto_a
    move-object/from16 v1, v23

    .line 707
    .line 708
    goto :goto_b

    .line 709
    :cond_e
    const/4 v9, 0x1

    .line 710
    goto :goto_a

    .line 711
    :goto_b
    iget-object v4, v1, La7/m;->l:Ljava/lang/Object;

    .line 712
    .line 713
    if-eqz v4, :cond_10

    .line 714
    .line 715
    if-eqz v21, :cond_f

    .line 716
    .line 717
    goto :goto_d

    .line 718
    :cond_f
    :goto_c
    move-object/from16 v4, p4

    .line 719
    .line 720
    goto :goto_e

    .line 721
    :cond_10
    :goto_d
    iput-object v11, v1, La7/m;->l:Ljava/lang/Object;

    .line 722
    .line 723
    goto :goto_c

    .line 724
    :goto_e
    invoke-virtual {v4, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 725
    .line 726
    .line 727
    move-object v12, v1

    .line 728
    move-object v10, v4

    .line 729
    move v8, v9

    .line 730
    move v15, v14

    .line 731
    move-object/from16 v6, v17

    .line 732
    .line 733
    move-object/from16 v13, v19

    .line 734
    .line 735
    move/from16 v4, v20

    .line 736
    .line 737
    move-object/from16 v7, v22

    .line 738
    .line 739
    const/4 v9, 0x0

    .line 740
    const/16 v11, 0x10

    .line 741
    .line 742
    const/16 v14, 0xc

    .line 743
    .line 744
    move-object/from16 v1, p2

    .line 745
    .line 746
    goto/16 :goto_0

    .line 747
    .line 748
    :cond_11
    invoke-static {}, Lo6/k;->N()V

    .line 749
    .line 750
    .line 751
    const/16 v18, 0x0

    .line 752
    .line 753
    throw v18

    .line 754
    :cond_12
    move/from16 v20, v4

    .line 755
    .line 756
    move-object v2, v6

    .line 757
    move-object/from16 v22, v7

    .line 758
    .line 759
    move-object v4, v10

    .line 760
    move-object v1, v12

    .line 761
    invoke-virtual {v2, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 762
    .line 763
    .line 764
    move-object/from16 v3, v22

    .line 765
    .line 766
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 767
    .line 768
    .line 769
    new-instance v4, Lm6/v3;

    .line 770
    .line 771
    const/4 v6, 0x0

    .line 772
    move/from16 v7, v20

    .line 773
    .line 774
    invoke-direct {v4, v2, v7, v6}, Lm6/v3;-><init>(Landroid/widget/ScrollView;II)V

    .line 775
    .line 776
    .line 777
    invoke-virtual {v2, v4}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 778
    .line 779
    .line 780
    new-instance v2, Landroid/widget/LinearLayout;

    .line 781
    .line 782
    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 783
    .line 784
    .line 785
    const/4 v15, 0x0

    .line 786
    invoke-virtual {v2, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 787
    .line 788
    .line 789
    const v4, 0x800015

    .line 790
    .line 791
    .line 792
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 793
    .line 794
    .line 795
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 796
    .line 797
    const/4 v9, -0x2

    .line 798
    const/4 v10, -0x1

    .line 799
    invoke-direct {v4, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 800
    .line 801
    .line 802
    invoke-virtual {v2, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 803
    .line 804
    .line 805
    new-instance v4, Lm6/u3;

    .line 806
    .line 807
    const/4 v6, 0x1

    .line 808
    invoke-direct {v4, v5, v6}, Lm6/u3;-><init>(La7/m;I)V

    .line 809
    .line 810
    .line 811
    const v6, 0x7f080055

    .line 812
    .line 813
    .line 814
    move-object/from16 v7, p6

    .line 815
    .line 816
    invoke-static {v0, v7, v6, v15, v4}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 817
    .line 818
    .line 819
    move-result-object v4

    .line 820
    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 821
    .line 822
    .line 823
    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 824
    .line 825
    .line 826
    const/16 v2, 0x230

    .line 827
    .line 828
    invoke-static {v0, v3, v2}, Landroid/support/v4/media/session/b;->P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;

    .line 829
    .line 830
    .line 831
    move-result-object v0

    .line 832
    iput-object v0, v5, La7/m;->l:Ljava/lang/Object;

    .line 833
    .line 834
    iget-object v0, v1, La7/m;->l:Ljava/lang/Object;

    .line 835
    .line 836
    check-cast v0, Landroid/view/View;

    .line 837
    .line 838
    if-eqz v0, :cond_13

    .line 839
    .line 840
    new-instance v2, Lm6/w3;

    .line 841
    .line 842
    const/4 v4, 0x0

    .line 843
    invoke-direct {v2, v1, v4}, Lm6/w3;-><init>(La7/m;I)V

    .line 844
    .line 845
    .line 846
    invoke-virtual {v0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 847
    .line 848
    .line 849
    :cond_13
    invoke-interface/range {p5 .. p5}, Ljava/util/List;->size()I

    .line 850
    .line 851
    .line 852
    move-result v0

    .line 853
    new-instance v1, Ljava/lang/StringBuilder;

    .line 854
    .line 855
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 856
    .line 857
    .line 858
    move-object/from16 v2, p2

    .line 859
    .line 860
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 861
    .line 862
    .line 863
    const-string v2, ". "

    .line 864
    .line 865
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 866
    .line 867
    .line 868
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 869
    .line 870
    .line 871
    const-string v0, " options"

    .line 872
    .line 873
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 874
    .line 875
    .line 876
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 877
    .line 878
    .line 879
    move-result-object v0

    .line 880
    invoke-static {v0}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 881
    .line 882
    .line 883
    move-result-object v0

    .line 884
    invoke-static {v3, v0}, Lcom/bumptech/glide/c;->a(Landroid/view/View;Ljava/lang/String;)V

    .line 885
    .line 886
    .line 887
    return-void
.end method

.method public static final Z(Lcom/harindra/iptvpro/PlayerActivity;Lm6/l7;Lm6/m7;)V
    .locals 12

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "group"

    .line 7
    .line 8
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget v1, p1, Lm6/l7;->e:I

    .line 12
    .line 13
    iget v2, p1, Lm6/l7;->d:I

    .line 14
    .line 15
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->O1:Lf7/g1;

    .line 16
    .line 17
    const/4 v7, 0x0

    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    invoke-virtual {v0, v7}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    .line 21
    .line 22
    .line 23
    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->s1:Landroid/media/audiofx/LoudnessEnhancer;

    .line 24
    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->release()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :catchall_0
    move-exception v0

    .line 32
    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    .line 33
    .line 34
    .line 35
    :cond_1
    :goto_0
    iput-object v7, p0, Lcom/harindra/iptvpro/PlayerActivity;->s1:Landroid/media/audiofx/LoudnessEnhancer;

    .line 36
    .line 37
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->N1:Li/h;

    .line 38
    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    invoke-virtual {v0}, Li/h;->dismiss()V

    .line 42
    .line 43
    .line 44
    :cond_2
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    const/4 v3, 0x2

    .line 49
    const/16 v5, 0x30

    .line 50
    .line 51
    invoke-static {v0, v3, v5}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v6

    .line 59
    invoke-static {v6, v3, v5}, Le7/e;->c0(Ljava/lang/String;IC)Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    new-instance v5, Landroid/widget/LinearLayout;

    .line 64
    .line 65
    invoke-direct {v5, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 66
    .line 67
    .line 68
    const/4 v6, 0x1

    .line 69
    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 70
    .line 71
    .line 72
    const v8, 0x7f080059

    .line 73
    .line 74
    .line 75
    invoke-virtual {v5, v8}, Landroid/view/View;->setBackgroundResource(I)V

    .line 76
    .line 77
    .line 78
    const/16 v8, 0x12

    .line 79
    .line 80
    invoke-virtual {p0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 81
    .line 82
    .line 83
    move-result v9

    .line 84
    const/16 v10, 0x10

    .line 85
    .line 86
    invoke-virtual {p0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 87
    .line 88
    .line 89
    move-result v11

    .line 90
    invoke-virtual {p0, v8}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 91
    .line 92
    .line 93
    move-result v8

    .line 94
    invoke-virtual {p0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 95
    .line 96
    .line 97
    move-result v10

    .line 98
    invoke-virtual {v5, v9, v11, v8, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 99
    .line 100
    .line 101
    new-instance v8, Landroid/widget/TextView;

    .line 102
    .line 103
    invoke-direct {v8, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 104
    .line 105
    .line 106
    const-string v9, "NEXT EPISODE IN 8s"

    .line 107
    .line 108
    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 109
    .line 110
    .line 111
    const/high16 v9, 0x41300000    # 11.0f

    .line 112
    .line 113
    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v8}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 117
    .line 118
    .line 119
    move-result-object v9

    .line 120
    invoke-virtual {v8, v9, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 121
    .line 122
    .line 123
    const-string v6, "#38BDF8"

    .line 124
    .line 125
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    move-result v6

    .line 129
    invoke-virtual {v8, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 130
    .line 131
    .line 132
    const v6, 0x7f08004f

    .line 133
    .line 134
    .line 135
    invoke-virtual {v8, v6}, Landroid/view/View;->setBackgroundResource(I)V

    .line 136
    .line 137
    .line 138
    const/16 v6, 0xa

    .line 139
    .line 140
    invoke-virtual {p0, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 141
    .line 142
    .line 143
    move-result v9

    .line 144
    const/4 v10, 0x5

    .line 145
    invoke-virtual {p0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 146
    .line 147
    .line 148
    move-result v11

    .line 149
    invoke-virtual {p0, v6}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 150
    .line 151
    .line 152
    move-result v6

    .line 153
    invoke-virtual {p0, v10}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 154
    .line 155
    .line 156
    move-result v10

    .line 157
    invoke-virtual {v8, v9, v11, v6, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 158
    .line 159
    .line 160
    iget-object v6, p1, Lm6/l7;->f:Ljava/lang/String;

    .line 161
    .line 162
    const-string v9, "E"

    .line 163
    .line 164
    const-string v10, " \u2022 "

    .line 165
    .line 166
    const-string v11, "Up Next: S"

    .line 167
    .line 168
    invoke-static {v11, v0, v9, v3, v10}, Lq3/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    iget-object v3, p2, Lm6/m7;->c:Ljava/lang/String;

    .line 180
    .line 181
    new-instance v6, Ljava/lang/StringBuilder;

    .line 182
    .line 183
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 184
    .line 185
    .line 186
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 187
    .line 188
    .line 189
    const-string v3, " \u2022 Season "

    .line 190
    .line 191
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 195
    .line 196
    .line 197
    const-string v2, ", Episode "

    .line 198
    .line 199
    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 200
    .line 201
    .line 202
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    const-string v2, ""

    .line 210
    .line 211
    const v3, 0x7f0800d0

    .line 212
    .line 213
    .line 214
    invoke-static {p0, v3, v0, v1, v2}, Landroid/support/v4/media/session/b;->b(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 222
    .line 223
    .line 224
    new-instance v0, Landroid/widget/LinearLayout;

    .line 225
    .line 226
    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 227
    .line 228
    .line 229
    const/4 v1, 0x0

    .line 230
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 231
    .line 232
    .line 233
    const v2, 0x800015

    .line 234
    .line 235
    .line 236
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 237
    .line 238
    .line 239
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 240
    .line 241
    const/4 v3, -0x1

    .line 242
    const/4 v6, -0x2

    .line 243
    invoke-direct {v2, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 244
    .line 245
    .line 246
    const/16 v3, 0xe

    .line 247
    .line 248
    invoke-virtual {p0, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 249
    .line 250
    .line 251
    move-result v3

    .line 252
    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 253
    .line 254
    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 255
    .line 256
    .line 257
    new-instance v2, Lm6/r4;

    .line 258
    .line 259
    const/16 v3, 0x11

    .line 260
    .line 261
    invoke-direct {v2, p0, v3}, Lm6/r4;-><init>(Lcom/harindra/iptvpro/PlayerActivity;I)V

    .line 262
    .line 263
    .line 264
    const-string v3, "Cancel Auto-Play"

    .line 265
    .line 266
    const v6, 0x7f080055

    .line 267
    .line 268
    .line 269
    invoke-static {p0, v3, v6, v1, v2}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 270
    .line 271
    .line 272
    move-result-object v1

    .line 273
    new-instance v2, Lm6/a5;

    .line 274
    .line 275
    const/4 v3, 0x4

    .line 276
    invoke-direct {v2, p0, p2, p1, v3}, Lm6/a5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;I)V

    .line 277
    .line 278
    .line 279
    const-string v3, "\u23ed Play Next Episode Now"

    .line 280
    .line 281
    const v6, 0x7f080051

    .line 282
    .line 283
    .line 284
    const v9, 0x7f0800ca

    .line 285
    .line 286
    .line 287
    invoke-static {p0, v3, v6, v9, v2}, Landroid/support/v4/media/session/b;->u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;

    .line 288
    .line 289
    .line 290
    move-result-object v2

    .line 291
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 298
    .line 299
    .line 300
    const/16 v0, 0x21c

    .line 301
    .line 302
    invoke-static {p0, v5, v0}, Landroid/support/v4/media/session/b;->P(Lcom/harindra/iptvpro/PlayerActivity;Landroid/widget/LinearLayout;I)Li/h;

    .line 303
    .line 304
    .line 305
    move-result-object v1

    .line 306
    iput-object v1, p0, Lcom/harindra/iptvpro/PlayerActivity;->N1:Li/h;

    .line 307
    .line 308
    new-instance v0, Lm6/e4;

    .line 309
    .line 310
    const/4 v3, 0x1

    .line 311
    invoke-direct {v0, v2, v3}, Lm6/e4;-><init>(Landroid/widget/Button;I)V

    .line 312
    .line 313
    .line 314
    invoke-virtual {v2, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 315
    .line 316
    .line 317
    invoke-static {p0}, Landroidx/lifecycle/i0;->a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;

    .line 318
    .line 319
    .line 320
    move-result-object v9

    .line 321
    new-instance v0, Lm6/i5;

    .line 322
    .line 323
    const/4 v6, 0x0

    .line 324
    move-object v3, p0

    .line 325
    move-object v5, p1

    .line 326
    move-object v4, p2

    .line 327
    move-object v2, v8

    .line 328
    invoke-direct/range {v0 .. v6}, Lm6/i5;-><init>(Li/h;Landroid/widget/TextView;Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;Lr6/d;)V

    .line 329
    .line 330
    .line 331
    const/4 p1, 0x3

    .line 332
    invoke-static {v9, v7, v0, p1}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    .line 333
    .line 334
    .line 335
    move-result-object p1

    .line 336
    iput-object p1, p0, Lcom/harindra/iptvpro/PlayerActivity;->O1:Lf7/g1;

    .line 337
    .line 338
    return-void
.end method

.method public static a(IILjava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x2

    .line 4
    if-gez p0, :cond_0

    .line 5
    .line 6
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    new-array p1, v2, [Ljava/lang/Object;

    .line 11
    .line 12
    aput-object p2, p1, v1

    .line 13
    .line 14
    aput-object p0, p1, v0

    .line 15
    .line 16
    const-string p0, "%s (%s) must not be negative"

    .line 17
    .line 18
    invoke-static {p0, p1}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :cond_0
    if-ltz p1, :cond_1

    .line 24
    .line 25
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    const/4 v3, 0x3

    .line 34
    new-array v3, v3, [Ljava/lang/Object;

    .line 35
    .line 36
    aput-object p2, v3, v1

    .line 37
    .line 38
    aput-object p0, v3, v0

    .line 39
    .line 40
    aput-object p1, v3, v2

    .line 41
    .line 42
    const-string p0, "%s (%s) must not be greater than size (%s)"

    .line 43
    .line 44
    invoke-static {p0, v3}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    return-object p0

    .line 49
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 50
    .line 51
    const-string p2, "negative size: "

    .line 52
    .line 53
    invoke-static {p2, p1}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw p0
.end method

.method public static final a0(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;Lm6/n1;)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v4, p3

    .line 8
    .line 9
    const-string v1, "<this>"

    .line 10
    .line 11
    invoke-static {v0, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v1, "group"

    .line 15
    .line 16
    invoke-static {v2, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, v3, Lm6/l7;->a:Lm6/n;

    .line 20
    .line 21
    iget-object v6, v1, Lm6/n;->a:Ljava/lang/String;

    .line 22
    .line 23
    iget v7, v3, Lm6/l7;->e:I

    .line 24
    .line 25
    iget v8, v3, Lm6/l7;->d:I

    .line 26
    .line 27
    new-instance v9, Ljava/util/ArrayList;

    .line 28
    .line 29
    const/4 v1, 0x6

    .line 30
    invoke-direct {v9, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 31
    .line 32
    .line 33
    if-eqz v4, :cond_1

    .line 34
    .line 35
    invoke-virtual {v4}, Lm6/n1;->a()Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_1

    .line 40
    .line 41
    iget-wide v10, v4, Lm6/n1;->b:J

    .line 42
    .line 43
    const-wide/32 v12, 0xea60

    .line 44
    .line 45
    .line 46
    div-long/2addr v10, v12

    .line 47
    const-wide/16 v12, 0x1

    .line 48
    .line 49
    cmp-long v1, v10, v12

    .line 50
    .line 51
    if-gez v1, :cond_0

    .line 52
    .line 53
    move-wide v10, v12

    .line 54
    :cond_0
    new-instance v12, Lm6/v0;

    .line 55
    .line 56
    invoke-virtual {v4}, Lm6/n1;->b()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    new-instance v5, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    const-string v13, "\u25b6 Resume Episode ("

    .line 63
    .line 64
    invoke-direct {v5, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v5, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    const-string v10, " min \u2022 "

    .line 71
    .line 72
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v1, "%)"

    .line 79
    .line 80
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v14

    .line 87
    iget-object v1, v3, Lm6/l7;->f:Ljava/lang/String;

    .line 88
    .line 89
    const-string v5, "Continue watching "

    .line 90
    .line 91
    const-string v10, " from saved position"

    .line 92
    .line 93
    invoke-static {v5, v1, v10}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v15

    .line 97
    invoke-virtual {v4}, Lm6/n1;->b()I

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    const-string v5, "RESUME "

    .line 102
    .line 103
    const-string v10, "%"

    .line 104
    .line 105
    invoke-static {v1, v5, v10}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v16

    .line 109
    new-instance v18, Lm6/d;

    .line 110
    .line 111
    const/4 v5, 0x3

    .line 112
    move-object v1, v0

    .line 113
    move-object/from16 v0, v18

    .line 114
    .line 115
    invoke-direct/range {v0 .. v5}, Lm6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 116
    .line 117
    .line 118
    move-object v0, v1

    .line 119
    const v13, 0x7f0800ca

    .line 120
    .line 121
    .line 122
    const/16 v17, 0x1

    .line 123
    .line 124
    invoke-direct/range {v12 .. v18}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    :cond_1
    new-instance v13, Lm6/v0;

    .line 131
    .line 132
    if-eqz p3, :cond_2

    .line 133
    .line 134
    const-string v1, "\u23ee Start Episode from Beginning"

    .line 135
    .line 136
    :goto_0
    move-object v15, v1

    .line 137
    goto :goto_1

    .line 138
    :cond_2
    const-string v1, "\u25b6 Play Episode Now"

    .line 139
    .line 140
    goto :goto_0

    .line 141
    :goto_1
    const-string v1, "Play Season "

    .line 142
    .line 143
    const-string v4, " from 00:00"

    .line 144
    .line 145
    const-string v5, ", Episode "

    .line 146
    .line 147
    invoke-static {v8, v7, v1, v5, v4}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v16

    .line 151
    if-nez p3, :cond_3

    .line 152
    .line 153
    const/16 v18, 0x1

    .line 154
    .line 155
    goto :goto_2

    .line 156
    :cond_3
    const/16 v18, 0x0

    .line 157
    .line 158
    :goto_2
    new-instance v10, Lm6/a5;

    .line 159
    .line 160
    invoke-direct {v10, v0, v3, v2}, Lm6/a5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/l7;Lm6/m7;)V

    .line 161
    .line 162
    .line 163
    const v14, 0x7f0800ca

    .line 164
    .line 165
    .line 166
    const-string v17, "PLAY"

    .line 167
    .line 168
    move-object/from16 v19, v10

    .line 169
    .line 170
    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    invoke-static {v2, v8, v7, v6}, La/a;->q(Lm6/m7;IILjava/lang/String;)Lm6/l7;

    .line 177
    .line 178
    .line 179
    move-result-object v10

    .line 180
    const-string v11, ")"

    .line 181
    .line 182
    const-string v12, "E"

    .line 183
    .line 184
    if-eqz v10, :cond_4

    .line 185
    .line 186
    new-instance v13, Lm6/v0;

    .line 187
    .line 188
    iget v14, v10, Lm6/l7;->d:I

    .line 189
    .line 190
    iget v15, v10, Lm6/l7;->e:I

    .line 191
    .line 192
    const/16 v20, 0x1

    .line 193
    .line 194
    const-string v1, "\u23ed Play Next Episode (S"

    .line 195
    .line 196
    invoke-static {v14, v15, v1, v12, v11}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v15

    .line 200
    iget-object v1, v10, Lm6/l7;->f:Ljava/lang/String;

    .line 201
    .line 202
    new-instance v14, Lm6/a5;

    .line 203
    .line 204
    const/4 v4, 0x1

    .line 205
    invoke-direct {v14, v0, v2, v10, v4}, Lm6/a5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;I)V

    .line 206
    .line 207
    .line 208
    const/16 v18, 0x0

    .line 209
    .line 210
    move-object/from16 v19, v14

    .line 211
    .line 212
    const v14, 0x7f0800ca

    .line 213
    .line 214
    .line 215
    const-string v17, "NEXT EP"

    .line 216
    .line 217
    move-object/from16 v16, v1

    .line 218
    .line 219
    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    goto :goto_3

    .line 226
    :cond_4
    const/16 v20, 0x1

    .line 227
    .line 228
    :goto_3
    const-string v1, "currentEpisodeId"

    .line 229
    .line 230
    invoke-static {v6, v1}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 231
    .line 232
    .line 233
    iget-object v1, v2, Lm6/m7;->q:Ljava/util/Map;

    .line 234
    .line 235
    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 236
    .line 237
    .line 238
    move-result-object v4

    .line 239
    invoke-static {v4}, Lo6/j;->f0(Ljava/util/Collection;)Ljava/util/List;

    .line 240
    .line 241
    .line 242
    move-result-object v4

    .line 243
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 244
    .line 245
    .line 246
    move-result-object v10

    .line 247
    invoke-interface {v1, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v10

    .line 251
    check-cast v10, Ljava/util/List;

    .line 252
    .line 253
    sget-object v13, Lo6/r;->k:Lo6/r;

    .line 254
    .line 255
    if-nez v10, :cond_5

    .line 256
    .line 257
    move-object v10, v13

    .line 258
    :cond_5
    new-instance v14, Lm6/l;

    .line 259
    .line 260
    const/4 v15, 0x7

    .line 261
    invoke-direct {v14, v15}, Lm6/l;-><init>(I)V

    .line 262
    .line 263
    .line 264
    invoke-static {v10, v14}, Lo6/j;->g0(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/util/List;

    .line 265
    .line 266
    .line 267
    move-result-object v10

    .line 268
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 269
    .line 270
    .line 271
    move-result-object v14

    .line 272
    const/4 v15, 0x0

    .line 273
    :goto_4
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    .line 274
    .line 275
    .line 276
    move-result v16

    .line 277
    if-eqz v16, :cond_7

    .line 278
    .line 279
    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v16

    .line 283
    move-object/from16 p3, v13

    .line 284
    .line 285
    move-object/from16 v13, v16

    .line 286
    .line 287
    check-cast v13, Lm6/l7;

    .line 288
    .line 289
    move-object/from16 v16, v14

    .line 290
    .line 291
    iget-object v14, v13, Lm6/l7;->a:Lm6/n;

    .line 292
    .line 293
    iget-object v14, v14, Lm6/n;->a:Ljava/lang/String;

    .line 294
    .line 295
    invoke-static {v14, v6}, La7/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v14

    .line 299
    if-nez v14, :cond_8

    .line 300
    .line 301
    iget v13, v13, Lm6/l7;->e:I

    .line 302
    .line 303
    if-ne v13, v7, :cond_6

    .line 304
    .line 305
    goto :goto_5

    .line 306
    :cond_6
    add-int/lit8 v15, v15, 0x1

    .line 307
    .line 308
    move-object/from16 v13, p3

    .line 309
    .line 310
    move-object/from16 v14, v16

    .line 311
    .line 312
    goto :goto_4

    .line 313
    :cond_7
    move-object/from16 p3, v13

    .line 314
    .line 315
    const/4 v15, -0x1

    .line 316
    :cond_8
    :goto_5
    const/4 v13, 0x0

    .line 317
    if-lez v15, :cond_9

    .line 318
    .line 319
    add-int/lit8 v15, v15, -0x1

    .line 320
    .line 321
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object v1

    .line 325
    check-cast v1, Lm6/l7;

    .line 326
    .line 327
    goto :goto_7

    .line 328
    :cond_9
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 329
    .line 330
    .line 331
    move-result-object v10

    .line 332
    invoke-interface {v4, v10}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    .line 333
    .line 334
    .line 335
    move-result v10

    .line 336
    if-lez v10, :cond_c

    .line 337
    .line 338
    add-int/lit8 v10, v10, -0x1

    .line 339
    .line 340
    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    move-result-object v4

    .line 344
    check-cast v4, Ljava/lang/Number;

    .line 345
    .line 346
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 347
    .line 348
    .line 349
    move-result v4

    .line 350
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 351
    .line 352
    .line 353
    move-result-object v4

    .line 354
    invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 355
    .line 356
    .line 357
    move-result-object v1

    .line 358
    check-cast v1, Ljava/util/List;

    .line 359
    .line 360
    if-nez v1, :cond_a

    .line 361
    .line 362
    move-object/from16 v1, p3

    .line 363
    .line 364
    :cond_a
    new-instance v4, Lm6/l;

    .line 365
    .line 366
    const/16 v10, 0x8

    .line 367
    .line 368
    invoke-direct {v4, v10}, Lm6/l;-><init>(I)V

    .line 369
    .line 370
    .line 371
    invoke-static {v1, v4}, Lo6/j;->g0(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/util/List;

    .line 372
    .line 373
    .line 374
    move-result-object v1

    .line 375
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 376
    .line 377
    .line 378
    move-result v4

    .line 379
    if-eqz v4, :cond_b

    .line 380
    .line 381
    move-object v1, v13

    .line 382
    goto :goto_6

    .line 383
    :cond_b
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 384
    .line 385
    .line 386
    move-result v4

    .line 387
    add-int/lit8 v4, v4, -0x1

    .line 388
    .line 389
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 390
    .line 391
    .line 392
    move-result-object v1

    .line 393
    :goto_6
    check-cast v1, Lm6/l7;

    .line 394
    .line 395
    goto :goto_7

    .line 396
    :cond_c
    move-object v1, v13

    .line 397
    :goto_7
    if-eqz v1, :cond_d

    .line 398
    .line 399
    new-instance v14, Lm6/v0;

    .line 400
    .line 401
    iget v4, v1, Lm6/l7;->d:I

    .line 402
    .line 403
    iget v10, v1, Lm6/l7;->e:I

    .line 404
    .line 405
    const-string v15, "\u23ee Play Previous Episode (S"

    .line 406
    .line 407
    invoke-static {v4, v10, v15, v12, v11}, La0/h;->o(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 408
    .line 409
    .line 410
    move-result-object v16

    .line 411
    iget-object v4, v1, Lm6/l7;->f:Ljava/lang/String;

    .line 412
    .line 413
    new-instance v10, Lm6/a5;

    .line 414
    .line 415
    const/4 v11, 0x2

    .line 416
    invoke-direct {v10, v0, v2, v1, v11}, Lm6/a5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;I)V

    .line 417
    .line 418
    .line 419
    const/16 v19, 0x0

    .line 420
    .line 421
    const v15, 0x7f0800ca

    .line 422
    .line 423
    .line 424
    const-string v18, "PREV EP"

    .line 425
    .line 426
    move-object/from16 v17, v4

    .line 427
    .line 428
    move-object/from16 v20, v10

    .line 429
    .line 430
    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v9, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 434
    .line 435
    .line 436
    :cond_d
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->B()Lm6/q1;

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 441
    .line 442
    invoke-virtual {v1, v4}, Lm6/q1;->c(Ljava/lang/String;)Lm6/p1;

    .line 443
    .line 444
    .line 445
    move-result-object v1

    .line 446
    sget-object v4, Lm6/q6;->EPISODE:Lm6/q6;

    .line 447
    .line 448
    invoke-virtual {v1, v4, v6}, Lm6/p1;->b(Lm6/q6;Ljava/lang/String;)Z

    .line 449
    .line 450
    .line 451
    move-result v1

    .line 452
    new-instance v14, Lm6/v0;

    .line 453
    .line 454
    if-eqz v1, :cond_e

    .line 455
    .line 456
    const-string v4, "\u2713 Episode is in the Playback Queue"

    .line 457
    .line 458
    :goto_8
    move-object/from16 v16, v4

    .line 459
    .line 460
    goto :goto_9

    .line 461
    :cond_e
    const-string v4, "\u2795 Add Episode to Playback Queue"

    .line 462
    .line 463
    goto :goto_8

    .line 464
    :goto_9
    if-eqz v1, :cond_f

    .line 465
    .line 466
    const-string v4, "Open the queue to reorder or remove it"

    .line 467
    .line 468
    :goto_a
    move-object/from16 v17, v4

    .line 469
    .line 470
    goto :goto_b

    .line 471
    :cond_f
    const-string v4, "Plays after the current movie/episode ends"

    .line 472
    .line 473
    goto :goto_a

    .line 474
    :goto_b
    if-eqz v1, :cond_10

    .line 475
    .line 476
    const-string v4, "QUEUED"

    .line 477
    .line 478
    :goto_c
    move-object/from16 v18, v4

    .line 479
    .line 480
    goto :goto_d

    .line 481
    :cond_10
    const-string v4, "QUEUE"

    .line 482
    .line 483
    goto :goto_c

    .line 484
    :goto_d
    new-instance v4, Lm6/b5;

    .line 485
    .line 486
    invoke-direct {v4, v1, v0, v2, v3}, Lm6/b5;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;)V

    .line 487
    .line 488
    .line 489
    const/16 v19, 0x0

    .line 490
    .line 491
    const v15, 0x7f0800cb

    .line 492
    .line 493
    .line 494
    move-object/from16 v20, v4

    .line 495
    .line 496
    invoke-direct/range {v14 .. v20}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 497
    .line 498
    .line 499
    invoke-virtual {v9, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 500
    .line 501
    .line 502
    iget-object v1, v0, Lcom/harindra/iptvpro/PlayerActivity;->z1:Ljava/util/HashMap;

    .line 503
    .line 504
    iget-object v4, v2, Lm6/m7;->a:Ljava/lang/String;

    .line 505
    .line 506
    invoke-virtual {v1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 507
    .line 508
    .line 509
    move-result-object v1

    .line 510
    check-cast v1, Ljava/util/Map;

    .line 511
    .line 512
    if-eqz v1, :cond_14

    .line 513
    .line 514
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 515
    .line 516
    .line 517
    move-result-object v4

    .line 518
    invoke-interface {v1, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 519
    .line 520
    .line 521
    move-result-object v1

    .line 522
    check-cast v1, Ljava/util/List;

    .line 523
    .line 524
    if-eqz v1, :cond_14

    .line 525
    .line 526
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 527
    .line 528
    .line 529
    move-result v4

    .line 530
    if-eqz v4, :cond_11

    .line 531
    .line 532
    goto :goto_f

    .line 533
    :cond_11
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 534
    .line 535
    .line 536
    move-result-object v1

    .line 537
    const/4 v4, 0x0

    .line 538
    :cond_12
    :goto_e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 539
    .line 540
    .line 541
    move-result v10

    .line 542
    if-eqz v10, :cond_15

    .line 543
    .line 544
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 545
    .line 546
    .line 547
    move-result-object v10

    .line 548
    check-cast v10, Lm6/l7;

    .line 549
    .line 550
    iget v10, v10, Lm6/l7;->e:I

    .line 551
    .line 552
    if-le v10, v7, :cond_12

    .line 553
    .line 554
    add-int/lit8 v4, v4, 0x1

    .line 555
    .line 556
    if-ltz v4, :cond_13

    .line 557
    .line 558
    goto :goto_e

    .line 559
    :cond_13
    invoke-static {}, Lo6/k;->M()V

    .line 560
    .line 561
    .line 562
    throw v13

    .line 563
    :cond_14
    :goto_f
    const/4 v4, 0x0

    .line 564
    :cond_15
    if-lez v4, :cond_16

    .line 565
    .line 566
    new-instance v10, Lm6/v0;

    .line 567
    .line 568
    const-string v1, "\u2795 Queue the next "

    .line 569
    .line 570
    const-string v11, " episode(s) of Season "

    .line 571
    .line 572
    invoke-static {v4, v8, v1, v11}, La0/h;->n(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v12

    .line 576
    new-instance v1, Lm6/a5;

    .line 577
    .line 578
    const/4 v4, 0x3

    .line 579
    invoke-direct {v1, v0, v2, v3, v4}, Lm6/a5;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Lm6/l7;I)V

    .line 580
    .line 581
    .line 582
    const/4 v15, 0x0

    .line 583
    const v11, 0x7f0800cb

    .line 584
    .line 585
    .line 586
    const-string v13, "Adds every later episode of this season in order (duplicates are skipped)"

    .line 587
    .line 588
    const-string v14, "QUEUE ALL"

    .line 589
    .line 590
    move-object/from16 v16, v1

    .line 591
    .line 592
    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 593
    .line 594
    .line 595
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 596
    .line 597
    .line 598
    :cond_16
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->D()Lm6/m6;

    .line 599
    .line 600
    .line 601
    move-result-object v1

    .line 602
    iget-object v4, v0, Lcom/harindra/iptvpro/PlayerActivity;->g2:Ljava/lang/String;

    .line 603
    .line 604
    invoke-virtual {v1, v6, v4}, Lm6/m6;->Z(Ljava/lang/String;Ljava/lang/String;)Z

    .line 605
    .line 606
    .line 607
    move-result v1

    .line 608
    new-instance v10, Lm6/v0;

    .line 609
    .line 610
    if-eqz v1, :cond_17

    .line 611
    .line 612
    const-string v4, "Mark Episode as Unwatched"

    .line 613
    .line 614
    :goto_10
    move-object v12, v4

    .line 615
    goto :goto_11

    .line 616
    :cond_17
    const-string v4, "\u2713 Mark Episode as Watched"

    .line 617
    .line 618
    goto :goto_10

    .line 619
    :goto_11
    const-string v4, "Update watched history for Season "

    .line 620
    .line 621
    invoke-static {v8, v7, v4, v5}, La0/h;->n(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 622
    .line 623
    .line 624
    move-result-object v13

    .line 625
    if-eqz v1, :cond_18

    .line 626
    .line 627
    const-string v4, "WATCHED \u2713"

    .line 628
    .line 629
    :goto_12
    move-object v14, v4

    .line 630
    goto :goto_13

    .line 631
    :cond_18
    const-string v4, "MARK"

    .line 632
    .line 633
    goto :goto_12

    .line 634
    :goto_13
    new-instance v4, Lm6/b5;

    .line 635
    .line 636
    invoke-direct {v4, v1, v0, v3, v2}, Lm6/b5;-><init>(ZLcom/harindra/iptvpro/PlayerActivity;Lm6/l7;Lm6/m7;)V

    .line 637
    .line 638
    .line 639
    const/4 v15, 0x0

    .line 640
    const v11, 0x7f0800d0

    .line 641
    .line 642
    .line 643
    move-object/from16 v16, v4

    .line 644
    .line 645
    invoke-direct/range {v10 .. v16}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 646
    .line 647
    .line 648
    invoke-virtual {v9, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 649
    .line 650
    .line 651
    iget-object v1, v3, Lm6/l7;->f:Ljava/lang/String;

    .line 652
    .line 653
    iget-object v2, v2, Lm6/m7;->c:Ljava/lang/String;

    .line 654
    .line 655
    new-instance v3, Ljava/lang/StringBuilder;

    .line 656
    .line 657
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 658
    .line 659
    .line 660
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 661
    .line 662
    .line 663
    const-string v2, " \u2022 Season "

    .line 664
    .line 665
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 666
    .line 667
    .line 668
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 669
    .line 670
    .line 671
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 672
    .line 673
    .line 674
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 675
    .line 676
    .line 677
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 678
    .line 679
    .line 680
    move-result-object v3

    .line 681
    const-string v4, "CONTINUE"

    .line 682
    .line 683
    const-string v6, "Back"

    .line 684
    .line 685
    move-object v2, v1

    .line 686
    const v1, 0x7f0800d0

    .line 687
    .line 688
    .line 689
    move-object v5, v9

    .line 690
    invoke-static/range {v0 .. v6}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 691
    .line 692
    .line 693
    return-void
.end method

.method public static final b(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 8

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "title"

    .line 7
    .line 8
    invoke-static {p2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "subtitle"

    .line 12
    .line 13
    invoke-static {p3, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "badgeText"

    .line 17
    .line 18
    invoke-static {p4, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    new-instance v0, Landroid/widget/LinearLayout;

    .line 22
    .line 23
    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 28
    .line 29
    .line 30
    const/16 v2, 0x10

    .line 31
    .line 32
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 33
    .line 34
    .line 35
    const v2, 0x7f08005a

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundResource(I)V

    .line 39
    .line 40
    .line 41
    const/16 v2, 0xe

    .line 42
    .line 43
    invoke-virtual {p0, v2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 44
    .line 45
    .line 46
    move-result v3

    .line 47
    const/16 v4, 0xc

    .line 48
    .line 49
    invoke-virtual {p0, v4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 50
    .line 51
    .line 52
    move-result v5

    .line 53
    invoke-virtual {p0, v2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    invoke-virtual {p0, v4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 58
    .line 59
    .line 60
    move-result v6

    .line 61
    invoke-virtual {v0, v3, v5, v2, v6}, Landroid/view/View;->setPadding(IIII)V

    .line 62
    .line 63
    .line 64
    new-instance v2, Landroid/widget/ImageView;

    .line 65
    .line 66
    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 70
    .line 71
    .line 72
    const p1, 0x7f080057

    .line 73
    .line 74
    .line 75
    invoke-virtual {v2, p1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 76
    .line 77
    .line 78
    const/16 p1, 0x8

    .line 79
    .line 80
    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 81
    .line 82
    .line 83
    move-result v3

    .line 84
    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 85
    .line 86
    .line 87
    move-result v5

    .line 88
    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 89
    .line 90
    .line 91
    move-result v6

    .line 92
    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 93
    .line 94
    .line 95
    move-result v7

    .line 96
    invoke-virtual {v2, v3, v5, v6, v7}, Landroid/view/View;->setPadding(IIII)V

    .line 97
    .line 98
    .line 99
    sget-object v3, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    .line 100
    .line 101
    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 102
    .line 103
    .line 104
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 105
    .line 106
    const/16 v5, 0x2a

    .line 107
    .line 108
    invoke-virtual {p0, v5}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 109
    .line 110
    .line 111
    move-result v6

    .line 112
    invoke-virtual {p0, v5}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 113
    .line 114
    .line 115
    move-result v5

    .line 116
    invoke-direct {v3, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 123
    .line 124
    .line 125
    new-instance v2, Landroid/widget/LinearLayout;

    .line 126
    .line 127
    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 128
    .line 129
    .line 130
    const/4 v3, 0x1

    .line 131
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 132
    .line 133
    .line 134
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    .line 135
    .line 136
    const/4 v6, -0x2

    .line 137
    const/high16 v7, 0x3f800000    # 1.0f

    .line 138
    .line 139
    invoke-direct {v5, v1, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {p0, v4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    invoke-virtual {v5, v1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0, p1}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 150
    .line 151
    .line 152
    move-result p1

    .line 153
    invoke-virtual {v5, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v2, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 157
    .line 158
    .line 159
    new-instance p1, Landroid/widget/TextView;

    .line 160
    .line 161
    invoke-direct {p1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 165
    .line 166
    .line 167
    const/high16 p2, 0x41780000    # 15.5f

    .line 168
    .line 169
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {p1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 173
    .line 174
    .line 175
    move-result-object p2

    .line 176
    invoke-virtual {p1, p2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 177
    .line 178
    .line 179
    const-string p2, "#F8FAFC"

    .line 180
    .line 181
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 182
    .line 183
    .line 184
    move-result p2

    .line 185
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 189
    .line 190
    .line 191
    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 192
    .line 193
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 194
    .line 195
    .line 196
    new-instance v1, Landroid/widget/TextView;

    .line 197
    .line 198
    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 202
    .line 203
    .line 204
    const/high16 p3, 0x41380000    # 11.5f

    .line 205
    .line 206
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 207
    .line 208
    .line 209
    const-string p3, "#BAE6FD"

    .line 210
    .line 211
    invoke-static {p3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 212
    .line 213
    .line 214
    move-result p3

    .line 215
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 216
    .line 217
    .line 218
    const/4 p3, 0x2

    .line 219
    invoke-virtual {v1, p3}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 232
    .line 233
    .line 234
    invoke-static {p4}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 235
    .line 236
    .line 237
    move-result p1

    .line 238
    if-nez p1, :cond_0

    .line 239
    .line 240
    new-instance p1, Landroid/widget/TextView;

    .line 241
    .line 242
    invoke-direct {p1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {p1, p4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 246
    .line 247
    .line 248
    const/high16 p2, 0x41280000    # 10.5f

    .line 249
    .line 250
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {p1}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 254
    .line 255
    .line 256
    move-result-object p2

    .line 257
    invoke-virtual {p1, p2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 258
    .line 259
    .line 260
    const-string p2, "#38BDF8"

    .line 261
    .line 262
    invoke-static {p2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 263
    .line 264
    .line 265
    move-result p2

    .line 266
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 267
    .line 268
    .line 269
    const p2, 0x7f08004f

    .line 270
    .line 271
    .line 272
    invoke-virtual {p1, p2}, Landroid/view/View;->setBackgroundResource(I)V

    .line 273
    .line 274
    .line 275
    const/16 p2, 0xa

    .line 276
    .line 277
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 278
    .line 279
    .line 280
    move-result p3

    .line 281
    const/4 p4, 0x5

    .line 282
    invoke-virtual {p0, p4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 283
    .line 284
    .line 285
    move-result v1

    .line 286
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 287
    .line 288
    .line 289
    move-result p2

    .line 290
    invoke-virtual {p0, p4}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 291
    .line 292
    .line 293
    move-result p0

    .line 294
    invoke-virtual {p1, p3, v1, p2, p0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 298
    .line 299
    .line 300
    :cond_0
    return-object v0
.end method

.method public static final b0(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;Ljava/lang/Integer;)V
    .locals 8

    .line 1
    const-string v0, "group"

    .line 2
    .line 3
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v4, p0, Lcom/harindra/iptvpro/PlayerActivity;->d2:Lm6/w8;

    .line 7
    .line 8
    iget-object v0, p0, Lcom/harindra/iptvpro/PlayerActivity;->z1:Ljava/util/HashMap;

    .line 9
    .line 10
    iget-object v1, p1, Lm6/m7;->a:Ljava/lang/String;

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, Ljava/util/Map;

    .line 17
    .line 18
    iget-object v1, p1, Lm6/m7;->q:Ljava/util/Map;

    .line 19
    .line 20
    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_0

    .line 25
    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    invoke-static {p1, v0}, Lm6/m7;->a(Lm6/m7;Ljava/util/Map;)Lm6/m7;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    :cond_0
    move-object v3, p1

    .line 33
    iget-object p1, v3, Lm6/m7;->q:Ljava/util/Map;

    .line 34
    .line 35
    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_1

    .line 40
    .line 41
    if-eqz v4, :cond_1

    .line 42
    .line 43
    invoke-static {p0}, Landroidx/lifecycle/i0;->a(Landroidx/lifecycle/r;)Landroidx/lifecycle/m;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    new-instance v1, Lm6/q;

    .line 48
    .line 49
    const/4 v6, 0x0

    .line 50
    const/4 v7, 0x4

    .line 51
    move-object v2, p0

    .line 52
    move-object v5, p2

    .line 53
    invoke-direct/range {v1 .. v7}, Lm6/q;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 54
    .line 55
    .line 56
    const/4 p0, 0x3

    .line 57
    const/4 p2, 0x0

    .line 58
    invoke-static {p1, p2, v1, p0}, Lf7/v;->j(Lf7/s;Lr6/i;Lz6/p;I)Lf7/g1;

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_1
    move-object v2, p0

    .line 63
    move-object v5, p2

    .line 64
    iput-object v3, v2, Lcom/harindra/iptvpro/PlayerActivity;->I1:Lm6/m7;

    .line 65
    .line 66
    if-eqz v5, :cond_2

    .line 67
    .line 68
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 69
    .line 70
    .line 71
    move-result p0

    .line 72
    goto :goto_0

    .line 73
    :cond_2
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    invoke-static {p0}, Lo6/j;->f0(Ljava/util/Collection;)Ljava/util/List;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    invoke-static {p0}, Lo6/j;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    check-cast p0, Ljava/lang/Integer;

    .line 86
    .line 87
    if-eqz p0, :cond_3

    .line 88
    .line 89
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 90
    .line 91
    .line 92
    move-result p0

    .line 93
    goto :goto_0

    .line 94
    :cond_3
    const/4 p0, 0x1

    .line 95
    :goto_0
    invoke-static {v2, v3, p0}, Landroid/support/v4/media/session/b;->Q(Lcom/harindra/iptvpro/PlayerActivity;Lm6/m7;I)V

    .line 96
    .line 97
    .line 98
    return-void
.end method

.method public static c(Lh1/n;Ljava/lang/String;Lh1/k;I)La1/q;
    .locals 12

    .line 1
    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 2
    .line 3
    iget-object v0, p2, Lh1/k;->c:Ljava/lang/String;

    .line 4
    .line 5
    invoke-static {p1, v0}, Ly0/d;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    iget-wide v6, p2, Lh1/k;->a:J

    .line 10
    .line 11
    iget-wide v8, p2, Lh1/k;->b:J

    .line 12
    .line 13
    invoke-virtual {p0}, Lh1/n;->b()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    :goto_0
    move-object v10, p1

    .line 20
    goto :goto_1

    .line 21
    :cond_0
    iget-object p0, p0, Lh1/n;->l:Lr5/l0;

    .line 22
    .line 23
    const/4 p1, 0x0

    .line 24
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    check-cast p0, Lh1/b;

    .line 29
    .line 30
    iget-object p0, p0, Lh1/b;->a:Ljava/lang/String;

    .line 31
    .line 32
    iget-object p1, p2, Lh1/k;->c:Ljava/lang/String;

    .line 33
    .line 34
    invoke-static {p0, p1}, Ly0/d;->j(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    invoke-virtual {p0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    goto :goto_0

    .line 43
    :goto_1
    const-string p0, "The uri must be set."

    .line 44
    .line 45
    invoke-static {v2, p0}, Landroid/support/v4/media/session/b;->n(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    new-instance v1, La1/q;

    .line 49
    .line 50
    const/4 v3, 0x1

    .line 51
    const/4 v4, 0x0

    .line 52
    sget-object v5, Lr5/a2;->n:Lr5/a2;

    .line 53
    .line 54
    move v11, p3

    .line 55
    invoke-direct/range {v1 .. v11}, La1/q;-><init>(Landroid/net/Uri;I[BLjava/util/Map;JJLjava/lang/String;I)V

    .line 56
    .line 57
    .line 58
    return-object v1
.end method

.method public static c0(Lcom/google/common/util/concurrent/r;Lq5/j;Ljava/util/concurrent/Executor;)Lcom/google/common/util/concurrent/f;
    .locals 1

    .line 1
    new-instance v0, Lcom/google/common/util/concurrent/f;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iput-object p0, v0, Lcom/google/common/util/concurrent/f;->o:Lcom/google/common/util/concurrent/r;

    .line 10
    .line 11
    iput-object p1, v0, Lcom/google/common/util/concurrent/f;->p:Lq5/j;

    .line 12
    .line 13
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    sget-object p1, Lcom/google/common/util/concurrent/h;->k:Lcom/google/common/util/concurrent/h;

    .line 17
    .line 18
    if-ne p2, p1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    new-instance p1, Lcom/google/common/util/concurrent/t;

    .line 22
    .line 23
    invoke-direct {p1, p2, v0}, Lcom/google/common/util/concurrent/t;-><init>(Ljava/util/concurrent/Executor;Lcom/google/common/util/concurrent/i;)V

    .line 24
    .line 25
    .line 26
    move-object p2, p1

    .line 27
    :goto_0
    invoke-interface {p0, v0, p2}, Lcom/google/common/util/concurrent/r;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 28
    .line 29
    .line 30
    return-object v0
.end method

.method public static d(IILjava/lang/String;Z)V
    .locals 2

    .line 1
    if-eqz p3, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p3, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const/4 v0, 0x2

    .line 15
    new-array v0, v0, [Ljava/lang/Object;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    aput-object p0, v0, v1

    .line 19
    .line 20
    const/4 p0, 0x1

    .line 21
    aput-object p1, v0, p0

    .line 22
    .line 23
    invoke-static {p2, v0}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-direct {p3, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw p3
.end method

.method public static d0(Landroid/os/Bundle;)Landroid/os/Bundle;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p0, :cond_0

    .line 3
    .line 4
    return-object v0

    .line 5
    :cond_0
    const-class v1, Landroid/support/v4/media/session/b;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-virtual {p0, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 12
    .line 13
    .line 14
    :try_start_0
    invoke-virtual {p0}, Landroid/os/BaseBundle;->isEmpty()Z
    :try_end_0
    .catch Landroid/os/BadParcelableException; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    return-object p0

    .line 18
    :catch_0
    const-string p0, "MediaSessionCompat"

    .line 19
    .line 20
    const-string v1, "Could not unparcel the data."

    .line 21
    .line 22
    invoke-static {p0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 23
    .line 24
    .line 25
    return-object v0
.end method

.method public static e(ILjava/lang/String;Z)V
    .locals 2

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v0, 0x1

    .line 11
    new-array v0, v0, [Ljava/lang/Object;

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    aput-object p0, v0, v1

    .line 15
    .line 16
    invoke-static {p1, v0}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-direct {p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p2
.end method

.method public static e0(Ljava/lang/String;Ljava/util/HashSet;Ljava/util/Collection;Lf7/w0;)Lw7/l;
    .locals 20

    .line 1
    const-string v0, "scopedPrefixes"

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    invoke-static {v1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    .line 9
    .line 10
    move-object/from16 v2, p0

    .line 11
    .line 12
    invoke-direct {v0, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 13
    .line 14
    .line 15
    const-string v2, "credentialsRedacted"

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-eqz v2, :cond_0

    .line 23
    .line 24
    new-instance v0, Lm6/w6;

    .line 25
    .line 26
    const-string v1, "Account came from a backup without credentials"

    .line 27
    .line 28
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-object v0

    .line 32
    :cond_0
    const-string v2, "profile"

    .line 33
    .line 34
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    if-nez v2, :cond_1

    .line 39
    .line 40
    new-instance v0, Lm6/w6;

    .line 41
    .line 42
    const-string v1, "Account details are missing"

    .line 43
    .line 44
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    return-object v0

    .line 48
    :cond_1
    const-string v4, "id"

    .line 49
    .line 50
    const-string v5, ""

    .line 51
    .line 52
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    const-string v6, "optString(...)"

    .line 57
    .line 58
    invoke-static {v4, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    invoke-static {v4}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 62
    .line 63
    .line 64
    move-result-object v4

    .line 65
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    const-string v4, "name"

    .line 70
    .line 71
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    invoke-static {v4, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-static {v4}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 83
    .line 84
    .line 85
    move-result-object v9

    .line 86
    const-string v4, "type"

    .line 87
    .line 88
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    invoke-static {v4, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-static {v4}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v10

    .line 103
    const-string v4, "source"

    .line 104
    .line 105
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    invoke-static {v4, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    invoke-static {v4}, Le7/e;->o0(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 113
    .line 114
    .line 115
    move-result-object v4

    .line 116
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v11

    .line 120
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    if-nez v4, :cond_2

    .line 125
    .line 126
    new-instance v0, Lm6/w6;

    .line 127
    .line 128
    const-string v1, "Account ID is missing"

    .line 129
    .line 130
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    return-object v0

    .line 134
    :cond_2
    invoke-virtual {v9}, Ljava/lang/String;->length()I

    .line 135
    .line 136
    .line 137
    move-result v4

    .line 138
    if-nez v4, :cond_3

    .line 139
    .line 140
    new-instance v0, Lm6/w6;

    .line 141
    .line 142
    const-string v1, "Account name is missing"

    .line 143
    .line 144
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    return-object v0

    .line 148
    :cond_3
    move-object/from16 v4, p1

    .line 149
    .line 150
    invoke-virtual {v4, v10}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v4

    .line 154
    if-nez v4, :cond_4

    .line 155
    .line 156
    new-instance v0, Lm6/w6;

    .line 157
    .line 158
    const-string v1, "Unknown account type"

    .line 159
    .line 160
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    return-object v0

    .line 164
    :cond_4
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    .line 165
    .line 166
    .line 167
    move-result v4

    .line 168
    if-nez v4, :cond_5

    .line 169
    .line 170
    new-instance v0, Lm6/w6;

    .line 171
    .line 172
    const-string v1, "Playlist / server address is missing"

    .line 173
    .line 174
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    return-object v0

    .line 178
    :cond_5
    const-string v4, "****"

    .line 179
    .line 180
    invoke-static {v11, v4, v3}, Le7/e;->Q(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 181
    .line 182
    .line 183
    move-result v4

    .line 184
    if-eqz v4, :cond_6

    .line 185
    .line 186
    new-instance v0, Lm6/w6;

    .line 187
    .line 188
    const-string v1, "Account address was redacted"

    .line 189
    .line 190
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    return-object v0

    .line 194
    :cond_6
    move-object/from16 v4, p3

    .line 195
    .line 196
    invoke-virtual {v4, v8}, Lf7/w0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v4

    .line 200
    check-cast v4, Ljava/lang/String;

    .line 201
    .line 202
    new-instance v7, Ljava/util/HashSet;

    .line 203
    .line 204
    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    .line 205
    .line 206
    .line 207
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 212
    .line 213
    .line 214
    move-result v12

    .line 215
    if-eqz v12, :cond_7

    .line 216
    .line 217
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v12

    .line 221
    check-cast v12, Ljava/lang/String;

    .line 222
    .line 223
    new-instance v13, Ljava/lang/StringBuilder;

    .line 224
    .line 225
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 229
    .line 230
    .line 231
    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 232
    .line 233
    .line 234
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v12

    .line 238
    invoke-virtual {v7, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 239
    .line 240
    .line 241
    goto :goto_0

    .line 242
    :cond_7
    const-string v1, "prefs"

    .line 243
    .line 244
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 245
    .line 246
    .line 247
    move-result v4

    .line 248
    if-nez v4, :cond_8

    .line 249
    .line 250
    new-instance v0, Lorg/json/JSONArray;

    .line 251
    .line 252
    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 253
    .line 254
    .line 255
    goto :goto_1

    .line 256
    :cond_8
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 257
    .line 258
    .line 259
    move-result-object v4

    .line 260
    if-eqz v4, :cond_26

    .line 261
    .line 262
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    const-string v1, "getJSONArray(...)"

    .line 267
    .line 268
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    :goto_1
    new-instance v1, Ljava/util/ArrayList;

    .line 272
    .line 273
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 274
    .line 275
    .line 276
    move-result v4

    .line 277
    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 278
    .line 279
    .line 280
    new-instance v4, Ljava/util/HashSet;

    .line 281
    .line 282
    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    .line 286
    .line 287
    .line 288
    move-result v12

    .line 289
    move v13, v3

    .line 290
    :goto_2
    if-ge v13, v12, :cond_25

    .line 291
    .line 292
    invoke-virtual {v0, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 293
    .line 294
    .line 295
    move-result-object v14

    .line 296
    const-string v15, " is corrupt"

    .line 297
    .line 298
    const-string v3, "Account settings entry "

    .line 299
    .line 300
    if-nez v14, :cond_9

    .line 301
    .line 302
    new-instance v0, Lm6/w6;

    .line 303
    .line 304
    add-int/lit8 v13, v13, 0x1

    .line 305
    .line 306
    invoke-static {v13, v3, v15}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 307
    .line 308
    .line 309
    move-result-object v1

    .line 310
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    return-object v0

    .line 314
    :cond_9
    move-object/from16 p1, v0

    .line 315
    .line 316
    const-string v0, "k"

    .line 317
    .line 318
    invoke-virtual {v14, v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    invoke-virtual {v7, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 323
    .line 324
    .line 325
    move-result v16

    .line 326
    if-nez v16, :cond_a

    .line 327
    .line 328
    new-instance v0, Lm6/w6;

    .line 329
    .line 330
    add-int/lit8 v13, v13, 0x1

    .line 331
    .line 332
    const-string v1, " has an unexpected key"

    .line 333
    .line 334
    invoke-static {v13, v3, v1}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v1

    .line 338
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    return-object v0

    .line 342
    :cond_a
    invoke-virtual {v4, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 343
    .line 344
    .line 345
    move-result v16

    .line 346
    if-nez v16, :cond_b

    .line 347
    .line 348
    new-instance v0, Lm6/w6;

    .line 349
    .line 350
    add-int/lit8 v13, v13, 0x1

    .line 351
    .line 352
    const-string v1, " is duplicated"

    .line 353
    .line 354
    invoke-static {v13, v3, v1}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v1

    .line 358
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 359
    .line 360
    .line 361
    return-object v0

    .line 362
    :cond_b
    move-object/from16 p2, v4

    .line 363
    .line 364
    const-string v4, "v"

    .line 365
    .line 366
    invoke-virtual {v14, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 367
    .line 368
    .line 369
    move-result v16

    .line 370
    if-nez v16, :cond_c

    .line 371
    .line 372
    new-instance v0, Lm6/w6;

    .line 373
    .line 374
    add-int/lit8 v13, v13, 0x1

    .line 375
    .line 376
    const-string v1, " has no value"

    .line 377
    .line 378
    invoke-static {v13, v3, v1}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v1

    .line 382
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    return-object v0

    .line 386
    :cond_c
    invoke-virtual {v14, v4}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v4

    .line 390
    move-object/from16 p3, v7

    .line 391
    .line 392
    const-string v7, "t"

    .line 393
    .line 394
    invoke-virtual {v14, v7, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v7

    .line 398
    if-eqz v7, :cond_22

    .line 399
    .line 400
    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    .line 401
    .line 402
    .line 403
    move-result v14

    .line 404
    move-object/from16 v17, v8

    .line 405
    .line 406
    const/16 v8, 0x62

    .line 407
    .line 408
    if-eq v14, v8, :cond_20

    .line 409
    .line 410
    const/16 v8, 0x66

    .line 411
    .line 412
    if-eq v14, v8, :cond_1c

    .line 413
    .line 414
    const/16 v8, 0x69

    .line 415
    .line 416
    if-eq v14, v8, :cond_18

    .line 417
    .line 418
    const/16 v8, 0x6c

    .line 419
    .line 420
    if-eq v14, v8, :cond_15

    .line 421
    .line 422
    const/16 v8, 0x73

    .line 423
    .line 424
    if-eq v14, v8, :cond_13

    .line 425
    .line 426
    const v8, 0x1bc62

    .line 427
    .line 428
    .line 429
    if-eq v14, v8, :cond_d

    .line 430
    .line 431
    goto/16 :goto_b

    .line 432
    .line 433
    :cond_d
    const-string v8, "set"

    .line 434
    .line 435
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 436
    .line 437
    .line 438
    move-result v7

    .line 439
    if-nez v7, :cond_e

    .line 440
    .line 441
    goto/16 :goto_b

    .line 442
    .line 443
    :cond_e
    instance-of v7, v4, Lorg/json/JSONArray;

    .line 444
    .line 445
    if-eqz v7, :cond_f

    .line 446
    .line 447
    check-cast v4, Lorg/json/JSONArray;

    .line 448
    .line 449
    goto :goto_3

    .line 450
    :cond_f
    const/4 v4, 0x0

    .line 451
    :goto_3
    if-eqz v4, :cond_23

    .line 452
    .line 453
    new-instance v7, Ljava/util/LinkedHashSet;

    .line 454
    .line 455
    invoke-direct {v7}, Ljava/util/LinkedHashSet;-><init>()V

    .line 456
    .line 457
    .line 458
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    .line 459
    .line 460
    .line 461
    move-result v8

    .line 462
    const/4 v14, 0x0

    .line 463
    :goto_4
    if-ge v14, v8, :cond_12

    .line 464
    .line 465
    move/from16 v18, v8

    .line 466
    .line 467
    invoke-virtual {v4, v14}, Lorg/json/JSONArray;->opt(I)Ljava/lang/Object;

    .line 468
    .line 469
    .line 470
    move-result-object v8

    .line 471
    move-object/from16 v19, v4

    .line 472
    .line 473
    instance-of v4, v8, Ljava/lang/String;

    .line 474
    .line 475
    if-eqz v4, :cond_10

    .line 476
    .line 477
    check-cast v8, Ljava/lang/String;

    .line 478
    .line 479
    goto :goto_5

    .line 480
    :cond_10
    const/4 v8, 0x0

    .line 481
    :goto_5
    if-nez v8, :cond_11

    .line 482
    .line 483
    new-instance v0, Lm6/w6;

    .line 484
    .line 485
    add-int/lit8 v13, v13, 0x1

    .line 486
    .line 487
    invoke-static {v13, v3, v15}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 488
    .line 489
    .line 490
    move-result-object v1

    .line 491
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 492
    .line 493
    .line 494
    return-object v0

    .line 495
    :cond_11
    invoke-virtual {v7, v8}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    .line 496
    .line 497
    .line 498
    add-int/lit8 v14, v14, 0x1

    .line 499
    .line 500
    move/from16 v8, v18

    .line 501
    .line 502
    move-object/from16 v4, v19

    .line 503
    .line 504
    goto :goto_4

    .line 505
    :cond_12
    move-object v14, v7

    .line 506
    goto/16 :goto_c

    .line 507
    .line 508
    :cond_13
    const-string v8, "s"

    .line 509
    .line 510
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 511
    .line 512
    .line 513
    move-result v7

    .line 514
    if-nez v7, :cond_14

    .line 515
    .line 516
    goto/16 :goto_b

    .line 517
    .line 518
    :cond_14
    instance-of v7, v4, Ljava/lang/String;

    .line 519
    .line 520
    if-eqz v7, :cond_23

    .line 521
    .line 522
    move-object v14, v4

    .line 523
    check-cast v14, Ljava/lang/String;

    .line 524
    .line 525
    goto/16 :goto_c

    .line 526
    .line 527
    :cond_15
    const-string v8, "l"

    .line 528
    .line 529
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 530
    .line 531
    .line 532
    move-result v7

    .line 533
    if-nez v7, :cond_16

    .line 534
    .line 535
    goto/16 :goto_b

    .line 536
    .line 537
    :cond_16
    instance-of v7, v4, Ljava/lang/Number;

    .line 538
    .line 539
    if-eqz v7, :cond_17

    .line 540
    .line 541
    check-cast v4, Ljava/lang/Number;

    .line 542
    .line 543
    goto :goto_6

    .line 544
    :cond_17
    const/4 v4, 0x0

    .line 545
    :goto_6
    if-eqz v4, :cond_23

    .line 546
    .line 547
    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    .line 548
    .line 549
    .line 550
    move-result-wide v7

    .line 551
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 552
    .line 553
    .line 554
    move-result-object v14

    .line 555
    goto/16 :goto_c

    .line 556
    .line 557
    :cond_18
    const-string v8, "i"

    .line 558
    .line 559
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 560
    .line 561
    .line 562
    move-result v7

    .line 563
    if-nez v7, :cond_19

    .line 564
    .line 565
    goto/16 :goto_b

    .line 566
    .line 567
    :cond_19
    instance-of v7, v4, Ljava/lang/Number;

    .line 568
    .line 569
    if-eqz v7, :cond_1a

    .line 570
    .line 571
    check-cast v4, Ljava/lang/Number;

    .line 572
    .line 573
    goto :goto_7

    .line 574
    :cond_1a
    const/4 v4, 0x0

    .line 575
    :goto_7
    if-eqz v4, :cond_23

    .line 576
    .line 577
    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    .line 578
    .line 579
    .line 580
    move-result-wide v7

    .line 581
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 582
    .line 583
    .line 584
    move-result v14

    .line 585
    int-to-double v14, v14

    .line 586
    cmpg-double v7, v7, v14

    .line 587
    .line 588
    if-nez v7, :cond_1b

    .line 589
    .line 590
    goto :goto_8

    .line 591
    :cond_1b
    const/4 v4, 0x0

    .line 592
    :goto_8
    if-eqz v4, :cond_23

    .line 593
    .line 594
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 595
    .line 596
    .line 597
    move-result v4

    .line 598
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 599
    .line 600
    .line 601
    move-result-object v14

    .line 602
    goto :goto_c

    .line 603
    :cond_1c
    const-string v8, "f"

    .line 604
    .line 605
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 606
    .line 607
    .line 608
    move-result v7

    .line 609
    if-nez v7, :cond_1d

    .line 610
    .line 611
    goto :goto_b

    .line 612
    :cond_1d
    instance-of v7, v4, Ljava/lang/Number;

    .line 613
    .line 614
    if-eqz v7, :cond_1e

    .line 615
    .line 616
    check-cast v4, Ljava/lang/Number;

    .line 617
    .line 618
    goto :goto_9

    .line 619
    :cond_1e
    const/4 v4, 0x0

    .line 620
    :goto_9
    if-eqz v4, :cond_23

    .line 621
    .line 622
    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    .line 623
    .line 624
    .line 625
    move-result-wide v7

    .line 626
    invoke-static {v7, v8}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 627
    .line 628
    .line 629
    move-result-object v4

    .line 630
    invoke-static {v7, v8}, Ljava/lang/Double;->isNaN(D)Z

    .line 631
    .line 632
    .line 633
    move-result v14

    .line 634
    if-nez v14, :cond_1f

    .line 635
    .line 636
    invoke-static {v7, v8}, Ljava/lang/Double;->isInfinite(D)Z

    .line 637
    .line 638
    .line 639
    move-result v7

    .line 640
    if-nez v7, :cond_1f

    .line 641
    .line 642
    goto :goto_a

    .line 643
    :cond_1f
    const/4 v4, 0x0

    .line 644
    :goto_a
    if-eqz v4, :cond_23

    .line 645
    .line 646
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 647
    .line 648
    .line 649
    move-result-wide v7

    .line 650
    double-to-float v4, v7

    .line 651
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 652
    .line 653
    .line 654
    move-result-object v14

    .line 655
    goto :goto_c

    .line 656
    :cond_20
    const-string v8, "b"

    .line 657
    .line 658
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 659
    .line 660
    .line 661
    move-result v7

    .line 662
    if-nez v7, :cond_21

    .line 663
    .line 664
    goto :goto_b

    .line 665
    :cond_21
    instance-of v7, v4, Ljava/lang/Boolean;

    .line 666
    .line 667
    if-eqz v7, :cond_23

    .line 668
    .line 669
    move-object v14, v4

    .line 670
    check-cast v14, Ljava/lang/Boolean;

    .line 671
    .line 672
    goto :goto_c

    .line 673
    :cond_22
    move-object/from16 v17, v8

    .line 674
    .line 675
    :cond_23
    :goto_b
    const/4 v14, 0x0

    .line 676
    :goto_c
    if-nez v14, :cond_24

    .line 677
    .line 678
    new-instance v0, Lm6/w6;

    .line 679
    .line 680
    add-int/lit8 v13, v13, 0x1

    .line 681
    .line 682
    const-string v1, " has a wrong value type"

    .line 683
    .line 684
    invoke-static {v13, v3, v1}, La0/h;->p(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 685
    .line 686
    .line 687
    move-result-object v1

    .line 688
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 689
    .line 690
    .line 691
    return-object v0

    .line 692
    :cond_24
    new-instance v3, Lm6/e7;

    .line 693
    .line 694
    invoke-static {v0}, La7/h;->b(Ljava/lang/Object;)V

    .line 695
    .line 696
    .line 697
    invoke-direct {v3, v0, v14}, Lm6/e7;-><init>(Ljava/lang/String;Ljava/io/Serializable;)V

    .line 698
    .line 699
    .line 700
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 701
    .line 702
    .line 703
    add-int/lit8 v13, v13, 0x1

    .line 704
    .line 705
    move-object/from16 v0, p1

    .line 706
    .line 707
    move-object/from16 v4, p2

    .line 708
    .line 709
    move-object/from16 v7, p3

    .line 710
    .line 711
    move-object/from16 v8, v17

    .line 712
    .line 713
    const/4 v3, 0x0

    .line 714
    goto/16 :goto_2

    .line 715
    .line 716
    :cond_25
    move-object/from16 v17, v8

    .line 717
    .line 718
    new-instance v0, Lm6/x6;

    .line 719
    .line 720
    new-instance v3, Lm6/z6;

    .line 721
    .line 722
    new-instance v7, Lm6/y6;

    .line 723
    .line 724
    const-string v4, "username"

    .line 725
    .line 726
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 727
    .line 728
    .line 729
    move-result-object v12

    .line 730
    invoke-static {v12, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 731
    .line 732
    .line 733
    const-string v4, "password"

    .line 734
    .line 735
    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 736
    .line 737
    .line 738
    move-result-object v13

    .line 739
    invoke-static {v13, v6}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 740
    .line 741
    .line 742
    invoke-direct/range {v7 .. v13}, Lm6/y6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 743
    .line 744
    .line 745
    invoke-direct {v3, v7, v1}, Lm6/z6;-><init>(Lm6/y6;Ljava/util/ArrayList;)V

    .line 746
    .line 747
    .line 748
    invoke-direct {v0, v3}, Lm6/x6;-><init>(Lm6/z6;)V

    .line 749
    .line 750
    .line 751
    return-object v0

    .line 752
    :cond_26
    new-instance v0, Lm6/w6;

    .line 753
    .line 754
    const-string v1, "Account settings data is corrupt"

    .line 755
    .line 756
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 757
    .line 758
    .line 759
    return-object v0

    .line 760
    :catch_0
    new-instance v0, Lm6/w6;

    .line 761
    .line 762
    const-string v1, "Saved account data is corrupt"

    .line 763
    .line 764
    invoke-direct {v0, v1}, Lm6/w6;-><init>(Ljava/lang/String;)V

    .line 765
    .line 766
    .line 767
    return-object v0
.end method

.method public static f(Ljava/lang/String;Z)V
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    throw p1
.end method

.method public static g(Z)V
    .locals 0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 7
    .line 8
    .line 9
    throw p0
.end method

.method public static h(ZLjava/lang/String;J)V
    .locals 1

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    const/4 p3, 0x1

    .line 11
    new-array p3, p3, [Ljava/lang/Object;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    aput-object p2, p3, v0

    .line 15
    .line 16
    invoke-static {p1, p3}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p0
.end method

.method public static i(ZLjava/lang/String;JJ)V
    .locals 0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 7
    .line 8
    .line 9
    move-result-object p2

    .line 10
    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 11
    .line 12
    .line 13
    move-result-object p3

    .line 14
    const/4 p4, 0x2

    .line 15
    new-array p4, p4, [Ljava/lang/Object;

    .line 16
    .line 17
    const/4 p5, 0x0

    .line 18
    aput-object p2, p4, p5

    .line 19
    .line 20
    const/4 p2, 0x1

    .line 21
    aput-object p3, p4, p2

    .line 22
    .line 23
    invoke-static {p1, p4}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw p0
.end method

.method public static j(ZLjava/lang/String;Ljava/lang/Object;)V
    .locals 2

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    new-array v0, v0, [Ljava/lang/Object;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    aput-object p2, v0, v1

    .line 11
    .line 12
    invoke-static {p1, v0}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p0
.end method

.method public static k(ZLjava/lang/String;Ljava/lang/Object;Ljava/lang/Comparable;)V
    .locals 2

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    new-array v0, v0, [Ljava/lang/Object;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    aput-object p2, v0, v1

    .line 11
    .line 12
    const/4 p2, 0x1

    .line 13
    aput-object p3, v0, p2

    .line 14
    .line 15
    invoke-static {p1, v0}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw p0
.end method

.method public static l(II)V
    .locals 6

    .line 1
    if-ltz p0, :cond_1

    .line 2
    .line 3
    if-lt p0, p1, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    return-void

    .line 7
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 8
    .line 9
    const/4 v1, 0x2

    .line 10
    const/4 v2, 0x1

    .line 11
    const/4 v3, 0x0

    .line 12
    const-string v4, "index"

    .line 13
    .line 14
    if-ltz p0, :cond_3

    .line 15
    .line 16
    if-ltz p1, :cond_2

    .line 17
    .line 18
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    const/4 v5, 0x3

    .line 27
    new-array v5, v5, [Ljava/lang/Object;

    .line 28
    .line 29
    aput-object v4, v5, v3

    .line 30
    .line 31
    aput-object p0, v5, v2

    .line 32
    .line 33
    aput-object p1, v5, v1

    .line 34
    .line 35
    const-string p0, "%s (%s) must be less than size (%s)"

    .line 36
    .line 37
    invoke-static {p0, v5}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    goto :goto_1

    .line 42
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 43
    .line 44
    const-string v0, "negative size: "

    .line 45
    .line 46
    invoke-static {v0, p1}, La0/h;->r(Ljava/lang/String;I)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    throw p0

    .line 54
    :cond_3
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    new-array p1, v1, [Ljava/lang/Object;

    .line 59
    .line 60
    aput-object v4, p1, v3

    .line 61
    .line 62
    aput-object p0, p1, v2

    .line 63
    .line 64
    const-string p0, "%s (%s) must not be negative"

    .line 65
    .line 66
    invoke-static {p0, p1}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    :goto_1
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    throw v0
.end method

.method public static m(Ld1/a1;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static n(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    .line 5
    .line 6
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    throw p0
.end method

.method public static o(II)V
    .locals 2

    .line 1
    if-ltz p0, :cond_0

    .line 2
    .line 3
    if-gt p0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 7
    .line 8
    const-string v1, "index"

    .line 9
    .line 10
    invoke-static {p0, p1, v1}, Landroid/support/v4/media/session/b;->a(IILjava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    throw v0
.end method

.method public static p(III)V
    .locals 2

    .line 1
    if-ltz p0, :cond_1

    .line 2
    .line 3
    if-lt p1, p0, :cond_1

    .line 4
    .line 5
    if-le p1, p2, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    return-void

    .line 9
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 10
    .line 11
    if-ltz p0, :cond_4

    .line 12
    .line 13
    if-gt p0, p2, :cond_4

    .line 14
    .line 15
    if-ltz p1, :cond_3

    .line 16
    .line 17
    if-le p1, p2, :cond_2

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_2
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    const/4 p2, 0x2

    .line 29
    new-array p2, p2, [Ljava/lang/Object;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    aput-object p1, p2, v1

    .line 33
    .line 34
    const/4 p1, 0x1

    .line 35
    aput-object p0, p2, p1

    .line 36
    .line 37
    const-string p0, "end index (%s) must not be less than start index (%s)"

    .line 38
    .line 39
    invoke-static {p0, p2}, Lb4/a;->B(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    goto :goto_2

    .line 44
    :cond_3
    :goto_1
    const-string p0, "end index"

    .line 45
    .line 46
    invoke-static {p1, p2, p0}, Landroid/support/v4/media/session/b;->a(IILjava/lang/String;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    goto :goto_2

    .line 51
    :cond_4
    const-string p1, "start index"

    .line 52
    .line 53
    invoke-static {p0, p2, p1}, Landroid/support/v4/media/session/b;->a(IILjava/lang/String;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    :goto_2
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    throw v0
.end method

.method public static q(Landroid/content/Context;Ljava/lang/String;)I
    .locals 9

    .line 1
    if-eqz p1, :cond_4

    .line 2
    .line 3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 4
    .line 5
    const/16 v1, 0x21

    .line 6
    .line 7
    if-ge v0, v1, :cond_3

    .line 8
    .line 9
    const-string v1, "android.permission.POST_NOTIFICATIONS"

    .line 10
    .line 11
    invoke-static {v1, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_3

    .line 16
    .line 17
    new-instance p1, Lu/t;

    .line 18
    .line 19
    invoke-direct {p1, p0}, Lu/t;-><init>(Landroid/content/Context;)V

    .line 20
    .line 21
    .line 22
    const/16 v1, 0x18

    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    if-lt v0, v1, :cond_0

    .line 26
    .line 27
    iget-object p0, p1, Lu/t;->a:Landroid/app/NotificationManager;

    .line 28
    .line 29
    invoke-static {p0}, Lu/s;->a(Landroid/app/NotificationManager;)Z

    .line 30
    .line 31
    .line 32
    move-result p0

    .line 33
    goto :goto_0

    .line 34
    :cond_0
    const-string p1, "appops"

    .line 35
    .line 36
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/app/AppOpsManager;

    .line 41
    .line 42
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    iget v0, v0, Landroid/content/pm/ApplicationInfo;->uid:I

    .line 55
    .line 56
    const/4 v1, 0x1

    .line 57
    :try_start_0
    const-class v3, Landroid/app/AppOpsManager;

    .line 58
    .line 59
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    move-result-object v3

    .line 67
    const-string v4, "checkOpNoThrow"

    .line 68
    .line 69
    const/4 v5, 0x3

    .line 70
    new-array v6, v5, [Ljava/lang/Class;

    .line 71
    .line 72
    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 73
    .line 74
    aput-object v7, v6, v2

    .line 75
    .line 76
    aput-object v7, v6, v1

    .line 77
    .line 78
    const-class v7, Ljava/lang/String;

    .line 79
    .line 80
    const/4 v8, 0x2

    .line 81
    aput-object v7, v6, v8

    .line 82
    .line 83
    invoke-virtual {v3, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    const-string v6, "OP_POST_NOTIFICATION"

    .line 88
    .line 89
    invoke-virtual {v3, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    const-class v6, Ljava/lang/Integer;

    .line 94
    .line 95
    invoke-virtual {v3, v6}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    check-cast v3, Ljava/lang/Integer;

    .line 100
    .line 101
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 102
    .line 103
    .line 104
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    new-array v5, v5, [Ljava/lang/Object;

    .line 109
    .line 110
    aput-object v3, v5, v2

    .line 111
    .line 112
    aput-object v0, v5, v1

    .line 113
    .line 114
    aput-object p0, v5, v8

    .line 115
    .line 116
    invoke-virtual {v4, p1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    check-cast p0, Ljava/lang/Integer;

    .line 121
    .line 122
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 123
    .line 124
    .line 125
    move-result p0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 126
    if-nez p0, :cond_1

    .line 127
    .line 128
    :catch_0
    move p0, v1

    .line 129
    goto :goto_0

    .line 130
    :cond_1
    move p0, v2

    .line 131
    :goto_0
    if-eqz p0, :cond_2

    .line 132
    .line 133
    goto :goto_1

    .line 134
    :cond_2
    const/4 v2, -0x1

    .line 135
    :goto_1
    return v2

    .line 136
    :cond_3
    invoke-static {}, Landroid/os/Process;->myPid()I

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    invoke-static {}, Landroid/os/Process;->myUid()I

    .line 141
    .line 142
    .line 143
    move-result v1

    .line 144
    invoke-virtual {p0, p1, v0, v1}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    .line 145
    .line 146
    .line 147
    move-result p0

    .line 148
    return p0

    .line 149
    :cond_4
    new-instance p0, Ljava/lang/NullPointerException;

    .line 150
    .line 151
    const-string p1, "permission must be non-null"

    .line 152
    .line 153
    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    throw p0
.end method

.method public static r(Ljava/lang/String;Z)V
    .locals 0

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 5
    .line 6
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    throw p1
.end method

.method public static s(Z)V
    .locals 0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 7
    .line 8
    .line 9
    throw p0
.end method

.method public static t(La1/i;)V
    .locals 0

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    :try_start_0
    invoke-interface {p0}, La1/i;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    .line 5
    .line 6
    :catch_0
    :cond_0
    return-void
.end method

.method public static final u(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/String;IILz6/a;)Landroid/widget/Button;
    .locals 6

    .line 1
    const-string v0, "<this>"

    .line 2
    .line 3
    invoke-static {p0, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "label"

    .line 7
    .line 8
    invoke-static {p1, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    new-instance v0, Landroid/widget/Button;

    .line 12
    .line 13
    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 17
    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 21
    .line 22
    .line 23
    const/high16 v2, 0x41400000    # 12.0f

    .line 24
    .line 25
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Landroid/widget/TextView;->getTypeface()Landroid/graphics/Typeface;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    const/4 v3, 0x1

    .line 33
    invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 34
    .line 35
    .line 36
    const/4 v2, -0x1

    .line 37
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0, p2}, Landroid/view/View;->setBackgroundResource(I)V

    .line 41
    .line 42
    .line 43
    const/4 p2, 0x0

    .line 44
    invoke-virtual {v0, p2}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0, v3}, Landroid/view/View;->setFocusable(Z)V

    .line 48
    .line 49
    .line 50
    const/16 p2, 0x10

    .line 51
    .line 52
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    const/16 v3, 0x8

    .line 57
    .line 58
    invoke-virtual {p0, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 59
    .line 60
    .line 61
    move-result v4

    .line 62
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 63
    .line 64
    .line 65
    move-result p2

    .line 66
    invoke-virtual {p0, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 67
    .line 68
    .line 69
    move-result v5

    .line 70
    invoke-virtual {v0, v2, v4, p2, v5}, Landroid/view/View;->setPadding(IIII)V

    .line 71
    .line 72
    .line 73
    if-eqz p3, :cond_0

    .line 74
    .line 75
    invoke-virtual {v0, p3, v1, v1, v1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(IIII)V

    .line 76
    .line 77
    .line 78
    const/4 p2, 0x7

    .line 79
    invoke-virtual {p0, p2}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 84
    .line 85
    .line 86
    :cond_0
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    .line 87
    .line 88
    const/16 p3, 0x28

    .line 89
    .line 90
    invoke-virtual {p0, p3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 91
    .line 92
    .line 93
    move-result p3

    .line 94
    const/4 v1, -0x2

    .line 95
    invoke-direct {p2, v1, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p0, v3}, Lcom/harindra/iptvpro/PlayerActivity;->q(I)I

    .line 99
    .line 100
    .line 101
    move-result p3

    .line 102
    invoke-virtual {p2, p3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0, p2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 106
    .line 107
    .line 108
    new-instance p2, Lm6/w1;

    .line 109
    .line 110
    const p3, 0x3f847ae1    # 1.035f

    .line 111
    .line 112
    .line 113
    invoke-direct {p2, p3, p0}, Lm6/w1;-><init>(FLcom/harindra/iptvpro/PlayerActivity;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0, p2}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 117
    .line 118
    .line 119
    invoke-static {p1}, Lcom/bumptech/glide/c;->C(Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    invoke-static {p0}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 124
    .line 125
    .line 126
    move-result p2

    .line 127
    if-eqz p2, :cond_1

    .line 128
    .line 129
    goto :goto_0

    .line 130
    :cond_1
    move-object p1, p0

    .line 131
    :goto_0
    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 132
    .line 133
    .line 134
    new-instance p0, Lm3/f;

    .line 135
    .line 136
    const/4 p1, 0x5

    .line 137
    invoke-direct {p0, p1, p4}, Lm3/f;-><init>(ILjava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 141
    .line 142
    .line 143
    return-object v0
.end method

.method public static z(Ljava/lang/String;)[B
    .locals 6

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    rem-int/lit8 v0, v0, 0x2

    .line 6
    .line 7
    if-nez v0, :cond_2

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    div-int/lit8 v0, v0, 0x2

    .line 14
    .line 15
    new-array v1, v0, [B

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_0
    if-ge v2, v0, :cond_1

    .line 19
    .line 20
    mul-int/lit8 v3, v2, 0x2

    .line 21
    .line 22
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    const/16 v5, 0x10

    .line 27
    .line 28
    invoke-static {v4, v5}, Ljava/lang/Character;->digit(CI)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    add-int/lit8 v3, v3, 0x1

    .line 33
    .line 34
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    invoke-static {v3, v5}, Ljava/lang/Character;->digit(CI)I

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    const/4 v5, -0x1

    .line 43
    if-eq v4, v5, :cond_0

    .line 44
    .line 45
    if-eq v3, v5, :cond_0

    .line 46
    .line 47
    mul-int/lit8 v4, v4, 0x10

    .line 48
    .line 49
    add-int/2addr v4, v3

    .line 50
    int-to-byte v3, v4

    .line 51
    aput-byte v3, v1, v2

    .line 52
    .line 53
    add-int/lit8 v2, v2, 0x1

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 57
    .line 58
    const-string v0, "input is not hexadecimal"

    .line 59
    .line 60
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw p0

    .line 64
    :cond_1
    return-object v1

    .line 65
    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 66
    .line 67
    const-string v0, "Expected a string of even length"

    .line 68
    .line 69
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw p0
.end method


# virtual methods
.method public D([Lb0/j;I)Lb0/j;
    .locals 10

    .line 1
    new-instance v0, Lp1/h0;

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lp1/h0;-><init>(I)V

    .line 6
    .line 7
    .line 8
    and-int/lit8 v0, p2, 0x1

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    const/16 v0, 0x190

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/16 v0, 0x2bc

    .line 16
    .line 17
    :goto_0
    and-int/lit8 p2, p2, 0x2

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    const/4 v2, 0x1

    .line 21
    if-eqz p2, :cond_1

    .line 22
    .line 23
    move p2, v2

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    move p2, v1

    .line 26
    :goto_1
    array-length v3, p1

    .line 27
    const/4 v4, 0x0

    .line 28
    const v5, 0x7fffffff

    .line 29
    .line 30
    .line 31
    move v6, v1

    .line 32
    :goto_2
    if-ge v6, v3, :cond_5

    .line 33
    .line 34
    aget-object v7, p1, v6

    .line 35
    .line 36
    iget v8, v7, Lb0/j;->c:I

    .line 37
    .line 38
    sub-int/2addr v8, v0

    .line 39
    invoke-static {v8}, Ljava/lang/Math;->abs(I)I

    .line 40
    .line 41
    .line 42
    move-result v8

    .line 43
    mul-int/lit8 v8, v8, 0x2

    .line 44
    .line 45
    iget-boolean v9, v7, Lb0/j;->d:Z

    .line 46
    .line 47
    if-ne v9, p2, :cond_2

    .line 48
    .line 49
    move v9, v1

    .line 50
    goto :goto_3

    .line 51
    :cond_2
    move v9, v2

    .line 52
    :goto_3
    add-int/2addr v8, v9

    .line 53
    if-eqz v4, :cond_3

    .line 54
    .line 55
    if-le v5, v8, :cond_4

    .line 56
    .line 57
    :cond_3
    move-object v4, v7

    .line 58
    move v5, v8

    .line 59
    :cond_4
    add-int/lit8 v6, v6, 0x1

    .line 60
    .line 61
    goto :goto_2

    .line 62
    :cond_5
    return-object v4
.end method

.method public abstract H([Landroid/text/InputFilter;)[Landroid/text/InputFilter;
.end method

.method public abstract U(Z)V
.end method

.method public abstract V(Z)V
.end method

.method public abstract v(Landroid/content/Context;Lw/f;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
.end method

.method public abstract w(Landroid/content/Context;[Lb0/j;I)Landroid/graphics/Typeface;
.end method

.method public x(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    .locals 1

    .line 1
    invoke-static {p1}, Lb4/a;->x(Landroid/content/Context;)Ljava/io/File;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 v0, 0x0

    .line 6
    if-nez p1, :cond_0

    .line 7
    .line 8
    return-object v0

    .line 9
    :cond_0
    :try_start_0
    invoke-static {p1, p2}, Lb4/a;->h(Ljava/io/File;Ljava/io/InputStream;)Z

    .line 10
    .line 11
    .line 12
    move-result p2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    if-nez p2, :cond_1

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 16
    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_1
    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    invoke-static {p2}, Landroid/graphics/Typeface;->createFromFile(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 24
    .line 25
    .line 26
    move-result-object p2
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 28
    .line 29
    .line 30
    return-object p2

    .line 31
    :catchall_0
    move-exception p2

    .line 32
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 33
    .line 34
    .line 35
    throw p2

    .line 36
    :catch_0
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 37
    .line 38
    .line 39
    return-object v0
.end method

.method public y(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    .locals 0

    .line 1
    invoke-static {p1}, Lb4/a;->x(Landroid/content/Context;)Ljava/io/File;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p4, 0x0

    .line 6
    if-nez p1, :cond_0

    .line 7
    .line 8
    return-object p4

    .line 9
    :cond_0
    :try_start_0
    invoke-static {p1, p2, p3}, Lb4/a;->g(Ljava/io/File;Landroid/content/res/Resources;I)Z

    .line 10
    .line 11
    .line 12
    move-result p2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 13
    if-nez p2, :cond_1

    .line 14
    .line 15
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 16
    .line 17
    .line 18
    return-object p4

    .line 19
    :cond_1
    :try_start_1
    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    invoke-static {p2}, Landroid/graphics/Typeface;->createFromFile(Ljava/lang/String;)Landroid/graphics/Typeface;

    .line 24
    .line 25
    .line 26
    move-result-object p2
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 27
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 28
    .line 29
    .line 30
    return-object p2

    .line 31
    :catchall_0
    move-exception p2

    .line 32
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 33
    .line 34
    .line 35
    throw p2

    .line 36
    :catch_0
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 37
    .line 38
    .line 39
    return-object p4
.end method
